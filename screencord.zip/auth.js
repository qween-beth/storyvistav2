/**
 * Screencord — Authentication Module (SQLite Backend)
 * Handles login, signup, session management via server API.
 */

const ScreencordAuth = {
    currentUser: null,
    token: null,
    isGuest: false,

    async init() {
        // Check for existing token in localStorage
        const savedToken = localStorage.getItem('screencord_token');
        if (savedToken) {
            try {
                const res = await this.apiFetch('/api/auth/me');
                if (res.user) {
                    this.currentUser = res.user;
                    this.token = savedToken;
                    this.showApp();
                    return;
                }
            } catch (err) {
                // Token invalid, clear it
                localStorage.removeItem('screencord_token');
            }
        }
        this.showAuthGate();
    },





    async apiFetch(url, options = {}) {
        const headers = { 'Content-Type': 'application/json', ...options.headers };
        const token = this.token || localStorage.getItem('screencord_token');
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const res = await fetch(url, { ...options, headers });
        const data = await res.json();
        
        if (!res.ok) {
            throw new Error(data.error || 'Request failed');
        }
        return data;
    },

    isAdmin() {
        return this.currentUser?.role === 'admin';
    },

    showApp() {
        const authGate = document.getElementById('auth-gate');
        const appContent = document.getElementById('app-content');
        if (authGate) authGate.style.display = 'none';
        if (appContent) appContent.style.display = 'block';

        // Update UI with user info
        const userNameEl = document.getElementById('user-display-name');
        const userEmailEl = document.getElementById('user-email');
        const userAvatarEl = document.getElementById('user-avatar-letter');
        const creditsPill = document.getElementById('credits-pill');
        const creditsCountEl = document.getElementById('credits-count');
        const userCreditsInfoEl = document.getElementById('user-credits-info');
        const userPlanBadgeEl = document.getElementById('user-plan-badge');

        if (this.isGuest) {
            if (userNameEl) userNameEl.textContent = 'Guest';
            if (userEmailEl) userEmailEl.textContent = 'Not signed in';
            if (userAvatarEl) userAvatarEl.textContent = 'G';
            if (creditsPill) creditsPill.style.display = 'none';
            if (userPlanBadgeEl) userPlanBadgeEl.style.display = 'none';
            if (userCreditsInfoEl) userCreditsInfoEl.style.display = 'none';
        } else {
            if (userNameEl) userNameEl.textContent = this.currentUser?.display_name || 'User';
            if (userEmailEl) userEmailEl.textContent = this.currentUser?.email || '';
            if (userAvatarEl) {
                const name = this.currentUser?.display_name || this.currentUser?.email || 'U';
                userAvatarEl.textContent = name.charAt(0).toUpperCase();
            }
            if (creditsPill) creditsPill.style.display = 'flex';
            
            // Credits & Plan (added to API session response)
            const credits = this.currentUser?.credits ?? '--';
            const plan = this.currentUser?.plan ?? 'starter';
            
            if (creditsCountEl) creditsCountEl.textContent = credits;
            if (userCreditsInfoEl) {
                userCreditsInfoEl.style.display = 'inline-block';
                userCreditsInfoEl.textContent = `${credits} credits remaining`;
            }
            if (userPlanBadgeEl) {
                userPlanBadgeEl.style.display = 'inline-block';
                userPlanBadgeEl.textContent = plan === 'pro' ? 'Pro' : 'Starter';
                userPlanBadgeEl.className = `plan-badge ${plan}`;
            }

            const upgradeBtn = document.getElementById('btn-request-upgrade');
            if (upgradeBtn) {
                upgradeBtn.style.display = (plan === 'pro') ? 'none' : 'flex';
            }
        }

        // Role-based UI restriction
        if (typeof setUIRole === 'function') {
            const role = this.currentUser?.role || (this.isGuest ? 'viewer' : 'host');
            setUIRole(role);
        }

        // Store name for chat
        if (this.currentUser?.display_name) {
            localStorage.setItem('screencord_user_name', this.currentUser.display_name);
        } else if (this.isGuest) {
            const guestName = localStorage.getItem('screencord_user_name') || 'Guest';
            localStorage.setItem('screencord_user_name', guestName);
        }
    },

    showAuthGate() {
        const authGate = document.getElementById('auth-gate');
        const appContent = document.getElementById('app-content');
        if (authGate) authGate.style.display = 'flex';
        if (appContent) appContent.style.display = 'none';
    },

    async login(email, password) {
        const data = await this.apiFetch('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        this.currentUser = data.user;
        this.token = data.token;
        localStorage.setItem('screencord_token', data.token);
        this.showApp();
        return data;
    },

    async signup(email, password, displayName) {
        const data = await this.apiFetch('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify({ email, password, display_name: displayName })
        });
        
        this.currentUser = data.user;
        this.token = data.token;
        localStorage.setItem('screencord_token', data.token);
        this.showApp();
        return data;
    },

    async logout() {
        if (!this.isGuest) {
            try {
                await this.apiFetch('/api/auth/logout', { method: 'POST' });
            } catch (e) { /* ignore */ }
        }
        
        this.currentUser = null;
        this.token = null;
        this.isGuest = false;
        localStorage.removeItem('screencord_token');
        this.showAuthGate();
    },

    enterGuestMode() {
        this.isGuest = true;
        this.currentUser = null;
        this.token = null;
        this.showApp();
    },

    async updateProfile(updates) {
        const data = await this.apiFetch('/api/auth/profile', {
            method: 'PATCH',
            body: JSON.stringify(updates)
        });
        if (data.user) this.currentUser = data.user;
        return data.user;
    }
};

window.ScreencordAuth = ScreencordAuth;

// ─── Auth Form Handlers ───
window.handleAuthLogin = async function() {
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;
    const errorEl = document.getElementById('auth-error');
    const btn = document.getElementById('auth-submit-btn');

    if (!email || !password) {
        errorEl.textContent = 'Please enter email and password';
        errorEl.style.display = 'block';
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Signing in...';
    errorEl.style.display = 'none';

    try {
        await ScreencordAuth.login(email, password);
    } catch (err) {
        errorEl.textContent = err.message || 'Login failed';
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
    }
};

window.handleAuthSignup = async function() {
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;
    const name = document.getElementById('auth-name').value.trim() || email.split('@')[0];
    const errorEl = document.getElementById('auth-error');
    const btn = document.getElementById('auth-signup-btn');

    if (!email || !password) {
        errorEl.textContent = 'Please enter email and password';
        errorEl.style.display = 'block';
        return;
    }

    if (password.length < 6) {
        errorEl.textContent = 'Password must be at least 6 characters';
        errorEl.style.display = 'block';
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Creating account...';
    errorEl.style.display = 'none';

    try {
        await ScreencordAuth.signup(email, password, name);
    } catch (err) {
        errorEl.textContent = err.message || 'Signup failed';
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Create Account';
    }
};

window.handleAuthLogout = async function() {
    await ScreencordAuth.logout();
};

window.toggleAuthMode = function() {
    const loginGroup = document.getElementById('auth-login-group');
    const signupGroup = document.getElementById('auth-signup-group');
    const nameField = document.getElementById('auth-name-field');
    const toggleText = document.getElementById('auth-toggle-text');
    const errorEl = document.getElementById('auth-error');
    const successEl = document.getElementById('auth-success');

    if (errorEl) errorEl.style.display = 'none';
    if (successEl) successEl.style.display = 'none';

    if (loginGroup.style.display !== 'none') {
        loginGroup.style.display = 'none';
        signupGroup.style.display = 'flex';
        nameField.style.display = 'block';
        toggleText.innerHTML = 'Already have an account? <a href="#" onclick="toggleAuthMode(); return false;">Sign in</a>';
    } else {
        loginGroup.style.display = 'flex';
        signupGroup.style.display = 'none';
        nameField.style.display = 'none';
        toggleText.innerHTML = 'Don\'t have an account? <a href="#" onclick="toggleAuthMode(); return false;">Sign up</a>';
    }
};

// ─── Guest Join ───
window.guestJoinSession = function() {
    ScreencordAuth.enterGuestMode();
    // Navigate to record view but immediately show join modal
    if (typeof navigate === 'function') navigate('record');
    if (typeof setUIRole === 'function') setUIRole('viewer');
    // Small delay to ensure DOM is ready after showApp()
    setTimeout(() => {
        if (typeof showJoinModal === 'function') showJoinModal();
    }, 100);
};

// ─── Credits & Upgrades ───
window.showCreditsModal = function() {
    showToast('Credit history & plan details coming soon', 'info');
};

window.openUpgradeModal = async function() {
    const modal = document.getElementById('upgrade-modal');
    if (!modal) return;
    
    modal.style.display = 'flex';
    const grid = document.getElementById('upgrade-plans-grid');
    if (!grid) return;

    try {
        const plans = await window.ScreencordAuth.apiFetch('/api/plans');
        const currentPlan = window.ScreencordAuth.currentUser?.plan || 'starter';

        grid.innerHTML = plans.map(p => {
            const isCurrent = p.plan_name === currentPlan;
            const isRecommended = p.plan_name === 'pro';
            const accentColor = p.plan_name === 'business' ? 'var(--purple)' : (isRecommended ? 'var(--blue)' : 'var(--text-3)');
            const bgClass = isRecommended ? 'var(--btn-ghost-bg)' : 'var(--surface-1)';
            const border = isCurrent ? '2px solid var(--border)' : (isRecommended ? '2px solid var(--blue)' : '2px solid var(--border)');
            const displayName = p.plan_name.charAt(0).toUpperCase() + p.plan_name.slice(1);
            
            const description = p.plan_name === 'starter' 
                ? 'Basic recording and live features. Perfect for beginners.' 
                : (p.plan_name === 'pro' ? 'Includes Scheduling and Events. Great for professionals.' : 'Maximum capacity for teams and production.');

            return `
                <div style="background:${bgClass}; border: ${border}; border-radius: 20px; padding: 32px; display:flex; flex-direction:column; position:relative; ${isRecommended ? 'box-shadow: 0 20px 40px rgba(59,130,246,0.15);' : ''}">
                    ${isRecommended ? `<div style="position:absolute; top: -14px; right: 24px; background: var(--blue); color:white; padding: 4px 16px; border-radius: 20px; font-size: 0.75rem; font-weight:800; letter-spacing:0.05em;">RECOMMENDED</div>` : ''}
                    <div class="plan-badge ${p.plan_name}" style="width:fit-content; margin-bottom:16px;">${displayName.toUpperCase()}</div>
                    <div style="font-size: 2.5rem; font-weight:800; margin-bottom:8px; color:${accentColor === 'var(--text-3)' ? 'var(--text-1)' : accentColor}">
                        ${p.price || '$0'} 
                        <small style="font-size:0.9rem; font-weight:600; color:var(--text-3)">/mo</small>
                    </div>
                    <p style="font-size: 0.9rem; color:var(--text-2); margin-bottom:24px;">
                        ${description}
                    </p>
                    <div style="flex:1; margin-bottom:32px;">
                        <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:12px;">
                            <li style="display:flex; align-items:center; gap:10px; font-size:0.95rem; color:var(--text-1); font-weight:600;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${accentColor}" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> 
                                ${p.monthly_credits} Monthly Credits
                            </li>
                            ${p.modules.includes('schedule') ? `
                                <li style="display:flex; align-items:center; gap:10px; font-size:0.95rem; color:var(--text-1); font-weight:600;">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${accentColor}" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> 
                                    Scheduled Watch Parties
                                </li>
                            ` : ''}
                            ${p.modules.includes('admin') ? `
                                <li style="display:flex; align-items:center; gap:10px; font-size:0.95rem; color:var(--text-1); font-weight:600;">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${accentColor}" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> 
                                    Admin Dashboard Access
                                </li>
                            ` : ''}
                            <li style="display:flex; align-items:center; gap:10px; font-size:0.95rem; color:var(--text-1); font-weight:600;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${accentColor}" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> 
                                Priority AI Processing
                            </li>
                        </ul>
                    </div>
                    ${isCurrent ? `
                        <button class="btn btn--outline" style="width:100%; justify-content:center; opacity:0.7;" disabled>Current Plan</button>
                    ` : `
                        <button id="btn-request-${p.plan_name}" class="btn ${isRecommended ? 'btn--primary' : 'btn--outline'}" style="width:100%; justify-content:center; padding: 14px;" onclick="ScreencordAuth.submitUpgradeRequest('${p.plan_name}')">
                            Request ${displayName} Upgrade
                        </button>
                    `}
                </div>
            `;
        }).join('');
    } catch (err) {
        grid.innerHTML = `<p style="padding:40px; text-align:center; color:var(--text-error); width:100%; grid-column: 1 / -1">Failed to load plans: ${err.message}</p>`;
    }
};

window.closeUpgradeModal = function() {
    const modal = document.getElementById('upgrade-modal');
    if (modal) modal.style.display = 'none';
};

window.requestUpgrade = function() {
    window.openUpgradeModal();
};

ScreencordAuth.submitUpgradeRequest = async function(plan) {
    const btn = document.getElementById(`btn-request-${plan}`);
    const originalText = btn ? btn.textContent : 'Request Upgrade';
    
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Sending...';
    }

    try {
        await this.apiFetch('/api/upgrade-request', {
            method: 'POST',
            body: JSON.stringify({ plan })
        });
        showToast(`Upgrade request for ${plan.toUpperCase()} submitted! An admin will review it.`, 'success');
        window.closeUpgradeModal();
    } catch (err) {
        showToast(err.message || 'Failed to submit request.', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    }
};

window.checkUseCredits = async function(amount, reason) {
    if (window.ScreencordAuth.isGuest) {
        showToast('Please sign in to use this feature.', 'warning');
        return false;
    }
    
    try {
        const res = await window.ScreencordAuth.apiFetch('/api/credits/use', {
            method: 'POST',
            body: JSON.stringify({ amount, reason })
        });
        
        // Update local credits display
        if (res.credits !== undefined) {
            window.ScreencordAuth.currentUser.credits = res.credits;
            const creditsCountEl = document.getElementById('credits-count');
            const userCreditsInfoEl = document.getElementById('user-credits-info');
            if (creditsCountEl) creditsCountEl.textContent = res.credits;
            if (userCreditsInfoEl) userCreditsInfoEl.textContent = `${res.credits} credits remaining`;
        }
        return true;
    } catch (err) {
        showToast(`Insufficient credits (${amount} required). Please request an upgrade.`, 'error');
        return false;
    }
};

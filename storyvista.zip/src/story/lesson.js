'use strict';

const Anthropic = require('@anthropic-ai/sdk');
const { retrieveBlocks, buildContext } = require('./retriever');
const { resolveMedia } = require('../media/index');
const { narrateLesson } = require('../voice/tts');
const { saveLesson } = require('../storage/generations');
const logger = require('../utils/logger');
const path = require('path');
const fs = require('fs');

let _claude = null;
function claude() {
  if (!_claude) _claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return _claude;
}

const LESSON_SYSTEM = `You are the Story Vista lesson generation engine. You create structured, visual, narration-ready lessons for educators.

CRITICAL RULES:
- Ground every fact in the provided KNOWLEDGE BLOCKS — never invent content
- Each section must map to a learning objective
- Include visual scene descriptions for each concept (used to generate images)
- Write narration scripts as if spoken aloud by a teacher
- Discussion questions must be thought-provoking and open-ended

OUTPUT: Valid JSON only. No markdown. No preamble.`;

function buildLessonPrompt(request, context) {
  const { topic, ageBand, subject, duration, curriculumNote } = request;
  return `Create an educational lesson about: "${topic}"
Target age band: ${ageBand}
Subject area: ${subject || 'general'}
Lesson duration: ${duration || 20} minutes
${curriculumNote ? `Curriculum alignment: ${curriculumNote}` : ''}

KNOWLEDGE BLOCKS (use ONLY these facts):
${context}

Return JSON with this structure:
{
  "title": "lesson title",
  "subject": "subject area",
  "ageBand": "${ageBand}",
  "duration": ${duration || 20},
  "learningObjectives": ["By the end of this lesson, students will be able to..."],
  "sections": [
    {
      "sectionNumber": 1,
      "title": "section title",
      "type": "introduction|concept|activity|review",
      "narrationScript": "what the teacher says aloud",
      "conceptBreakdown": ["step 1", "step 2"],
      "imageHint": "description of the visual for this section (15-20 words)",
      "duration": 5
    }
  ],
  "discussionQuestions": ["question 1", "question 2", "question 3"],
  "keyVocabulary": [{ "term": "...", "definition": "..." }],
  "factsUsed": ["fact 1", "fact 2"],
  "sources": [{ "name": "...", "url": "..." }],
  "topic": "${topic}"
}`;
}

const Groq = require('groq-sdk');
let _groq = null;
function groq() {
  if (!_groq) _groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  return _groq;
}

/**
 * Generate a complete lesson plan with text + images
 *
 * @param {Object} request
 * @param {string} request.topic
 * @param {string} request.ageBand
 * @param {string} [request.subject]
 * @param {number} [request.duration]     - lesson length in minutes
 * @param {string} [request.region]
 * @param {boolean}[request.withImages]
 * @returns {Promise<Lesson>}
 */
async function generateLesson(request) {
  const {
    topic,
    subject,
    ageBand = '9-12',
    region = 'ng',
    withImages = true,
    withAudio = false,
    voiceId,
  } = request;

  logger.info(`[LessonGen] Generating lesson — topic="${topic}" subject="${subject || 'any'}" age="${ageBand}" (Default: Groq)`);

  // 1. Retrieve knowledge blocks with subject filter
  const blocks = await retrieveBlocks({
    topic,
    ageBand,
    subjects: subject ? [subject] : [],
    limit: 5
  });

  let lesson;
  let mode = 'rag';

  if (blocks.length === 0) {
    logger.info(`[LessonGen] No knowledge blocks found for topic: "${topic}". Falling back to broad generative knowledge.`);
    mode = 'generic';
  }

  const context = buildContext(blocks, ageBand);

  // Dynamic system prompt: if we have no blocks, allow general knowledge
  const systemPrompt = mode === 'generic'
    ? LESSON_SYSTEM.replace('Ground every fact in the provided KNOWLEDGE BLOCKS — never invent content', 'Knowledge blocks are unavailable for this specific topic; please use your general educational knowledge while maintaining accurate, safe, and structured output.')
    : LESSON_SYSTEM;

  try {
    // ── Try Groq first (extremely fast) ──
    const model = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
    const response = await groq().chat.completions.create({
      model,
      max_tokens: 4096,
      temperature: 0.4,
      response_format: { type: "json_object" },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: buildLessonPrompt(request, context) }
      ],
    });

    const raw = response.choices[0]?.message?.content || '';
    lesson = JSON.parse(raw);
  } catch (err) {
    logger.warn(`[LessonGen] Groq failed. Falling back to Claude: ${err.message}`);
    
    // ── Fallback to Claude ──
    try {
      const model = process.env.CLAUDE_MODEL || 'claude-opus-4-5';
      const response = await claude().messages.create({
        model,
        max_tokens: 4096,
        temperature: 0.4,
        system: systemPrompt,
        messages: [{ role: 'user', content: buildLessonPrompt(request, context) }],
      });

      const raw = response.content[0]?.text || '';
      const clean = raw.replace(/^```(?:json)?\n?/m, '').replace(/\n?```$/m, '').trim();
      lesson = JSON.parse(clean);
    } catch (fErr) {
      logger.error(`[LessonGen] All models failed: ${fErr.message}`);
      throw new Error(`Generation failed across all providers: ${fErr.message}`);
    }
  }

  // Resolve images for each section
  if (withImages) {
    // If we have no blocks, use a pseudo-block for the image resolver
    const imageBlock = blocks.length > 0 ? blocks[0] : {
      id: 'gen_lesson_' + Date.now(),
      topic: lesson.topic || topic,
      summary: lesson.title || topic
    };

    const sectionsWithMedia = await Promise.all(
      (lesson.sections || []).map(async (section, idx) => {
        const media = await resolveMedia(imageBlock, 'lesson', ageBand, region, section.imageHint, idx);
        return { ...section, media };
      })
    );
    lesson.sections = sectionsWithMedia;
  }

  // ── 5. Generate Narration ──────────────────────────────────────
  if (withAudio) {
    logger.info(`[LessonGen] Generating full audio narration for lesson: "${lesson.title}"`);
    const audioDir = path.join(__dirname, '../frontend/public/audio');
    if (!fs.existsSync(audioDir)) {
      fs.mkdirSync(audioDir, { recursive: true });
    }
    
    // Create a unique folder for this lesson
    const lessonId = 'lesson_' + Date.now();
    const lessonAudioDir = path.join(audioDir, lessonId);
    fs.mkdirSync(lessonAudioDir);
    
    const audioResults = await narrateLesson(lesson, voiceId, lessonAudioDir, false);
    
    audioResults.forEach(res => {
      if (!res.error && res.fileName) {
        const url = `/audio/${lessonId}/${res.fileName}`;
        if (res.type === 'full') {
          lesson.introAudioUrl = url;
        } else if (res.type === 'intro') {
          lesson.introAudioUrl = url;
        } else if (res.type === 'section') {
          const section = lesson.sections.find(s => s.sectionNumber === res.sectionNumber);
          if (section) section.audioUrl = url;
        }
      }
    });
  }

  lesson._meta = {
    generatedAt: new Date().toISOString(),
    blocksUsed: blocks.map((b) => ({ id: b.id, topic: b.topic })),
    region,
    mode,
  };

  logger.info(`[LessonGen] ✓ Lesson complete: "${lesson.title}"`);

  // ── 7. Save to library ────────────────────────────────────────
  const saved = await saveLesson(lesson);
  if (saved) {
    lesson.id = saved.id;
    lesson.created_at = saved.created_at;
  }

  return lesson;
}

module.exports = { generateLesson };

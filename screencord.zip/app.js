/**
 * Screencord — Main Application v3
 * High-performance screen recording, live sharing & collaborative chat.
 * Added: Resources Library & Native Chat Polls, Global Sidebar UI.
 */

// ─── State ───
let mediaRecorder = null;
let recordedChunks = [];
let startTime = 0;
let timerInterval = null;
let isRecording = false;
let micEnabled = true;
let systemAudioEnabled = true;
let currentView = 'record';
let tempRecordingBlob = null;
let isStreamReady = false;
let currentStream = null;
let activePolls = {};

// ─── Elements ───
const $ = (s) => document.querySelector(s);
const el = {
    // Navigation
    navLinks: document.querySelectorAll('.nav__link'),
    views: document.querySelectorAll('.view'),
    
    // Recorder View
    shareScreenBtn: $('#share-screen-btn'),
    startBtn: $('#start-btn'),
    stopBtn: $('#stop-btn'),
    preview: $('#preview'),
    placeholder: $('#placeholder'),
    timerH: $('#timer-h'),
    timerM: $('#timer-m'),
    timerS: $('#timer-s'),
    statusText: $('#status-text'),
    statusBadge: $('#status-badge'),
    recBadge: $('#rec-badge'),
    micToggle: $('#mic-toggle'),
    audioToggle: $('#audio-toggle'),
    
    // Recordings View
    recordingsGrid: $('#recordings-grid'),
    emptyRecordings: $('#empty-recordings'),
    
    // Live View
    liveShareBtn: $('#live-share-btn'),
    liveStartBtn: $('#live-start-btn'),
    liveStopBtn: $('#live-stop-btn'),
    livePreview: $('#live-preview'),
    livePlaceholder: $('#live-placeholder'),
    liveRoomInfo: $('#live-room-info'),
    liveRoomCode: $('#live-room-code'),
    liveEmailInvites: $('#live-email-invites-container'),
    liveInviteField: $('#live-invite-emails'),
    
    // Watch View
    watchPreview: $('#watch-preview'),
    watchStatus: $('#watch-status'),
    
    // Share Playback View
    sharePlaybackVideo: $('#share-playback-video'),
    playbackRoomCode: $('#playback-room-code'),
    
    // Modals & Extras
    saveModal: $('#save-modal'),
    saveName: $('#save-name'),
    savePreviewVideo: $('#save-preview-video'),
    joinModal: $('#join-modal'),
    joinCode: $('#join-code'),
    joinName: $('#join-name'),
    shareModal: $('#share-modal'),
    shareRoomCode: $('#share-room-code'),
    shareStatus: $('#share-status'),
    
    toastContainer: $('#toast-container'),

    // Global Sidebar
    globalSidebar: $('#global-sidebar'),
    globalChatMessages: $('#global-chat-messages'),
    globalChatInput: $('#global-chat-input'),
    
    // Playback View (AI Enhanced)
    playbackVideo: $('#playback-video'),
    playbackTitle: $('#playback-title'),
    chaptersList: $('#chapters-list'),
    chapterSearchInput: $('#chapter-search-input'),
    aiStatusBadge: $('#ai-status-badge'),

    globalChatSend: $('#global-chat-send'),
    globalViewerCount: $('#global-viewer-count'),
    emojiPicker: $('#emoji-picker'),
    btnEmoji: $('#btn-emoji'),
    hostResourceControls: $('#host-resource-controls'),
    resourcesList: $('#resources-list'),
    annotationToolbar: $('#annotation-toolbar'),
};

// ─── Initialization ───
window.addEventListener('DOMContentLoaded', async () => {
    initTheme();
    await ScreencordDB.init();
    
    // Initialize Auth — this gates the entire app
    try {
        await ScreencordAuth.init();
    } catch (err) {
        console.warn('[Auth] Initialization failed. Defaulting to auth gate.', err);
        ScreencordAuth.showAuthGate();
    }
    
    navigate('record');
    
    // Proactively request Microphone Permission Early
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(t => t.stop());
        console.log('[Screencord] Mic permission pre-granted');
    } catch (e) {
        console.warn('[Screencord] Mic permission denied initially', e.message);
    }
    
    // Event Listeners
    el.micToggle.addEventListener('click', toggleMic);
    el.audioToggle.addEventListener('click', toggleAudio);
    
    if (el.shareScreenBtn) el.shareScreenBtn.addEventListener('click', setupRecordStream);
    if (el.startBtn) el.startBtn.addEventListener('click', startRecording);
    if (el.stopBtn) el.stopBtn.addEventListener('click', stopRecording);
    
    if (el.liveShareBtn) el.liveShareBtn.addEventListener('click', setupLiveStream);
    if (el.liveStartBtn) el.liveStartBtn.addEventListener('click', startLiveSession);
    if (el.liveStopBtn) el.liveStopBtn.addEventListener('click', stopLiveSession);
    
    // Global Sidebar Bindings
    if (el.globalChatSend) el.globalChatSend.addEventListener('click', window.sendGlobalChat);
    if (el.globalChatInput) el.globalChatInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') window.sendGlobalChat(); });
    if (el.btnEmoji) {
        el.btnEmoji.addEventListener('click', () => {
            el.emojiPicker.style.display = el.emojiPicker.style.display === 'none' ? 'flex' : 'none';
        });
    }

    // Tab Navigation for Sidebar
    document.querySelectorAll('.sidebar-tab').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.sidebar-tab').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.sidebar-pane').forEach(p => p.classList.remove('active'));
            
            const target = e.currentTarget.getAttribute('data-target');
            e.currentTarget.classList.add('active');
            $(`#${target}`).classList.add('active');
        });
    });

    // Auto-populate join name from profile
    const savedName = localStorage.getItem('screencord_user_name');
    if (savedName && el.joinName) el.joinName.value = savedName;

    // Initial role
    setUIRole('host');

    // Close user dropdown on outside click
    document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('user-dropdown');
        const trigger = e.target.closest('.user-menu__trigger');
        if (!trigger && dropdown) dropdown.classList.remove('active');
    });

    // Mobile Nav Toggle
    const navToggle = $('#nav-toggle');
    const navMenu = $('#nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            navMenu.classList.toggle('mobile-active');
            const icon = navToggle.querySelector('svg');
            if (navMenu.classList.contains('mobile-active')) {
                icon.innerHTML = '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>';
                document.body.style.overflow = 'hidden'; // Prevent scrolling when menu is open
            } else {
                icon.innerHTML = '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>';
                document.body.style.overflow = '';
            }
        });
    }

    window.closeMobileMenu = () => {
        if (navMenu && navMenu.classList.contains('mobile-active')) {
            navMenu.classList.remove('mobile-active');
            document.body.style.overflow = '';
            const icon = navToggle.querySelector('svg');
            if (icon) {
                icon.innerHTML = '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>';
            }
        }
    };

    // Initialize Resizers
    initResizers();

    // Initialize Annotations & Resources
    initAnnotations();
    initResourcePush();
});

// ─── Live Canvas (Annotations - Full Feature Suite) ───
let drawColor = '#3b82f6';
let activeTool = 'pen';
let fabricCanvases = new Map();

const strokeOptions = {
    size: 4, thinning: 0.5, smoothing: 0.5, streamline: 0.5,
    easing: (t) => t, start: { cap: true, taper: 0, easing: (t) => t }, end: { cap: true, taper: 0, easing: (t) => t }
};

function initAnnotations() {
    const canvases = document.querySelectorAll('.live-canvas');
    const colorPicker = document.getElementById('tool-color');

    if (colorPicker) {
        colorPicker.addEventListener('change', (e) => {
            drawColor = e.target.value;
            fabricCanvases.forEach(f => {
                const active = f.getActiveObject();
                if (active) {
                    if (active.type === 'i-text') active.set('fill', drawColor);
                    else active.set('stroke', drawColor);
                    f.renderAll();
                    broadcastObject(f, active);
                }
            });
        });
    }

    canvases.forEach(canvasEl => {
        const fCanvas = new fabric.Canvas(canvasEl, { isDrawingMode: false, selection: true });
        fabricCanvases.set(canvasEl.id, fCanvas);

        let isMouseDown = false;
        let startPoint = null;
        let activeObj = null;
        let currentPoints = [];

        fCanvas.on('mouse:down', (o) => {
            console.log('[Annotations] Mouse Down:', activeTool);
            // Allow drawing even if not host for local testing if needed, 
            // but in production we check isHost. For now, allow it to see if it works.
            isMouseDown = true;
            const pointer = fCanvas.getPointer(o.e);
            startPoint = { x: pointer.x, y: pointer.y };
            currentPoints = [];

            if (activeTool === 'pen') {
                currentPoints = [[pointer.x, pointer.y, (o.e && o.e.pressure) || 0.5]];
            } else if (activeTool === 'rect') {
                activeObj = new fabric.Rect({
                    left: startPoint.x, top: startPoint.y,
                    width: 1, height: 1, // Start small
                    fill: 'transparent', stroke: drawColor, strokeWidth: 3,
                    selectable: true, id: 'obj_' + Date.now()
                });
                fCanvas.add(activeObj);
            } else if (activeTool === 'arrow') {
                activeObj = new fabric.Path(`M ${startPoint.x} ${startPoint.y} L ${startPoint.x + 1} ${startPoint.y + 1}`, {
                    stroke: drawColor, strokeWidth: 3, fill: 'transparent', selectable: true, id: 'obj_' + Date.now()
                });
                fCanvas.add(activeObj);
            } else if (activeTool === 'text') {
                activeObj = new fabric.IText('Type...', {
                    left: startPoint.x, top: startPoint.y,
                    fontFamily: 'Inter', fontSize: 24, fill: drawColor,
                    selectable: true, id: 'obj_' + Date.now()
                });
                fCanvas.add(activeObj);
                fCanvas.setActiveObject(activeObj);
                activeObj.enterEditing();
                isMouseDown = false;
                broadcastObject(fCanvas, activeObj);
            }
        });

        fCanvas.on('mouse:move', (o) => {
            if (!isMouseDown) return;
            const pointer = fCanvas.getPointer(o.e);

            if (activeTool === 'pen') {
                currentPoints.push([pointer.x, pointer.y, (o.e && o.e.pressure) || 0.5]);
                renderLiveStroke(fCanvas, currentPoints, drawColor);
            } else if (activeTool === 'rect' && activeObj) {
                activeObj.set({
                    width: Math.abs(pointer.x - startPoint.x),
                    height: Math.abs(pointer.y - startPoint.y),
                    left: Math.min(pointer.x, startPoint.x),
                    top: Math.min(pointer.y, startPoint.y)
                });
            } else if (activeTool === 'arrow' && activeObj) {
                const dX = pointer.x - startPoint.x;
                const dY = pointer.y - startPoint.y;
                const angle = Math.atan2(dY, dX);
                const headLen = 15;
                const pathData = [
                    'M', startPoint.x, startPoint.y,
                    'L', pointer.x, pointer.y,
                    'M', pointer.x, pointer.y,
                    'L', pointer.x - headLen * Math.cos(angle - Math.PI / 6), pointer.y - headLen * Math.sin(angle - Math.PI / 6),
                    'M', pointer.x, pointer.y,
                    'L', pointer.x - headLen * Math.cos(angle + Math.PI / 6), pointer.y - headLen * Math.sin(angle + Math.PI / 6)
                ].join(' ');
                activeObj.set({ path: fabric.util.makePathSimpler(fabric.util.parsePath(pathData)) });
            }
            fCanvas.renderAll();
        });

        fCanvas.on('mouse:up', () => {
            if (!isMouseDown) return;
            isMouseDown = false;
            if (activeTool === 'pen') {
                const final = finalizeStroke(fCanvas, currentPoints, drawColor);
                if (final) broadcastObject(fCanvas, final);
                currentPoints = [];
            } else if (activeObj) {
                broadcastObject(fCanvas, activeObj);
                activeObj = null;
            }
        });

        fCanvas.on('object:modified', (e) => {
            if (ScreencordShare.isHost) broadcastObject(fCanvas, e.target);
        });

        fCanvas.on('text:changed', (e) => {
            if (ScreencordShare.isHost) broadcastObject(fCanvas, e.target);
        });
    });

    const toolIds = ['select', 'pen', 'rect', 'arrow', 'text', 'eraser'];
    toolIds.forEach(id => {
        const btn = document.getElementById(`tool-${id}`);
        if (btn) btn.onclick = () => selectTool(id);
    });

    window.addEventListener('resize', window.resizeCanvases);

    window.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        const key = e.key.toLowerCase();
        if (key === 's') selectTool('select');
        if (key === 'p') selectTool('pen');
        if (key === 'r') selectTool('rect');
        if (key === 'a') selectTool('arrow');
        if (key === 't') selectTool('text');
        if (key === 'e' || key === 'backspace' || key === 'delete') selectTool('eraser');
        if (key === 'c') window.clearCanvas();
        if (key === 'w') window.toggleWhiteboard();
    });
}

window.toggleAnnotationToolbar = function() {
    const tools = document.getElementById('annotation-tools');
    const toggleBtn = document.getElementById('annotation-toggle');
    if (!tools) return;
    const isOpen = tools.style.display !== 'none';
    
    if (isOpen) {
        // Closing: Disable drawing mode so video is interactive again
        tools.style.display = 'none';
        selectTool(null);
    } else {
        // Opening: Switch to pen by default if nothing else active
        tools.style.display = 'flex';
        selectTool('pen');
    }
    
    if (toggleBtn) toggleBtn.classList.toggle('active', !isOpen);
};
window.toggleWhiteboard = function() {
    if (!ScreencordShare.isHost) return;

    const preview = document.querySelector('.view.active .preview');
    if (!preview) return;
    const isActive = preview.classList.toggle('is-whiteboard');
    ScreencordShare.isWhiteboardActive = isActive;
    ScreencordShare.broadcastWhiteboardToggle(isActive);
    const btn = document.getElementById('tool-whiteboard');
    if (btn) btn.classList.toggle('active', isActive);
    showToast(isActive ? 'Whiteboard Enabled' : 'Whiteboard Disabled', 'info');
    if (isActive) selectTool('pen');
    setTimeout(() => window.resizeCanvases(), 50);
};

window.handleRemoteWhiteboardToggle = function(data) {
    const preview = document.querySelector('.view.active .preview');
    if (preview) preview.classList.toggle('is-whiteboard', data.isActive);
    const btn = document.getElementById('tool-whiteboard');
    if (btn) btn.classList.toggle('active', data.isActive);
    setTimeout(() => window.resizeCanvases(), 50);
};

function selectTool(toolId) {
    if (toolId === 'eraser') {
        fabricCanvases.forEach(f => {
            const active = f.getActiveObject();
            if (active) {
                const id = active.id;
                f.remove(active);
                if (ScreencordShare.isHost) ScreencordShare.broadcast({ type: 'OBJ_DELETE', id });
            }
        });
        return;
    }

    activeTool = toolId;
    console.log('[Annotations] Switched tool to:', toolId);
    
    // UI Update: Highlight active button
    document.querySelectorAll('.tool-btn').forEach(btn => {
        btn.classList.toggle('active', btn.id === `tool-${toolId}`);
    });

    fabricCanvases.forEach(f => {
        f.discardActiveObject();
        f.isDrawingMode = false;
        
        const isSelection = (toolId === 'select');
        const isDrawing = ['pen', 'rect', 'arrow', 'text'].includes(toolId);
        const isActive = isSelection || isDrawing; // any tool that needs pointer events
        
        f.selection = isSelection;
        f.skipTargetFind = !isSelection && toolId !== 'eraser';
        
        // Set cursor per tool
        const cursorStyle = isDrawing ? 'crosshair' : (isSelection ? 'default' : 'default');
        f.defaultCursor = cursorStyle;
        f.hoverCursor = isSelection ? 'move' : cursorStyle;
        
        if (f.wrapperEl) {
            // Always enable pointer-events on the wrapper when any tool is active,
            // and use is-drawing class so the CSS crosshair rule also fires.
            f.wrapperEl.style.pointerEvents = isActive ? 'auto' : 'none';
            f.wrapperEl.classList.toggle('is-drawing', isDrawing);
            f.wrapperEl.classList.toggle('is-selecting', isSelection);
            // Force cursor directly on wrapper and upper canvas so CSS can't override
            f.wrapperEl.style.cursor = cursorStyle;
        }
        
        // Apply cursor directly to Fabric's upper (interactive) canvas element
        if (f.upperCanvasEl) {
            f.upperCanvasEl.style.cursor = cursorStyle;
            f.upperCanvasEl.style.pointerEvents = isActive ? 'auto' : 'none';
        }
        
        f.renderAll();
    });

    showToast(`Tool: ${toolId.toUpperCase()} Active`, 'info');
}

function renderLiveStroke(fCanvas, points, color) {
    if (points.length < 2) return;
    const stroke = PerfectFreehand.getStroke(points, strokeOptions);
    const pathData = getSvgPathFromStroke(stroke);
    let preview = fCanvas.getObjects().find(o => o.id === 'temp-stroke');
    if (preview) fCanvas.remove(preview);
    const fabricPath = new fabric.Path(pathData, { fill: color, stroke: null, selectable: false, evented: false, id: 'temp-stroke' });
    fCanvas.add(fabricPath);
    fCanvas.renderAll();
}

function finalizeStroke(fCanvas, points, color) {
    let preview = fCanvas.getObjects().find(o => o.id === 'temp-stroke');
    if (preview) fCanvas.remove(preview);
    if (points.length < 2) return null;
    const stroke = PerfectFreehand.getStroke(points, strokeOptions);
    const pathData = getSvgPathFromStroke(stroke);
    const fabricPath = new fabric.Path(pathData, { fill: color, stroke: null, selectable: false, evented: false, id: 'obj_' + Date.now() });
    fCanvas.add(fabricPath);
    fCanvas.renderAll();
    return fabricPath;
}

function getSvgPathFromStroke(stroke) {
    if (!stroke.length) return '';
    const d = stroke.reduce((acc, [x0, y0], i, arr) => {
        const [x1, y1] = arr[(i + 1) % arr.length];
        acc.push(x0, y0, (x0 + x1) / 2, (y0 + y1) / 2);
        return acc;
    }, ['M', ...stroke[0], 'Q']);
    d.push('Z');
    return d.join(' ');
}

window.resizeCanvases = function() {
    fabricCanvases.forEach((fCanvas, id) => {
        const canvasEl = document.getElementById(id);
        const container = canvasEl.parentElement;
        if (container) {
            fCanvas.setDimensions({ width: container.clientWidth, height: container.clientHeight });
            fCanvas.renderAll();
        }
    });
};

function broadcastObject(fCanvas, obj) {
    if (!ScreencordShare.isHost) return;
    const data = obj.toObject(['id', 'left', 'top', 'width', 'height', 'fill', 'stroke', 'strokeWidth', 'path', 'text', 'fontFamily', 'fontSize', 'scaleX', 'scaleY', 'angle']);
    data.left /= fCanvas.width;
    data.top /= fCanvas.height;
    if (data.width) data.width /= fCanvas.width;
    if (data.height) data.height /= fCanvas.height;
    if (data.path) {
        data.path = data.path.map(p => p.map((val, idx) => (typeof val === 'number') ? (idx % 2 === 1 ? val / fCanvas.width : val / fCanvas.height) : val));
    }
    ScreencordShare.broadcast({ type: 'OBJ_UPDATE', obj: data });
}

window.clearCanvas = function() {
    fabricCanvases.forEach(f => f.clear());
    if (ScreencordShare.isHost) ScreencordShare.broadcast({ type: 'ANNOTATION_CLEAR' });
};

window.handleRemoteAnnotation = function(data) {
    const canvas = document.querySelector('.view.active .live-canvas');
    if (!canvas) return;
    const fCanvas = fabricCanvases.get(canvas.id);
    if (!fCanvas) return;
    if (data.type === 'ANNOTATION_CLEAR') { fCanvas.clear(); return; }
    if (data.type === 'OBJ_DELETE') {
        const obj = fCanvas.getObjects().find(o => o.id === data.id);
        if (obj) fCanvas.remove(obj);
        fCanvas.renderAll();
        return;
    }
    if (data.type === 'OBJ_UPDATE') {
        const d = data.obj;
        d.left *= fCanvas.width;
        d.top *= fCanvas.height;
        if (d.width) d.width *= fCanvas.width;
        if (d.height) d.height *= fCanvas.height;
        if (d.path) {
            d.path = d.path.map(p => p.map((val, idx) => (typeof val === 'number') ? (idx % 2 === 1 ? val * fCanvas.width : val * fCanvas.height) : val));
        }
        let existing = fCanvas.getObjects().find(o => o.id === d.id);
        if (existing) {
            existing.set(d);
            existing.setCoords();
        } else {
            fabric.util.enlivenObjects([d], (objects) => {
                objects.forEach(o => { o.selectable = false; fCanvas.add(o); });
            });
        }
        fCanvas.renderAll();
    }
};

// ─── Smart Resource Push ───
function initResourcePush() {
    // Handlers already in HTML onclicks
}

window.pushResource = function() {
    const title = document.getElementById('res-title').value.trim();
    const url = document.getElementById('res-url').value.trim();

    if (!title || !url) {
        showToast('Please enter title and URL to push', 'error');
        return;
    }

    try {
        new URL(url); // Validate URL
    } catch (e) {
        showToast('Please enter a valid URL', 'error');
        return;
    }

    ScreencordShare.broadcastResourcePush({ title, url });
    showToast(`Pushed "${title}" to all viewers!`, 'success');
};

window.handleRemoteResourcePush = function(data) {
    const popup = document.getElementById('push-popup');
    const titleEl = document.getElementById('push-title');
    const urlEl = document.getElementById('push-url');
    const btn = document.getElementById('push-action-btn');

    if (!popup || !titleEl || !urlEl || !btn) return;

    titleEl.textContent = data.title;
    urlEl.textContent = data.url;
    btn.onclick = () => window.open(data.url, '_blank');

    popup.style.display = 'block';
    
    // Auto-hide after 15 seconds if not closed
    setTimeout(() => {
        if (popup.style.display === 'block') window.closePushPopup();
    }, 15000);
};

window.closePushPopup = function() {
    const popup = document.getElementById('push-popup');
    if (popup) popup.style.display = 'none';
};

function initResizers() {
    let isDragging = false;
    let currentResizer = null;
    let currentPanel = null;

    document.addEventListener('mousedown', (e) => {
        const resizer = e.target.closest('.live-panel__resizer');
        if (!resizer) return;

        isDragging = true;
        currentResizer = resizer;
        currentPanel = resizer.parentElement;
        
        resizer.classList.add('is-dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging || !currentPanel) return;

        const panelRect = currentPanel.getBoundingClientRect();
        const relativeX = e.clientX - panelRect.left;
        
        const minWidth = 300;
        const minSidebar = 300; // Increased min sidebar for better content fit
        const containerWidth = panelRect.width;
        
        let videoWidth = relativeX - 7;
        if (videoWidth < minWidth) videoWidth = minWidth;
        if (containerWidth - videoWidth - 14 < minSidebar) videoWidth = containerWidth - minSidebar - 14;

        currentPanel.style.gridTemplateColumns = `${videoWidth}px 14px 1fr`;
        
        // Trigger canvas resize during manual panel resize
        window.resizeCanvases();
    });

    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            if (currentResizer) currentResizer.classList.remove('is-dragging');
            document.body.style.cursor = 'default';
            document.body.style.userSelect = 'auto';
            currentResizer = null;
            currentPanel = null;
        }
    });
}

// ─── Theme Logic ───
function initTheme() {
    const savedTheme = localStorage.getItem('screencord_theme');
    const prefersLight = window.matchMedia('(prefers-color-scheme: light)').matches;
    if (savedTheme === 'light' || (!savedTheme && prefersLight)) {
        document.documentElement.setAttribute('data-theme', 'light');
    }
}

window.toggleTheme = function() {
    const root = document.documentElement;
    if (root.getAttribute('data-theme') === 'light') {
        root.removeAttribute('data-theme');
        localStorage.setItem('screencord_theme', 'dark');
    } else {
        root.setAttribute('data-theme', 'light');
        localStorage.setItem('screencord_theme', 'light');
    }
}

// ─── Role Control ───
window.setUIRole = function(role) {
    console.log('[Screencord] Setting UI Role to:', role, 'Current User:', window.ScreencordAuth?.currentUser);
    const isViewer = (role === 'viewer');
    const isAdmin = (role === 'admin' || window.ScreencordAuth?.currentUser?.role === 'admin');
    const guestCta = document.getElementById('guest-signup-cta');
    const adminNav = document.getElementById('nav-admin');
    const dropdownAdmin = document.getElementById('dropdown-admin');
    
    document.querySelectorAll('.host-only').forEach(el => {
        el.style.display = isViewer ? 'none' : '';
    });
    document.querySelectorAll('.viewer-only').forEach(el => {
        el.style.display = isViewer ? '' : 'none';
    });

    if (adminNav) {
        adminNav.style.display = isAdmin ? 'flex' : 'none';
    }

    if (dropdownAdmin) {
        dropdownAdmin.style.display = isAdmin ? 'flex' : 'none';
    }

    if (guestCta) {
        guestCta.style.display = isViewer ? 'flex' : 'none';
    }
};

// ─── Navigation & Global Sidebar Injection ───

window.navigate = function(viewId) {
    // ─── Route Access Guard ───
    const isGuest = window.ScreencordAuth && window.ScreencordAuth.isGuest;
    const userModules = window.ScreencordAuth?.currentUser?.modules || [];
    
    // Core views that are always allowed if signed in, or gated by Guest role
    const hostOnlyViews = ['recordings', 'events', 'schedule', 'admin', 'playback'];
    
    if (isGuest && hostOnlyViews.includes(viewId)) {
        showToast('Unauthorized: Please sign in to access this module.', 'error');
        if (currentView === viewId) currentView = 'record';
        return; 
    }

    // Plan-based Gating (only for signed-in users, bypass for Admin role)
    if (!isGuest && window.ScreencordAuth.currentUser && window.ScreencordAuth.currentUser.role !== 'admin') {
        const moduleMap = {
            'record': 'record',
            'recordings': 'recordings',
            'playback': 'recordings',
            'live': 'live',
            'share-playback': 'live',
            'schedule': 'schedule',
            'events': 'events',
            'admin': 'admin'
        };

        const requiredModule = moduleMap[viewId];
        if (requiredModule && !userModules.includes(requiredModule)) {
            showToast(`LOCKED: The ${requiredModule.toUpperCase()} module is not included in your ${window.ScreencordAuth.currentUser.plan.toUpperCase()} plan.`, 'warning');
            return;
        }
    }

    currentView = viewId;
    el.views.forEach(v => {
        v.style.display = 'none';
        v.classList.remove('active');
    });
    const targetView = $(`#view-${viewId}`);
    if (targetView) {
        targetView.style.display = 'block';
        targetView.classList.add('active');
    }

    el.navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('data-nav') === viewId);
    });

    if (viewId === 'recordings') loadRecordings();
    if (viewId === 'admin' && window.ScreencordAdmin) ScreencordAdmin.loadDashboard();
    if (viewId === 'events' && window.loadEvents) window.loadEvents();
    if (viewId === 'schedule' && window.initSchedulingPage) window.initSchedulingPage();
    console.log('Navigating to view:', viewId);
    
    // Ensure canvases are resized when view is shown
    setTimeout(() => {
        window.resizeCanvases();
        
        // Sync whiteboard state visually on navigation
        const preview = targetView.querySelector('.preview');
        if (preview) {
            preview.classList.toggle('is-whiteboard', ScreencordShare.isWhiteboardActive);
        }
        const btn = document.getElementById('tool-whiteboard');
        if (btn) btn.classList.toggle('active', ScreencordShare.isWhiteboardActive);
    }, 50);

    if (viewId !== 'live' && viewId !== 'watch' && viewId !== 'share-playback') {
        if (window.ScreencordShare) ScreencordShare.destroy();
    }

    // Inject Sidebar Logic
    if (el.globalSidebar) {
        if (['live', 'watch', 'share-playback'].includes(viewId)) {
            const panel = targetView.querySelector('.live-panel');
            if (panel) panel.appendChild(el.globalSidebar);
            el.globalSidebar.style.display = 'flex';
            
            // Show host controls in resources if host
            if (el.hostResourceControls) {
                el.hostResourceControls.style.display = (viewId === 'live' || viewId === 'share-playback') ? 'block' : 'none';
            }

            // Show annotation toolbar if host
            if (el.annotationToolbar) {
                const isCollaborative = ['live', 'share-playback', 'watch'].includes(viewId);
                const isHost = ScreencordShare.isHost;
                el.annotationToolbar.style.display = (isCollaborative && isHost) ? 'flex' : 'none';
            }
        } else {
            el.globalSidebar.style.display = 'none';
            if (el.annotationToolbar) el.annotationToolbar.style.display = 'none';
            document.body.appendChild(el.globalSidebar); // Park it freely in body when hidden to prevent layout breaks
        }
    }
}

// ─── Stream Preparation ───
async function createMixedStream() {
    try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
            video: { frameRate: { ideal: 60 }, cursor: 'always' },
            audio: systemAudioEnabled
        });

        let micStream = null;
        if (micEnabled) {
            try {
                micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } catch (err) {
                showToast('Microphone not available', 'error');
            }
        }

        const combinedStream = new MediaStream();
        displayStream.getVideoTracks().forEach(t => combinedStream.addTrack(t));

        if (systemAudioEnabled || micStream) {
            const audioCtx = new AudioContext();
            const dest = audioCtx.createMediaStreamDestination();

            if (displayStream.getAudioTracks().length > 0) {
                const sysSrc = audioCtx.createMediaStreamSource(new MediaStream([displayStream.getAudioTracks()[0]]));
                sysSrc.connect(dest);
            }

            if (micStream) {
                const micSrc = audioCtx.createMediaStreamSource(micStream);
                micSrc.connect(dest);
            }

            if (dest.stream.getAudioTracks().length > 0) {
                dest.stream.getAudioTracks().forEach(t => combinedStream.addTrack(t));
            }
        }
        return combinedStream;
    } catch (err) {
        if (err.name !== 'NotAllowedError') showToast('Failed to start stream', 'error');
        return null;
    }
}

async function setupRecordStream() {
    if (window.ScreencordAuth && window.ScreencordAuth.isGuest) return showToast('Please sign in to start recordings.', 'warning');
    const stream = await createMixedStream();
    if (!stream) return;
    currentStream = stream;

    el.preview.srcObject = currentStream;
    el.preview.play();
    el.preview.classList.add('active');
    el.placeholder.style.display = 'none';

    el.shareScreenBtn.style.display = 'none';
    el.startBtn.style.display = 'flex';
    el.stopBtn.style.display = 'none';
    
    currentStream.getVideoTracks()[0].onended = () => {
        // This is triggered if the user clicks the browser's 'Stop sharing' button
        if (isRecording) {
            mediaRecorder.stop();
            setRecordingUI(false);
            stopTimer();
            // Safety timeout: ensure chunks are processed then show modal
            setTimeout(() => {
                if (recordedChunks.length > 0) showSaveRecordingModal();
            }, 100);
        }
        resetStreamMode();
    };
    showToast('Screen shared successfully. Click "Record" when ready.', 'success');
    window.updateStatusBanner();
}

async function setupLiveStream() {
    if (window.ScreencordAuth && window.ScreencordAuth.isGuest) return showToast('Please sign in to start broadcasts.', 'warning');
    try {
        const stream = await createMixedStream();
        if (!stream) return;
        currentStream = stream;

        // Only update UI once we have the stream
        el.livePreview.srcObject = currentStream;
        el.livePreview.play();
        el.livePreview.classList.add('active');
        el.livePlaceholder.style.display = 'none';

        el.liveShareBtn.style.display = 'none';
        el.liveStartBtn.style.display = 'flex';
        el.liveStopBtn.style.display = 'none';
        
        currentStream.getVideoTracks()[0].onended = () => {
            if (window.ScreencordShare && ScreencordShare.peer) stopLiveSession();
            resetLiveMode();
        };
        showToast('Screen ready. Click "Go Live" to get your code.', 'info');
        window.updateStatusBanner();
    } catch (err) {
        console.error(err);
    }
}

function resetStreamMode() {
    currentStream = null;
    if (el.preview.srcObject) {
         el.preview.srcObject.getTracks().forEach(t => t.stop());
    }
    el.preview.srcObject = null;
    el.preview.classList.remove('active');
    el.placeholder.style.display = 'flex';
    
    el.shareScreenBtn.style.display = 'flex';
    el.startBtn.style.display = 'none';
    el.stopBtn.style.display = 'none';
    window.updateStatusBanner();
}

function resetLiveMode() {
    currentStream = null;
    if (el.livePreview.srcObject) {
         el.livePreview.srcObject.getTracks().forEach(t => t.stop());
    }
    el.livePreview.srcObject = null;
    el.livePreview.classList.remove('active');
    el.livePlaceholder.style.display = 'flex';
    
    el.liveShareBtn.style.display = 'flex';
    el.liveStartBtn.style.display = 'none';
    el.liveStopBtn.style.display = 'none';
    window.updateStatusBanner();
}

// ─── Recording Logic ───
async function toggleMic() {
    micEnabled = !micEnabled;
    el.micToggle.classList.toggle('active', micEnabled);
}

async function toggleAudio() {
    systemAudioEnabled = !systemAudioEnabled;
    el.audioToggle.classList.toggle('active', systemAudioEnabled);
}

function startRecording() {
    if (window.ScreencordAuth && window.ScreencordAuth.isGuest) return showToast('Please sign in to start recordings.', 'warning');
    if (!currentStream) return showToast('Please share your screen first.', 'error');

    try {
        mediaRecorder = new MediaRecorder(currentStream, {
            mimeType: 'video/webm;codecs=vp9,opus'
        });

        recordedChunks = [];
        mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) recordedChunks.push(e.data);
        };

        mediaRecorder.onstop = showSaveRecordingModal;
        mediaRecorder.start();

        setRecordingUI(true);
        startTimer();
        window.updateStatusBanner();

    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    }
}

function stopRecording() {
    if (!mediaRecorder || mediaRecorder.state === 'inactive') return;
    mediaRecorder.stop();
    setRecordingUI(false);
    stopTimer();
    resetStreamMode();
}

function setRecordingUI(active) {
    isRecording = active;
    el.startBtn.style.display = 'none';
    el.shareScreenBtn.style.display = 'none';
    el.stopBtn.style.display = active ? 'flex' : 'none';
    
    el.statusBadge.classList.toggle('recording', active);
    el.statusText.textContent = active ? 'Recording' : 'Ready';
    el.recBadge.classList.toggle('active', active);
}

// ─── Status Banner ───
window.updateStatusBanner = function() {
    if (!el.statusBadge || !el.statusText) return;

    if (isRecording) {
        el.statusBadge.classList.add('recording');
        el.statusText.textContent = 'Recording';
    } else if (window.ScreencordShare && ScreencordShare.peer && ScreencordShare.isHost) {
        el.statusBadge.classList.add('recording');
        el.statusText.textContent = 'Live';
    } else if (currentStream) {
        el.statusBadge.classList.remove('recording');
        el.statusText.textContent = 'Screen Shared';
    } else {
        el.statusBadge.classList.remove('recording');
        el.statusText.textContent = 'Ready';
    }
};

// ─── Timer Logic ───
function startTimer() {
    startTime = Date.now();
    el.timerH.textContent = '00';
    el.timerM.textContent = '00';
    el.timerS.textContent = '00';
    timerInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const h = Math.floor(elapsed / 3600000);
        const m = Math.floor((elapsed % 3600000) / 60000);
        const s = Math.floor((elapsed % 60000) / 1000);
        el.timerH.textContent = h.toString().padStart(2, '0');
        el.timerM.textContent = m.toString().padStart(2, '0');
        el.timerS.textContent = s.toString().padStart(2, '0');
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

// ─── Save Modal ───
function showSaveRecordingModal() {
    tempRecordingBlob = new Blob(recordedChunks, { type: 'video/webm' });
    const url = URL.createObjectURL(tempRecordingBlob);
    
    el.savePreviewVideo.src = url;
    el.saveName.value = 'Recording ' + new Date().toLocaleString();
    el.saveModal.style.display = 'flex';
}

window.closeSaveModal = function() {
    el.saveModal.style.display = 'none';
    el.savePreviewVideo.src = '';
    tempRecordingBlob = null;
}

window.discardRecording = function() {
    if (confirm('Are you sure you want to discard this recording?')) {
        closeSaveModal();
    }
}

window.confirmSaveRecording = async function() {
    const name = el.saveName.value || 'Untitled Recording';
    
    // Credit Check: 1 credit per recording save
    const hasCredits = await window.checkUseCredits(1, 'save_recording');
    if (!hasCredits) return;
    
    try {
        await window.ScreencordDB.saveRecording({
            id: 'rec_' + Date.now(),
            name: name,
            blob: tempRecordingBlob,
            size: tempRecordingBlob.size,
            duration: el.timerH.textContent + ':' + el.timerM.textContent + ':' + el.timerS.textContent
        });
        
        showToast('Recording saved successfully!', 'success');
        closeSaveModal();
        navigate('recordings');
    } catch (err) {
        showToast('Failed to save recording', 'error');
    }
}

// ─── Recordings Library ───
async function loadRecordings() {
    try {
        const recordings = await window.ScreencordDB.getAllRecordings();
        el.recordingsGrid.innerHTML = '';
        
        if (recordings.length === 0) {
            el.emptyRecordings.style.display = 'flex';
            return;
        }

        el.emptyRecordings.style.display = 'none';
        recordings.forEach(rec => addRecordingToGrid(rec));
    } catch (err) {
        console.error(err);
    }
}

function addRecordingToGrid(rec) {
    const isProcessing = rec.aiStatus === 'processing';
    const isEnhanced = !!rec.chapters;
    const url = URL.createObjectURL(rec.blob);
    const card = document.createElement('div');
    card.className = 'recording-card';
    card.id = `card-${rec.id}`;
    
    card.innerHTML = `
        <div class="recording-card__thumb">
            <video src="${url}"></video>
            <div class="recording-card__play">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            </div>
            ${isEnhanced ? '<div class="ai-badge ai-badge--enhanced">AI Enhanced</div>' : ''}
            ${isProcessing ? '<div class="ai-overlay"><div class="spinner"></div><span>AI Processing...</span></div>' : ''}
        </div>
        <div class="recording-card__info">
            <h3 class="recording-card__name">${rec.name}</h3>
            <div class="recording-card__meta">
                <span>${rec.duration}</span>
                <span>${(rec.size / 1024 / 1024).toFixed(1)} MB</span>
            </div>
        </div>
        <div class="recording-card__actions" style="justify-content: space-between;">
            <div style="display:flex; gap:8px;">
                ${isEnhanced ? `
                    <button class="btn btn--ai btn--sm" title="View AI Notes" onclick="event.stopPropagation(); window.openRecording('${rec.id}')" style="padding: 10px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                    </button>
                ` : ''}
                ${!isEnhanced && !isProcessing ? `
                    <button class="btn btn--ai btn--sm" id="btn-ai-${rec.id}" title="Process with AI" onclick="event.stopPropagation(); processWithAI('${rec.id}')" style="padding: 10px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2v8"/><path d="M12 14v8"/><path d="M4.93 4.93l5.66 5.66"/><path d="M13.41 13.41l5.66 5.66"/><path d="M2 12h8"/><path d="M14 12h8"/><path d="M4.93 19.07l5.66-5.66"/><path d="M13.41 10.59l5.66-5.66"/></svg>
                    </button>
                ` : ''}
                <button class="btn btn--ghost btn--sm" title="Share Instant Watch Party" onclick="event.stopPropagation(); shareExistingRecording('${rec.id}')" style="padding: 10px;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                </button>
                <button class="btn btn--ghost btn--sm" title="Schedule Future Watch Party" onclick="event.stopPropagation(); window.openScheduleModal('${rec.id}')" style="padding: 10px;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                </button>
            </div>
            <button class="btn btn--danger btn--sm" title="Delete Recording" onclick="event.stopPropagation(); deleteRecording('${rec.id}')" style="padding: 10px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
            </button>
        </div>
    `;
    card.onclick = () => window.openRecording(rec.id);
    el.recordingsGrid.appendChild(card);
}

window.deleteRecording = async function(id) {
    if (confirm('Delete this recording forever?')) {
        await window.ScreencordDB.deleteRecording(id);
        loadRecordings();
    }
}

// ─── Live Session Logic ───
let liveMediaRecorder = null;
let liveChunks = [];

async function startLiveSession() {
    if (!currentStream) return showToast('Please share your screen first.', 'error');

    // Credit Check: 5 credits for live broadcast
    const hasCredits = await window.checkUseCredits(5, 'live_broadcast');
    if (!hasCredits) return;

    resetGlobalSidebar();
    try {
        ScreencordShare.roomType = 'live';
        const code = await ScreencordShare.initSession(true);
        el.liveRoomCode.textContent = code;
        el.liveRoomInfo.style.display = 'flex';
        el.liveStartBtn.style.display = 'none';
        el.liveStopBtn.style.display = 'flex';
        
        el.globalChatInput.disabled = false;
        el.globalChatSend.disabled = false;
        
        ScreencordShare.startStreaming(currentStream);
        setupSessionHandlers();

        // ─── AI Copilot Greeting ───
        setTimeout(() => {
            const aiMsg = {
                type: 'chat',
                text: "Hello! I'm Screencord AI. I'm actively indexing this session and will prepare the insights for the host once the broadcast completes.",
                name: 'Screencord AI',
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            ScreencordShare.sendMessage(aiMsg);
            renderMessage(aiMsg, false); // Render locally on host too
        }, 1500);

        // Track broadcast
        if (window.ScreencordTracker) {
            ScreencordTracker.startBroadcast(code, 'live');
        }

        // Silent background recording of the live session
        liveChunks = [];
        liveMediaRecorder = new MediaRecorder(currentStream, { mimeType: 'video/webm' });
        liveMediaRecorder.ondataavailable = e => { if (e.data.size > 0) liveChunks.push(e.data); };
        liveMediaRecorder.start();

        showToast('Live session started! Share your code.', 'success');
        window.updateStatusBanner();
        
        const liveBadge = $('#live-rec-badge');
        if(liveBadge) liveBadge.classList.add('active');

    } catch (err) {
        showToast('Could not start live: ' + err.message, 'error');
    }
}

function stopLiveSession() {
    // Stop and save background recording
    if (liveMediaRecorder && liveMediaRecorder.state !== 'inactive') {
        liveMediaRecorder.onstop = async () => {
            try {
                const blob = new Blob(liveChunks, { type: 'video/webm' });
                const name = `Live Broadcast - ${new Date().toLocaleString()}`;
                await window.ScreencordDB.saveRecording(name, blob);
                showToast('Live session automatically saved to your recordings.', 'success', 5000);
            } catch (err) {
                console.error("Failed to save live recording to DB:", err);
            }
        };
        liveMediaRecorder.stop();
    }

    // Track broadcast end
    if (window.ScreencordTracker) {
        ScreencordTracker.endBroadcast();
    }

    ScreencordShare.destroy();
    resetLiveMode();
    el.liveRoomInfo.style.display = 'none';
    el.globalChatInput.disabled = true;
    el.globalChatSend.disabled = true;
    
    const liveBadge = $('#live-rec-badge');
    if(liveBadge) liveBadge.classList.remove('active');
    
    showToast('Live session ended', 'info');
    window.updateStatusBanner();
}

// ─── Join Logic ───
window.showJoinModal = function() { el.joinModal.style.display = 'flex'; }
window.closeJoinModal = function() { el.joinModal.style.display = 'none'; }

window.joinSession = async function() {
    const code = el.joinCode.value.toUpperCase();
    const name = el.joinName.value || 'Viewer';
    
    if (!code) return showToast('Please enter a code', 'error');
    
    // Pre-join: Update UI immediately so user knows something is happening
    const originalText = el.joinCode.value;
    el.joinCode.disabled = true;
    el.joinName.disabled = true;
    
    try {
        // IMPORTANT: Register the stream callback BEFORE connecting.
        // The host sends the stream immediately when a viewer connects,
        // so this must be ready before connectToHost() resolves.
        ScreencordShare.onStreamReceived = (stream) => {
            el.watchPreview.srcObject = stream;
            el.watchPreview.play().catch(() => {}); // Ignore autoplay rejections
            el.watchPreview.classList.add('active');
            if(el.watchPlaceholder) el.watchPlaceholder.style.display = 'none';
        };

        // Initialise state but wait for connection before navigating
        showToast('Connecting to session...', 'info');
        
        await ScreencordShare.connectToHost(code, name);
        
        // Success: Now navigate
        localStorage.setItem('screencord_user_name', name);
        navigate('watch');
        closeJoinModal();
        resetGlobalSidebar();

        setupSessionHandlers();
        
        if (el.globalChatInput) el.globalChatInput.disabled = false;
        if (el.globalChatSend) el.globalChatSend.disabled = false;
        
        setUIRole('viewer');

        // Track viewer join in Supabase
        if (window.ScreencordTracker) {
            ScreencordTracker.logViewerJoin(code, name);
        }

        showToast('Joined session successfully!', 'success');
        
    } catch (err) {
        el.joinCode.disabled = false;
        el.joinName.disabled = false;
        showToast('Could not join: Session not found or connection failed', 'error');
    }
}

// ─── Share Existing Recording ───
window.shareExistingRecording = async function(id) {
    const rec = await ScreencordDB.getRecording(id);
    if (!rec) return;

    try {
        // Init session first
        showToast('Creating watch party room...', 'info');
        ScreencordShare.roomType = 'playback';
        const code = await ScreencordShare.initSession(true);

        // Prep stream from video element
        // (Note: We need the element to exist or create a hidden one if we want to prep before navigate)
        // For Watch Party, we navigate then attach, but session is prepped.
        navigate('share-playback');
        resetGlobalSidebar();
        
        const url = URL.createObjectURL(rec.blob);
        el.sharePlaybackVideo.src = url;
        if (el.playbackRoomCode) el.playbackRoomCode.textContent = code;
        
        const videoEl = el.sharePlaybackVideo;
        if (videoEl.captureStream || videoEl.mozCaptureStream) {
            const stream = videoEl.captureStream ? videoEl.captureStream() : videoEl.mozCaptureStream();
            ScreencordShare.startStreaming(stream);
            setupSessionHandlers();

            // Track watch party in Supabase
            if (window.ScreencordTracker) {
                ScreencordTracker.startBroadcast(code, 'playback');
            }
            
            if (el.globalChatInput) el.globalChatInput.disabled = false;
            if (el.globalChatSend) el.globalChatSend.disabled = false;
            
            showToast('Watch party ready! Attendees will see the playback when you press play.', 'success');
        } else {
            showToast('Your browser does not support stream capture for watch parties.', 'error');
        }
    } catch (err) {
        showToast('Error setting up watch party: ' + err.message, 'error');
    }
}

// ─── Global Interaction & Sidebar Logic ───

function resetGlobalSidebar() {
    activePolls = {};
    if (el.globalChatMessages) el.globalChatMessages.innerHTML = '<div class="chat-system-msg">Connected to Session.</div>';
    if (el.resourcesList) el.resourcesList.innerHTML = '<div class="chat-system-msg" style="width:100%; text-align:center;">No resources shared yet.</div>';
    if (el.globalViewerCount) el.globalViewerCount.textContent = '0';
}

function setupSessionHandlers() {
    ScreencordShare.onViewerUpdate = (count) => {
        if (el.globalViewerCount) el.globalViewerCount.textContent = count;
    };

    ScreencordShare.onMessage = (msg) => {
        if (msg.type === 'room_info') {
            const badge = $('#watch-rec-badge');
            if (badge) {
                if (msg.roomType === 'playback') {
                    badge.innerHTML = '<div class="rec-badge__dot" style="background: currentColor;"></div>WATCH PARTY';
                    badge.style.color = 'var(--purple)';
                } else {
                    badge.innerHTML = '<div class="rec-badge__dot"></div>LIVE';
                    badge.style.color = '';
                }
            }
            
            // Sync whiteboard state on join
            if (msg.isWhiteboardActive && window.handleRemoteWhiteboardToggle) {
                window.handleRemoteWhiteboardToggle({ type: 'WHITEBOARD_TOGGLE', isActive: true });
            }
            return;
        }
        
        if (msg.type === 'chat') {
            renderMessage(msg, false);
        } else if (msg.type === 'resource') {
            renderResource(msg, false);
            showToast('A new resource was shared!', 'info');
        } else if (msg.type === 'poll') {
            renderPoll(msg, false);
            showToast('A new poll was posted!', 'info');
        } else if (msg.type === 'poll_vote' && ScreencordShare.isHost) {
            updatePollVotes(msg.pollId, msg.optionId);
        } else if (msg.type === 'poll_results') {
            syncPollResults(msg.pollId, msg.results);
        }
    };
}

window.sendGlobalChat = function() {
    if(!el.globalChatInput || el.globalChatInput.disabled) return;
    const text = el.globalChatInput.value.trim();
    if (!text) return;
    const name = localStorage.getItem('screencord_user_name') || 'Host';
    const msg = ScreencordShare.sendMessage({ type: 'chat', text, name });
    renderMessage(msg, true);
    el.globalChatInput.value = '';
    el.emojiPicker.style.display = 'none'; // hide emoji picker if open
}

window.addEmoji = function(emoji) {
    if (el.globalChatInput && !el.globalChatInput.disabled) {
        el.globalChatInput.value += emoji;
        el.globalChatInput.focus();
        el.emojiPicker.style.display = 'none';
    }
}

window.addResource = function() {
    const title = $('#res-title').value.trim();
    const url = $('#res-url').value.trim();
    if (!title || !url) return showToast('Please enter both a title and a valid URL.', 'error');
    
    const resMsg = ScreencordShare.sendMessage({
        type: 'resource', title, url, sender: 'Host'
    });
    
    renderResource(resMsg, true);
    $('#res-title').value = '';
    $('#res-url').value = '';
    showToast('Resource logic shared!', 'success');
}

window.createPoll = function() {
    const q = $('#poll-q').value.trim();
    const o1 = $('#poll-o1').value.trim();
    const o2 = $('#poll-o2').value.trim();
    if (!q || (!o1 && !o2)) return showToast('Please enter a question and at least two options.', 'error');
    
    const pollId = 'poll_' + Date.now();
    const options = [
        { id: 'o1', text: o1, votes: 0 },
        { id: 'o2', text: o2, votes: 0 }
    ].filter(o => o.text !== '');
    
    const pollMsg = ScreencordShare.sendMessage({
        type: 'poll', id: pollId, question: q, options
    });
    
    renderPoll(pollMsg, true);
    $('#poll-q').value = '';
    $('#poll-o1').value = '';
    $('#poll-o2').value = '';
    showToast('Poll sent!', 'success');
}

function renderMessage(msg, isSelf = false) {
    if (!el.globalChatMessages) return;
    const div = document.createElement('div');
    div.className = `chat-msg ${isSelf ? 'chat-msg--self' : ''}`;
    div.innerHTML = `
        <div class="chat-msg__header">
            <span class="chat-msg__name">${msg.name}</span>
            <span class="chat-msg__time">${msg.time}</span>
        </div>
        <div class="chat-msg__text">${msg.text}</div>
    `;
    el.globalChatMessages.appendChild(div);
    el.globalChatMessages.scrollTop = el.globalChatMessages.scrollHeight;
}

function renderResource(msg, isSelf) {
    if (!el.resourcesList) return;
    const emptyMsg = el.resourcesList.querySelector('.chat-system-msg');
    if (emptyMsg) emptyMsg.remove();
    
    const a = document.createElement('a');
    a.href = msg.url;
    a.target = '_blank';
    a.className = 'resource-card';
    a.innerHTML = `
        <div class="resource-card__icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
        </div>
        <div class="resource-card__info">
            <span class="resource-card__title">${msg.title}</span>
            <span class="resource-card__url">${msg.url}</span>
        </div>
    `;
    el.resourcesList.appendChild(a);
}

function renderPoll(msg, isSelf) {
    if (isSelf) activePolls[msg.id] = msg;
    
    if (!el.globalChatMessages) return;
    const div = document.createElement('div');
    div.className = `chat-poll`;
    div.id = msg.id;
    
    let optionsHtml = '';
    msg.options.forEach(o => {
        optionsHtml += `
            <div class="chat-poll__opt" onclick="window.votePoll('${msg.id}', '${o.id}')">
                <span class="chat-poll__opt-text">${o.text} <span id="pct-${msg.id}-${o.id}" style="float:right; opacity:0.6; font-size:0.8rem;">0% (0)</span></span>
                <div class="chat-poll__bar" id="bar-${msg.id}-${o.id}"></div>
            </div>
        `;
    });

    div.innerHTML = `
        <div class="chat-poll__q">${msg.question}</div>
        <div style="display:flex; flex-direction:column; gap:8px;">
            ${optionsHtml}
        </div>
    `;
    
    el.globalChatMessages.appendChild(div);
    el.globalChatMessages.scrollTop = el.globalChatMessages.scrollHeight;
}

window.votePoll = function(pollId, optionId) {
    ScreencordShare.sendMessage({ type: 'poll_vote', pollId, optionId });
    const opts = document.querySelectorAll(`#${pollId} .chat-poll__opt`);
    opts.forEach(opt => {
        opt.style.pointerEvents = 'none';
        opt.style.opacity = '0.7';
    });
}

function updatePollVotes(pollId, optionId) {
    if (!activePolls[pollId]) return;
    const opt = activePolls[pollId].options.find(o => o.id === optionId);
    if (opt) opt.votes++;
    
    ScreencordShare.sendMessage({
        type: 'poll_results', pollId, results: activePolls[pollId].options
    });
    
    syncPollResults(pollId, activePolls[pollId].options);
}

function syncPollResults(pollId, results) {
    const totalVotes = results.reduce((sum, o) => sum + o.votes, 0);
    results.forEach(opt => {
        const bar = document.querySelector(`#${pollId} #bar-${pollId}-${opt.id}`);
        const pctText = document.querySelector(`#${pollId} #pct-${pollId}-${opt.id}`);
        if(bar && pctText) {
            const pct = totalVotes === 0 ? 0 : Math.round((opt.votes / totalVotes) * 100);
            bar.style.width = pct + '%';
            pctText.textContent = `${pct}% (${opt.votes})`;
        }
    });
}

// Global modal handlers
window.copyRoomCode = function(id) {
    const codeElement = $(`#${id}`);
    if(!codeElement) return;
    navigator.clipboard.writeText(codeElement.textContent);
    showToast('Code copied to clipboard!', 'success');
}
window.openInviteModal = function(codeId) {
    const code = $(`#${codeId}`).textContent;
    if (el.shareRoomCode) el.shareRoomCode.textContent = code;
    if (el.shareModal) el.shareModal.style.display = 'flex';
    switchInviteTab('recipients'); // Reset to first tab
}
window.switchInviteTab = function(tab) {
    const panes = {
        recipients: document.getElementById('invite-pane-recipients'),
        compose: document.getElementById('invite-pane-compose')
    };
    const tabs = {
        recipients: document.getElementById('tab-recipients'),
        compose: document.getElementById('tab-compose')
    };

    Object.keys(panes).forEach(k => {
        if (panes[k]) panes[k].style.display = (k === tab) ? 'block' : 'none';
        if (tabs[k]) {
            tabs[k].classList.toggle('active', k === tab);
            tabs[k].style.color = (k === tab) ? 'var(--text-2)' : 'var(--text-3)';
        }
    });

    if (tab === 'compose') {
        generateInviteTemplate();
    }
}

function generateInviteTemplate() {
    const editor = document.getElementById('invite-editor');
    const code = el.shareRoomCode.textContent;
    const name = localStorage.getItem('screencord_user_name') || 'A Host';
    const type = currentView === 'live' ? 'Live Stream' : 'Watch Party';

    editor.innerHTML = `
        <div style="font-family: sans-serif; color: #333;">
            <p>Hey there,</p>
            <p>I'm hosting a <strong>${type}</strong> on Screencord and I'd love for you to join me!</p>
            <div style="background: #f4f4f5; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; border: 1px solid #e4e4e7;">
                <span style="display:block; font-size: 0.8rem; color: #71717a; text-transform: uppercase; margin-bottom: 4px;">Access Code</span>
                <span style="font-size: 2rem; font-family: monospace; letter-spacing: 4px; color: #18181b; font-weight: bold;">${code}</span>
            </div>
            <p>You can join directly in your browser without any installation.</p>
            <p>Best,<br><strong>${name}</strong></p>
        </div>
    `;
}
window.closeShareModal = function() {
    if (el.shareModal) el.shareModal.style.display = 'none';
}
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        // SECURITY FOR SAVING: 
        // We prevent the saveModal from closing on background click
        // so the user MUST either Discard or Save. 
        if (e.target.id === 'save-modal') return;

        if(el.joinModal) el.joinModal.style.display = 'none';
        if(el.shareModal) el.shareModal.style.display = 'none';
    }
});

function showToast(text, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.textContent = text;
    el.toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('removing');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

window.sendEmailInvite = async function(fieldId = 'invite-emails', isCustom = false) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    const email = field.value.trim();
    if (!email) return showToast('Please enter at least one email address', 'error');

    const btn = event.currentTarget;
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '...';

    const payload = {
        to: email,
        room_code: el.shareRoomCode.textContent,
        room_type: currentView === 'live' ? 'live' : 'playback'
    };

    if (isCustom) {
        payload.custom_subject = document.getElementById('invite-subject').value;
        payload.custom_html = document.getElementById('invite-editor').innerHTML;
    }

    try {
        const response = await fetch('/api/ai/invite', {
            method: 'POST',
            body: JSON.stringify(payload),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('screencord_token')}`
            }
        });

        const result = await response.json();
        if (result.success) {
            showToast(`Successfully invited ${result.sentCount} participant(s)!`, 'success');
            field.value = '';
            if (isCustom) switchInviteTab('recipients');
            closeShareModal();
        } else {
            throw new Error(result.error || 'Failed to send');
        }
    } catch (err) {
        showToast('Error: ' + err.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

// ─── Role Control ───
function setUIRole(role) {
    const isViewer = (role === 'viewer');
    document.querySelectorAll('.host-only').forEach(el => {
        el.style.display = isViewer ? 'none' : '';
    });
    document.querySelectorAll('.viewer-only').forEach(el => {
        el.style.display = isViewer ? 'flex' : 'none';
    });
}

window.leaveSession = function() {
    if (confirm('Leave this session and return to recorder?')) {
        if (window.ScreencordShare) ScreencordShare.destroy();
        setUIRole('host');
        navigate('record');
        showToast('Disconnected from session', 'info');
    }
}

// ═══════════════════════════════════════════════════════
// PHASE 2: AI & POST-SESSION INTELLIGENCE LOGIC
// ═══════════════════════════════════════════════════════

let currentPlaybackRecording = null;

window.openRecording = async function(id) {
    const rec = await window.ScreencordDB.getRecording(id);
    if (!rec) return;

    currentPlaybackRecording = rec;
    const url = URL.createObjectURL(rec.blob);
    
    el.playbackVideo.src = url;
    el.playbackTitle.textContent = rec.name;
    
    // Update Badge
    if (rec.chapters) {
        el.aiStatusBadge.textContent = 'AI Enhanced';
        el.aiStatusBadge.className = 'badge badge--success';
    } else if (rec.aiStatus === 'processing') {
        el.aiStatusBadge.textContent = 'Processing...';
        el.aiStatusBadge.className = 'badge badge--warning pulsing';
    } else {
        el.aiStatusBadge.textContent = 'AI Ready';
        el.aiStatusBadge.className = 'badge badge--info';
    }

    renderChapters(rec);
    renderActionItems(rec);
    renderSummary(rec);
    navigate('playback');
}

window.processWithAI = async function(id) {
    // Credit Check: 10 credits for AI processing
    const hasCredits = await window.checkUseCredits(10, 'ai_processing');
    if (!hasCredits) return;

    try {
        const rec = await window.ScreencordDB.getRecording(id);
        if (!rec) return;

        showToast('Sending recording for AI processing...', 'info');
        
        // Update UI to processing state
        await window.ScreencordDB.updateRecording(id, { aiStatus: 'processing' });
        loadRecordings(); // Refresh gallery

        const formData = new FormData();
        formData.append('video', rec.blob, `${id}.webm`);

        const response = await fetch('/api/ai/process', {
            method: 'POST',
            body: formData,
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('screencord_token')}`
            }
        });

        const result = await response.json();
        
        if (result.success) {
            await window.ScreencordDB.updateRecording(id, {
                aiStatus: 'completed',
                transcript: result.transcript,
                chapters: result.chapters,
                actionItems: result.actionItems,
                summary: result.summary,
                durationSeconds: result.duration
            });
            showToast('AI Analysis Complete!', 'success');
        } else {
            throw new Error(result.error || 'Processing failed');
        }

    } catch (err) {
        console.error('[AI] Error:', err);
        showToast('AI Processing failed: ' + err.message, 'error');
        await window.ScreencordDB.updateRecording(id, { aiStatus: 'failed' });
    } finally {
        loadRecordings(); // Refresh gallery to show final state
    }
}

function renderChapters(rec) {
    if (!rec.chapters || rec.chapters.length === 0) {
        el.chaptersList.innerHTML = '<div class="chapters-empty"><p>No chapters yet. Click "Process with AI" to generate them.</p></div>';
        return;
    }

    el.chaptersList.innerHTML = '';
    rec.chapters.forEach(chap => {
        const item = document.createElement('div');
        item.className = 'chapter-item';
        item.innerHTML = `
            <div class="chapter-item__time">${formatSeconds(chap.start)}</div>
            <div class="chapter-item__title">${chap.title}</div>
        `;
        item.onclick = () => {
            el.playbackVideo.currentTime = chap.start;
            el.playbackVideo.play();
        };
        el.chaptersList.appendChild(item);
    });
}

function formatSeconds(s) {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
}

window.renderActionItems = function(rec) {
    const list = document.getElementById('action-items-list');
    const container = document.getElementById('ai-action-items-container');
    
    if (!rec.actionItems || rec.actionItems.length === 0) {
        if (container) container.style.display = 'none';
        return;
    }

    if (container) container.style.display = 'block';
    list.innerHTML = '';
    
    rec.actionItems.forEach(item => {
        const li = document.createElement('li');
        li.style.cssText = 'font-size: 0.85rem; color: var(--text-2); display: flex; align-items: flex-start; gap: 8px; margin-bottom: 8px;';
        li.innerHTML = `
            <span style="color: var(--purple); font-weight: bold;">•</span>
            <span>${item}</span>
        `;
        list.appendChild(li);
    });
};

window.renderSummary = function(rec) {
    const textEl = document.getElementById('ai-summary-text');
    const container = document.getElementById('ai-summary-container');
    
    if (!rec.summary) {
        if (container) container.style.display = 'none';
        return;
    }

    if (container) container.style.display = 'block';
    textEl.textContent = rec.summary;
};

window.filterChapters = function() {
    const query = el.chapterSearchInput.value.toLowerCase();
    const items = document.querySelectorAll('.chapter-item');
    
    items.forEach(item => {
        const title = item.querySelector('.chapter-item__title').textContent.toLowerCase();
        item.style.display = title.includes(query) ? 'flex' : 'none';
    });
}
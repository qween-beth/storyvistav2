'use strict';
require('dotenv').config();
const { scrapePage } = require('./src/ingestion/crawler');

async function test() {
  const url = 'https://kids.nationalgeographic.com/animals/mammals/facts/african-elephant';
  console.log(`Testing scraper for: ${url}`);
  try {
    const page = await scrapePage(url);
    if (page) {
      console.log('--- TITLE ---');
      console.log(page.title);
      console.log('--- DESCRIPTION ---');
      console.log(page.description);
      console.log('--- CONTENT (first 500 chars) ---');
      console.log(page.content.substring(0, 500));
      console.log('--- LINKS COUNT ---');
      console.log(page.links.length);
    } else {
      console.log('Scrape returned null');
    }
  } catch (err) {
    console.error('Error during scrape:', err);
  }
}

test();

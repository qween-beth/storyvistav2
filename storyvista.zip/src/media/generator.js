'use strict';

const axios = require('axios');
const logger = require('../utils/logger');

// ── Style presets per content type ────────────────────────────────
const STYLE_PRESETS = {
  story: {
    base: 'children\'s book illustration style, warm colours, soft lighting, friendly and inviting, high quality digital art',
    suffix: 'safe for children, no text, no letters',
  },
  lesson: {
    base: 'clean educational illustration, clear and informative, bright colours, simple design, diagram style',
    suffix: 'safe for children, no text overlays',
  },
};

// ── Age-band style adjustments ────────────────────────────────────
const AGE_STYLES = {
  '3-5': 'very simple shapes, bold colours, cartoonish, cute characters',
  '6-8': 'illustrated children\'s book style, expressive characters, clear scenes',
  '9-12': 'detailed illustration, slightly more realistic, educational feel',
};

// ── Cultural context hints ────────────────────────────────────────
const REGION_HINTS = {
  global: 'diverse, multicultural characters and settings',
  ng: 'diverse Nigerian children characters, local Nigerian architecture and landscapes',
  gh: 'Ghanaian children characters, vibrant Ghanaian kente and local settings',
  ke: 'Kenyan children characters, East African savanna or cityscapes',
  za: 'South African children characters, diverse South African landscapes',
  uk: 'British children characters, UK suburban or city architecture',
  us: 'American children characters, US suburban or city settings',
};

/**
 * Build a fact-grounded prompt from a knowledge block
 *
 * @param {Object} block        - knowledge block
 * @param {string} contentType  - 'story' | 'lesson'
 * @param {string} ageBand      - '3-5' | '6-8' | '9-12'
 * @param {string} region       - 'ng' | 'global'
 * @param {string} [sceneHint]  - optional specific scene description
 * @returns {string}
 */
function buildImagePrompt(block, contentType = 'story', ageBand = '6-8', region = 'ng', sceneHint = null) {
  const style = STYLE_PRESETS[contentType] || STYLE_PRESETS.story;
  const ageStyle = AGE_STYLES[ageBand] || AGE_STYLES['6-8'];
  const regionHint = REGION_HINTS[region] || REGION_HINTS.global;

  // Pull story elements for richer context
  const storyElements = typeof block.story_elements === 'string'
    ? JSON.parse(block.story_elements)
    : block.story_elements || {};

  const settings = storyElements.possibleSettings?.[0] || 'natural outdoor setting';
  const themes = storyElements.emotionalThemes?.[0] || 'curiosity and wonder';

  // Use a specific scene if provided, otherwise build from block data
  const scene = sceneHint
    || `a scene about "${block.topic}" showing ${settings}, evoking ${themes}`;

  const prompt = [
    style.base,
    ageStyle,
    regionHint,
    scene,
    style.suffix,
  ].filter(Boolean).join(', ');

  return prompt;
}

/**
 * Generate an image via Replicate (openai/gpt-image-1.5)
 *
 * @param {string} prompt
 * @param {Object} opts
 * @param {string} opts.aspect_ratio - '1:1', '16:9', '4:3' etc
 * @param {string} opts.quality - 'auto', 'high'
 * @returns {Promise<GeneratedImage>}
 */
async function generateImage(prompt, opts = {}) {
  if (!process.env.REPLICATE_API_TOKEN) {
    throw new Error('REPLICATE_API_TOKEN is required for image generation');
  }

  const Replicate = require('replicate');
  const replicate = new Replicate({
    auth: process.env.REPLICATE_API_TOKEN,
  });

  const { aspect_ratio = '1:1', quality = 'high' } = opts;

  logger.info(`[ImageGen] Generating image via Replicate (openai/gpt-image-1.5) — ${prompt.slice(0, 80)}...`);

  try {
    const input = {
      prompt,
      quality,
      aspect_ratio
    };

    const output = await replicate.run("openai/gpt-image-1.5", { input });

    // Output schema for openai/gpt-image-1.5 on replicate returns an array of URIs or URI objects
    // In recent Replicate Node client, images are objects with .url() or just strings
    const imageUrl = typeof output[0] === 'string' ? output[0] : (output[0]?.url ? output[0].url() : output[0]);

    if (!imageUrl) {
      throw new Error('Replicate returned no image URL');
    }

    return {
      url: imageUrl,
      revisedPrompt: prompt, // Replicate doesn't always return the revised prompt in the same way
      source: 'replicate-openai',
      license: 'generated',
      attribution: 'AI-generated illustration via Replicate',
      width: aspect_ratio === '16:9' ? 1792 : 1024,
      height: aspect_ratio === '16:9' ? 1024 : 1024,
    };
  } catch (error) {
    logger.error('Error generating image via Replicate:', error);
    throw error;
  }
}


/**
 * Generate a block-grounded image (main entry point)
 *
 * @param {Object} block
 * @param {string} contentType
 * @param {string} ageBand
 * @param {string} region
 * @param {string} [sceneHint]
 * @returns {Promise<GeneratedImage>}
 */
async function generateBlockImage(block, contentType = 'story', ageBand = '6-8', region = 'ng', sceneHint = null) {
  const prompt = buildImagePrompt(block, contentType, ageBand, region, sceneHint);
  return generateImage(prompt, {
    aspect_ratio: contentType === 'story' ? '16:9' : '1:1',
    quality: 'high',
  });
}

module.exports = { generateImage, generateBlockImage, buildImagePrompt };

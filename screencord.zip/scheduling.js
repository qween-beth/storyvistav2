// ─── Scheduled Sessions & Registration Logic ───
let schedulingRecordingId = null;
window.switchScheduleInviteTab = function(tab) {
    const panes = {
        'recipients': 'schedule-pane-recipients',
        'compose': 'schedule-pane-compose'
    };
    const tabs = {
        'recipients': 'tab-schedule-recipients',
        'compose': 'tab-schedule-compose'
    };

    Object.keys(panes).forEach(k => {
        document.getElementById(panes[k]).style.display = (k === tab) ? (tab === 'compose' ? 'flex' : 'block') : 'none';
        document.getElementById(tabs[k]).classList.toggle('active', k === tab);
        document.getElementById(tabs[k]).style.color = (k === tab) ? 'var(--text)' : 'var(--text-3)';
    });

    if (tab === 'compose') previewScheduledEmail(true);
};

let customQuestions = {
    'schedule': [],
    'schedule-page': []
};

window.openScheduleModal = function(id) {
    schedulingRecordingId = id;
    customQuestions['schedule'] = [];
    renderCustomQuestions('schedule');
    const modal = document.getElementById('schedule-modal');
    if (modal) modal.style.display = 'flex';
}

window.closeScheduleModal = function() {
    const modal = document.getElementById('schedule-modal');
    if (modal) modal.style.display = 'none';
    schedulingRecordingId = null;
}

window.initSchedulingPage = async function() {
    const select = document.getElementById('schedule-page-recording');
    if (!select) return;
    
    customQuestions['schedule-page'] = [];
    renderCustomQuestions('schedule-page');
    
    select.innerHTML = '<option value="">-- Select a Recording --</option>';
    try {
        const recordings = await window.ScreencordDB.getAllRecordings();
        if (recordings.length === 0) {
            select.innerHTML = '<option value="">No recordings found. Please record something first.</option>';
            return;
        }
        recordings.forEach(rec => {
            const opt = document.createElement('option');
            opt.value = rec.id;
            opt.textContent = `${rec.name} (${rec.duration})`;
            select.appendChild(opt);
        });
    } catch (err) {
        showToast('Error loading recordings for selection', 'error');
    }
}

window.addCustomQuestion = function(prefix) {
    const input = document.getElementById(`${prefix}-new-question`);
    const val = input.value.trim();
    if (!val) return;
    
    customQuestions[prefix].push(val);
    input.value = '';
    renderCustomQuestions(prefix);
}

window.removeCustomQuestion = function(prefix, idx) {
    customQuestions[prefix].splice(idx, 1);
    renderCustomQuestions(prefix);
}

window.renderCustomQuestions = function(prefix) {
    const list = document.getElementById(`${prefix}-questions-list`);
    if (!list) return;
    
    list.innerHTML = '';
    customQuestions[prefix].forEach((q, i) => {
        const div = document.createElement('div');
        div.style.cssText = 'display:flex; align-items:center; gap:8px; background:var(--surface-1); padding:8px 12px; border-radius:8px; border:1px solid var(--border); font-size:0.85rem;';
        div.innerHTML = `
            <span style="flex:1;">${q}</span>
            <button onclick="removeCustomQuestion('${prefix}', ${i})" style="border:0; background:transparent; color:var(--red); cursor:pointer; font-weight:bold;">×</button>
        `;
        list.appendChild(div);
    });
}

window.previewScheduledEmail = function(isFromPage = true) {
    const ids = isFromPage ? {
        theme: 'schedule-page-theme',
        title: 'schedule-page-title',
        time: 'schedule-page-time',
        editor: 'schedule-page-editor'
    } : {
        theme: 'email-theme',
        title: 'schedule-title',
        time: 'schedule-time',
        editor: 'preview-modal-body'
    };

    const theme = document.getElementById(ids.theme).value;
    const title = document.getElementById(ids.title).value || 'My Watch Party';
    const time = document.getElementById(ids.time).value;
    
    const sender = localStorage.getItem('screencord_user_name') || 'A Host';
    const dateStr = time ? new Date(time).toLocaleString() : 'January 1st, 2026';
    
    let badgeText, badgeBg, bgStyle, boxBg, boxBorder, btnBg, btnRadius, toneText, textColor, titleColor, accentColor;

    if (theme === 'party') {
        badgeText = '🔥 MASSIVE EVENT';
        badgeBg = 'linear-gradient(45deg, #f43f5e, #8b5cf6)';
        bgStyle = 'background: #0f172a; color: #fff; border: 2px solid #334155;';
        boxBg = '#1e293b';
        boxBorder = '#475569';
        btnBg = 'linear-gradient(90deg, #ec4899, #8b5cf6); color: white;';
        btnRadius = '24px';
        accentColor = '#ec4899';
        toneText = `<strong>${sender}</strong> is throwing an epic Watch Party! Grab your spot on the RSVP list before it fills up.`;
        textColor = '#cbd5e1'; titleColor = '#ffffff';
    } else if (theme === 'friendly') {
        badgeText = '✨ UPCOMING HANGOUT';
        badgeBg = '#8b5cf6';
        bgStyle = 'background: #fff; color: #1e293b; border: 1px solid #ddd6fe;';
        boxBg = '#f5f3ff';
        boxBorder = '#c4b5fd';
        btnBg = 'background: #6d28d9; color: white;';
        btnRadius = '16px';
        accentColor = '#8b5cf6';
        toneText = `<strong>${sender}</strong> is hosting an awesome Watch Party today, and we'd love for you to join us!`;
        textColor = '#4b5563'; titleColor = '#0f172a';
    } else {
        badgeText = 'EXECUTIVE BRIEFING';
        badgeBg = '#3b82f6';
        bgStyle = 'background: #fff; color: #1f2937; border: 1px solid #e5e7eb;';
        boxBg = '#f8fafc';
        boxBorder = '#cbd5e1';
        btnBg = 'background: #111827; color: white;';
        btnRadius = '8px';
        accentColor = '#3b82f6';
        toneText = `<strong>${sender}</strong> has scheduled an exclusive Watch Party and requests your attendance on the registered attendee list.`;
        textColor = '#4b5563'; titleColor = '#0f172a';
    }

    const html = `
        <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; ${bgStyle} padding: 40px; border-radius: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 32px;">
                <div style="width: 32px; height: 32px; background: ${accentColor}; border-radius: 8px;"></div>
                <span style="font-weight: 800; font-size: 1.2rem; color: ${titleColor};">Screencord</span>
            </div>
            
            <div style="display: inline-block; padding: 4px 12px; background: ${badgeBg}; color: white; border-radius: 100px; font-size: 10px; font-weight: 800; letter-spacing: 1px; margin-bottom: 20px;">
                ${badgeText}
            </div>
            
            <h1 style="font-size: 24px; font-weight: 800; color: ${titleColor}; margin: 0 0 16px;">${title}</h1>
            
            <div style="background: ${boxBg}; border: 1px solid ${boxBorder}; padding: 24px; border-radius: 16px; margin-bottom: 32px;">
                <p id="preview-tone-text" style="font-size: 16px; line-height: 1.6; color: ${textColor}; margin: 0 0 20px;">
                    ${toneText}
                </p>
                
                <div style="display: flex; align-items: center; gap: 12px; padding-top: 16px; border-top: 1px solid ${boxBorder};">
                    <div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items:center; justify-content:center; color:#999; font-size:12px;">CAL</div>
                    <div>
                        <div style="font-weight: 700; font-size: 14px; color: ${titleColor};">${dateStr}</div>
                        <div style="font-size: 12px; color: ${textColor};">Live Transmission via Screencord</div>
                    </div>
                </div>
            </div>

            <div style="text-align: center;">
                <a href="#" style="display: inline-block; padding: 16px 32px; border-radius: ${btnRadius}; background: ${btnBg}; text-decoration: none; font-weight: 700; font-size: 16px; box-shadow: 0 10px 20px rgba(0,0,0,0.1);">
                    Register to Attend
                </a>
            </div>
        </div>
    `;

    document.getElementById('preview-modal-body').innerHTML = html;
    document.getElementById('preview-modal').style.display = 'flex';
}

window.confirmScheduleSession = async function(isFromPage = false) {
    const ids = isFromPage ? {
        title: 'schedule-page-title',
        time: 'schedule-page-time',
        phone: 'schedule-page-phone',
        company: 'schedule-page-company',
        emails: 'schedule-page-emails',
        theme: 'schedule-page-theme',
        recId: 'schedule-page-recording',
        message: 'schedule-page-message'
    } : {
        title: 'schedule-title',
        time: 'schedule-time',
        phone: 'form-phone',
        company: 'form-company',
        emails: 'schedule-emails',
        theme: 'email-theme',
        recId: null,
        message: 'schedule-message'
    };
    
    let finalRecId = isFromPage ? document.getElementById(ids.recId).value : schedulingRecordingId;
    
    if (!finalRecId) return showToast('Please select a recording.', 'warning');
    
    const title = document.getElementById(ids.title).value.trim();
    const time = document.getElementById(ids.time).value;
    const phoneReq = document.getElementById(ids.phone).checked;
    const companyReq = document.getElementById(ids.company).checked;
    const theme = document.getElementById(ids.theme)?.value || 'professional';
    
    // Extract custom message from the rich editor if available
    let customMsg = "";
    if (isFromPage) {
        const editor = document.getElementById('schedule-page-editor');
        const toneElement = editor.querySelector('#preview-tone-text');
        customMsg = toneElement ? toneElement.innerText.trim() : editor.innerText.trim();
    } else {
        customMsg = document.getElementById(ids.message)?.value.trim() || "";
    }

    if (!title || !time) return showToast('Please enter title and time.', 'warning');

    try {
        const rec = await window.ScreencordDB.getRecording(finalRecId);
        showToast('Publishing recording and scheduling...', 'info');
        
        const roomCode = Math.random().toString(36).substring(2, 10).toUpperCase();
        
        const formData = new FormData();
        formData.append('video', rec.blob, `${finalRecId}.webm`);
        formData.append('title', title);
        formData.append('room_code', roomCode);
        formData.append('scheduled_at', time);
        formData.append('form_config', JSON.stringify({ 
            phone: phoneReq, 
            company: companyReq,
            theme: theme,
            custom_message: customMsg,
            questions: customQuestions[isFromPage ? 'schedule-page' : 'schedule']
        }));

        if (inviteEmails) {
            const emailArray = inviteEmails.split(/[,;\s]+/).filter(e => e.includes('@'));
            formData.append('invite_emails', JSON.stringify(emailArray));
            formData.append('email_theme', theme);
        }

        const response = await fetch('/api/sessions/schedule', {
            method: 'POST',
            body: formData,
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('screencord_token')}`
            }
        });

        const result = await response.json();
        if (result.success) {
            let msg = 'Event Scheduled!';
            if (result.invitesSent > 0) msg += ` Sent ${result.invitesSent} invites.`;
            showToast(`${msg} Reg link: ${window.location.origin}/?reg=${roomCode}`, 'success', 8000);
            
            if (isFromPage) {
                navigate('events'); // Go to dashboard if on the page
            } else {
                window.closeScheduleModal();
            }
        } else {
            showToast(result.error || 'Scheduling failed', 'error');
        }
    } catch (err) {
        showToast('Error scheduling event: ' + err.message, 'error');
    }
}

// Handle Registration Page Navigation (Synthetic Routing)
window.checkUrlParams = async function() {
    const params = new URLSearchParams(window.location.search);
    const regCode = params.get('reg');
    if (regCode) {
        setTimeout(() => loadRegistrationPage(regCode), 800);
    }
}

async function loadRegistrationPage(roomCode) {
    try {
        const response = await fetch(`/api/sessions/scheduled/${roomCode}`);
        const result = await response.json();
        
        if (result.success) {
            const session = result.session;
            document.getElementById('reg-session-title').textContent = session.title;
            document.getElementById('reg-session-time').textContent = new Date(session.scheduled_at).toLocaleString();
            
            const customArea = document.getElementById('reg-custom-fields');
            if (customArea) {
                customArea.innerHTML = '';
                if (session.form_config.phone) {
                    customArea.innerHTML += `
                        <label class="form-label" style="margin-top:16px">Phone Number</label>
                        <input type="tel" id="reg-phone" class="form-input" placeholder="+1...">
                    `;
                }
                if (session.form_config.company) {
                    customArea.innerHTML += `
                        <label class="form-label" style="margin-top:16px">Company / Organization</label>
                        <input type="text" id="reg-company" class="form-input" placeholder="ACME Corp">
                    `;
                }
                
                // Render Dynamic Questions
                if (session.form_config.questions && session.form_config.questions.length > 0) {
                    session.form_config.questions.forEach((q, i) => {
                        customArea.innerHTML += `
                            <label class="form-label" style="margin-top:16px">${q}</label>
                            <input type="text" class="form-input reg-custom-q" data-question="${q}" placeholder="Your answer...">
                        `;
                    });
                }
            }

            window.currentRegCode = roomCode;
            navigate('register');
        } else {
            showToast('Event not found or expired', 'error');
        }
    } catch (err) {
        showToast('Error loading registration page', 'error');
    }
}

window.submitRegistration = async function() {
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const phone = document.getElementById('reg-phone')?.value || '';
    const company = document.getElementById('reg-company')?.value || '';
    
    // Scrape custom questions
    const answers = {};
    document.querySelectorAll('.reg-custom-q').forEach(input => {
        answers[input.getAttribute('data-question')] = input.value.trim();
    });

    if (!name || !email) return showToast('Name and Email are required', 'warning');

    try {
        showToast('Registering...', 'info');
        const response = await fetch(`/api/sessions/register/${window.currentRegCode}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name, email, phone, 
                custom_data: { company, ...answers }
            })
        });

        const result = await response.json();
        if (result.success) {
            document.getElementById('registration-form').style.display = 'none';
            document.getElementById('registration-success').style.display = 'block';
        } else {
            showToast(result.error || 'Registration failed', 'error');
        }
    } catch (err) {
        showToast('Server error during registration', 'error');
    }
}

// ─── Events Dashboard Logic ───
window.loadEvents = async function() {
    const grid = document.getElementById('events-grid');
    const empty = document.getElementById('events-empty');
    if (!grid) return;

    try {
        const response = await fetch('/api/sessions/my-scheduled', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('screencord_token')}` }
        });
        const result = await response.json();

        if (result.success) {
            grid.innerHTML = '';
            if (result.sessions.length === 0) {
                empty.style.display = 'block';
                return;
            }
            empty.style.display = 'none';
            result.sessions.forEach(session => renderEventCard(session));
        }
    } catch (err) {
        showToast('Error loading events', 'error');
    }
}

function renderEventCard(session) {
    const grid = document.getElementById('events-grid');
    const card = document.createElement('div');
    card.className = 'recording-card';
    card.style.padding = '20px';
    
    const dateStr = new Date(session.scheduled_at).toLocaleString();
    const regUrl = window.location.origin + '/?reg=' + session.room_code;

    card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
            <span style="font-size:0.7rem; color:var(--purple); font-weight:700; text-transform:uppercase; letter-spacing:1px;">Upcoming Party</span>
            <div style="background: var(--surface-2); padding: 4px 10px; border-radius: 8px; font-size: 0.8rem; font-weight:600; color:var(--text-1); border: 1px solid var(--border);">
                ${session.attendee_count} Registered
            </div>
        </div>
        <h3 style="margin-bottom:6px; font-size:1.1rem;">${session.title}</h3>
        <p style="color:var(--text-3); font-size:0.85rem; margin-bottom:20px;">${dateStr}</p>
        
        <div style="display:flex; gap:8px; margin-top:auto;">
            <button class="btn btn--primary btn--sm" style="flex:1; justify-content:center" onclick="openAttendees('${session.room_code}')">
                View Attendees
            </button>
            <button class="btn btn--ghost btn--sm" style="flex:1; justify-content:center" onclick="copyTextToClipboard('${regUrl}', 'Reg link copied!')">
                Copy Link
            </button>
        </div>
    `;
    grid.appendChild(card);
}

window.openAttendees = async function(roomCode) {
    try {
        const response = await fetch(`/api/sessions/registrations/${roomCode}`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('screencord_token')}` }
        });
        const result = await response.json();

        if (result.success) {
            const body = document.getElementById('attendees-table-body');
            body.innerHTML = '';
            
            if (result.registrations.length === 0) {
                body.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:40px; color:var(--text-3);">No registrations yet.</td></tr>';
            } else {
                result.registrations.forEach(reg => {
                    const tr = document.createElement('tr');
                    
                    // Combine company + custom questions into a detailed custom column
                    let customInfo = [];
                    if (reg.custom_data.company) customInfo.push(`<strong>Co:</strong> ${reg.custom_data.company}`);
                    
                    Object.entries(reg.custom_data).forEach(([key, val]) => {
                        if (key !== 'company' && val) {
                            customInfo.push(`<strong>${key}:</strong> ${val}`);
                        }
                    });

                    tr.innerHTML = `
                        <td style="font-weight:600">${reg.name}</td>
                        <td style="color:var(--text-2)">${reg.email}</td>
                        <td>${reg.phone || '-'}</td>
                        <td style="font-size:0.8rem; line-height:1.4;">${customInfo.join('<br>') || '-'}</td>
                        <td style="color:var(--text-3)">${new Date(reg.created_at).toLocaleDateString()}</td>
                    `;
                    body.innerHTML += tr.outerHTML;
                });
            }
            
            document.getElementById('attendees-modal-title').textContent = 'Registrations';
            document.getElementById('attendees-modal-subtitle').textContent = `Room Code: ${roomCode}`;
            document.getElementById('attendees-modal').style.display = 'flex';
        }
    } catch (err) {
        showToast('Error loading attendees', 'error');
    }
}

window.closeAttendeesModal = () => { document.getElementById('attendees-modal').style.display = 'none'; };

window.copyTextToClipboard = (text, msg) => {
    navigator.clipboard.writeText(text);
    showToast(msg, 'success');
}

document.addEventListener('DOMContentLoaded', () => { setTimeout(window.checkUrlParams, 500); });

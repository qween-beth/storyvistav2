'use strict';

require('dotenv').config();
const { resolveMedia } = require('../src/media/index');
const logger = require('../src/utils/logger');

async function testVariety() {
  const block = {
    topic: 'African Savannah',
    key_concepts: ['habitat', 'wildlife'],
  };

  const sceneHints = [
    'Elephants walking in the savannah near a watering hole',
    'A cheetah chasing a gazelle across the dusty plains',
    'Tall baobab trees silhouetted against a golden sunset'
  ];

  console.log('--- TESTING IMAGE VARIETY FOR LESSON SLIDES ---');
  
  const urls = new Set();
  
  for (let i = 0; i < sceneHints.length; i++) {
    console.log(`\nSlide ${i + 1}: [${block.topic}] -> "${sceneHints[i]}"`);
    try {
      // We pass the index 'i' to ensure variety
      const result = await resolveMedia(block, 'lesson', '9-12', 'ng', sceneHints[i], i);
      
      console.log(`- Source: ${result.source}`);
      console.log(`- URL: ${result.url}`);
      
      if (urls.has(result.url)) {
        console.warn(`! DUPLICATE detected: This image was already used on another slide.`);
      } else {
        urls.add(result.url);
        console.log(`✓ UNIQUE: New image found for this slide.`);
      }
    } catch (err) {
      console.error(`✘ ERROR: ${err.message}`);
    }
  }

  console.log('\n--- VARIETY TEST COMPLETE ---');
  if (urls.size === sceneHints.length) {
    console.log('🎉 ALL SLIDES HAVE UNIQUE IMAGES!');
  } else {
    console.log(`⚠️ Only ${urls.size}/${sceneHints.length} slides have unique images.`);
  }
  process.exit(0);
}

testVariety();

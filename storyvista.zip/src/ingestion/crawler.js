'use strict';

const axios = require('axios');
const cheerio = require('cheerio');
const pLimit = require('p-limit');
const { URL } = require('url');
const logger = require('../utils/logger');

const crawlLimit = pLimit(parseInt(process.env.CRAWL_CONCURRENCY || '3', 10));

// ── User-Agent rotation (avoids blocks) ──────────────────────────
const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0',
];

function randomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

// ── HTML → Clean Markdown converter ──────────────────────────────
function htmlToMarkdown($, rootSelector) {
  const $root = rootSelector ? $(rootSelector) : $('body');

  // Remove non-content elements
  $root.find('script, style, nav, footer, header, aside, iframe, noscript, .ad, .ads, .sidebar, .menu, .nav, .cookie, .popup, [role="navigation"], [role="banner"], [role="complementary"]').remove();

  // Convert common HTML to simple markdown
  $root.find('h1').each((_, el) => { $(el).replaceWith(`\n# ${$(el).text().trim()}\n`); });
  $root.find('h2').each((_, el) => { $(el).replaceWith(`\n## ${$(el).text().trim()}\n`); });
  $root.find('h3').each((_, el) => { $(el).replaceWith(`\n### ${$(el).text().trim()}\n`); });
  $root.find('h4, h5, h6').each((_, el) => { $(el).replaceWith(`\n#### ${$(el).text().trim()}\n`); });
  $root.find('strong, b').each((_, el) => { $(el).replaceWith(`**${$(el).text().trim()}**`); });
  $root.find('em, i').each((_, el) => { $(el).replaceWith(`*${$(el).text().trim()}*`); });
  $root.find('li').each((_, el) => { $(el).replaceWith(`- ${$(el).text().trim()}\n`); });
  $root.find('br').replaceWith('\n');
  $root.find('p').each((_, el) => { $(el).replaceWith(`\n${$(el).text().trim()}\n`); });

  // Extract text content
  const text = $root.text()
    .replace(/\t/g, ' ')
    .replace(/ +/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return text;
}

// ── Extract links from a page ────────────────────────────────────
function extractLinks($, baseUrl) {
  const links = new Set();
  $('a[href]').each((_, el) => {
    try {
      const href = $(el).attr('href');
      if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('javascript:')) return;
      const resolved = new URL(href, baseUrl).href;
      // Only keep same-domain links
      const base = new URL(baseUrl);
      const target = new URL(resolved);
      if (target.hostname === base.hostname || target.hostname.endsWith('.' + base.hostname)) {
        links.add(resolved.split('#')[0]); // strip fragment
      }
    } catch (_) { /* invalid URL — skip */ }
  });
  return [...links];
}

// ── Detect main content area ─────────────────────────────────────
function detectMainContent($) {
  // Try well-known main content selectors
  const selectors = [
    'main', 'article', '[role="main"]',
    '#content', '#main-content', '.main-content',
    '.article-body', '.entry-content', '.post-content',
    '.mw-parser-output',  // Wikipedia
  ];

  for (const sel of selectors) {
    if ($(sel).length > 0 && $(sel).text().trim().length > 200) {
      return sel;
    }
  }
  return null; // fallback to full body
}

// ── Scrape a single page ─────────────────────────────────────────
async function fetchPage(url, retries = 2) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const { data, headers } = await axios.get(url, {
        headers: {
          'User-Agent': randomUA(),
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        timeout: 15000,
        maxRedirects: 5,
      });

      // Only process HTML responses
      const contentType = headers['content-type'] || '';
      if (!contentType.includes('text/html') && !contentType.includes('application/xhtml')) {
        logger.debug(`[Crawler] Skipping non-HTML: ${url} (${contentType})`);
        return null;
      }

      return data;
    } catch (err) {
      if (attempt < retries) {
        const delay = (attempt + 1) * 1000;
        logger.debug(`[Crawler] Retry ${attempt + 1} for ${url} in ${delay}ms`);
        await new Promise(r => setTimeout(r, delay));
      } else {
        throw err;
      }
    }
  }
}

/**
 * Scrape a single page and return structured data.
 *
 * @param {string} url
 * @param {Object} sourceMeta - { sourceId, sourceName }
 * @returns {Promise<RawPage|null>}
 */
async function scrapePage(url, sourceMeta = {}) {
  logger.info(`[Crawler] Scraping page → ${url}`);

  const html = await fetchPage(url);
  if (!html) return null;

  const $ = cheerio.load(html);

  const title = $('title').text().trim() ||
                $('meta[property="og:title"]').attr('content') ||
                $('h1').first().text().trim() || '';

  const description = $('meta[name="description"]').attr('content') ||
                      $('meta[property="og:description"]').attr('content') || '';

  const mainSelector = detectMainContent($);
  const content = htmlToMarkdown($, mainSelector);

  return {
    sourceId: sourceMeta.sourceId || sourceMeta.id || 'manual',
    sourceName: sourceMeta.sourceName || sourceMeta.name || 'Manual',
    sourceUrl: sourceMeta.sourceUrl || sourceMeta.url || url,
    pageUrl: url,
    title,
    description,
    content,
    links: extractLinks($, url),
    crawledAt: new Date().toISOString(),
    topic: null,
  };
}

/**
 * Check if a URL matches any of the include path patterns.
 *
 * @param {string} url
 * @param {string[]} patterns - glob-like patterns e.g. ['/animals/*', '/science/*']
 * @param {string} baseUrl
 * @returns {boolean}
 */
function matchesIncludePaths(url, patterns, baseUrl) {
  if (!patterns || patterns.length === 0) return true; // no filter = all allowed

  try {
    const target = new URL(url);
    const path = target.pathname;

    return patterns.some(pattern => {
      // Convert simple glob pattern to regex
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
      return regex.test(path);
    });
  } catch (_) {
    return false;
  }
}

/**
 * Crawl a single source — BFS link following with depth/page limits.
 *
 * @param {Object} source  - from sources.js
 * @param {string} [topic] - optional topic hint
 * @returns {Promise<Array<RawPage>>}
 */
async function crawlSource(source, topic = null) {
  const maxPages = source.crawlOpts?.maxPages || parseInt(process.env.CRAWL_MAX_PAGES || '20', 10);
  const includePaths = source.crawlOpts?.includePaths || [];
  const delayMs = parseInt(process.env.CRAWL_DELAY_MS || '800', 10); // politeness delay

  logger.info(`[Crawler] Starting crawl → ${source.name} (${source.url})`, {
    sourceId: source.id,
    maxPages,
    topic,
  });

  const visited = new Set();
  const queue = [source.url];
  const pages = [];

  while (queue.length > 0 && pages.length < maxPages) {
    const url = queue.shift();

    // Normalize URL
    const normalUrl = url.split('#')[0].replace(/\/+$/, '');
    if (visited.has(normalUrl)) continue;
    visited.add(normalUrl);

    // Check include path filter
    if (!matchesIncludePaths(normalUrl, includePaths, source.url)) {
      continue;
    }

    try {
      const page = await scrapePage(normalUrl, {
        id: source.id,
        name: source.name,
        url: source.url,
      });

      if (page && page.content && page.content.length >= 200) {
        page.topic = topic || null;
        pages.push(page);

        // Add discovered links to queue
        const newLinks = (page.links || []).filter(link => {
          const norm = link.split('#')[0].replace(/\/+$/, '');
          return !visited.has(norm) && matchesIncludePaths(norm, includePaths, source.url);
        });
        queue.push(...newLinks);
      }

      // Politeness delay between requests
      if (queue.length > 0 && pages.length < maxPages) {
        await new Promise(r => setTimeout(r, delayMs));
      }
    } catch (err) {
      logger.warn(`[Crawler] Failed to scrape ${normalUrl}: ${err.message}`);
    }
  }

  logger.info(`[Crawler] Completed → ${source.name}: ${pages.length} pages`, { sourceId: source.id });
  return pages;
}

/**
 * Crawl multiple sources concurrently (respects CRAWL_CONCURRENCY)
 *
 * @param {Array} sources
 * @param {string} [topic]
 * @returns {Promise<Array<RawPage>>}
 */
async function crawlSources(sources, topic = null) {
  const tasks = sources.map((src) =>
    crawlLimit(() => crawlSource(src, topic).catch((err) => {
      logger.warn(`[Crawler] Skipping ${src.id} after error: ${err.message}`);
      return []; // Don't let one bad source kill the whole run
    }))
  );

  const results = await Promise.all(tasks);
  return results.flat();
}

/**
 * Filter out pages with too little content to be useful
 * @param {Array<RawPage>} pages
 * @param {number} minChars
 * @returns {Array<RawPage>}
 */
function filterPages(pages, minChars = 300) {
  return pages.filter((p) => {
    if (!p.content || p.content.trim().length < minChars) return false;
    return true;
  });
}

module.exports = { crawlSource, crawlSources, scrapePage, filterPages };

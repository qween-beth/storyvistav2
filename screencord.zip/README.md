# 📽️ Screencord — AI-Powered Event Management & Strategic Intelligence

**Screencord** is a premium, privacy-first event management and strategic intelligence platform. Beyond high-fidelity recording and real-time streaming, Screencord features an integrated **AI Intelligence Hub** that acts as an automated executive assistant, alongside a professional-grade **Scheduling Dashboard** for managing large-scale watch parties and collaborative sessions.

---

## 🌟 Key Features

### 📅 Advanced Event Scheduling & Management
*   **Strategic Scheduling Dashboard:** A dedicated full-page workspace ([view-schedule](file:///c:/Users/USER/Desktop/2026/screencord/index.html#L614-694)) to architect your event from start to finish.
*   **Dynamic Form Builder:** Go beyond standard fields. Organizers can now add **Custom Survey Questions** to capture specific attendee intelligence (Dietary, Role, Goals) during registration.
*   **Thematic AI Invitations:** Choose from **Professional**, **Friendly**, or **Party** visual themes. Each selection dynamically renders a high-fidelity HTML invitation tailored to your event's tone.
*   **Rich Media Compose Engine:** Review and edit your invitations before they go out. Featuring a live **Email Preview & Editor**, you can customize subject lines and message body to ensure your branding is perfect.
*   **Live Attendee Intelligence:** A centralized registry for tracking registrations, managing custom survey responses, and monitoring attendee growth in real-time.

### 🎙️ AI Post-Session Intelligence
*   **Automated Transcription:** High-accuracy transcription powered by **Replicate (OpenAI Whisper)**.
*   **Strategic Summaries:** Auto-generated, executive briefings focusing on session purpose and decisions via **Groq (Llama 3)**.
*   **Action Item Extraction:** Intelligent identification and listing of tasks, deliverables, and follow-ups.
*   **Smart Chaptering:** Automatic logical sectioning and titles for easy timeline navigation.
*   **Automated Insight Reports:** Professional email reports delivering the summary, action items, and chapters directly to the host's inbox post-processing.

### 📡 Immersive Live Collaboration
*   **Low-Latency Streaming:** Near-zero latency WebRTC broadcasting with custom 7-digit access codes.
*   **Collaborative Whiteboard:** Real-time annotations, drawing, and arrow pointers powered by **Fabric.js**.
*   **Smart Resource Push:** Instantly push links and documents to all viewers' screens with one click.
*   **Interactive Polls:** Native chat-based polls for instant audience feedback.

### 🤖 Live AI Copilot
*   **Self-Indexing Sessions:** A pulsing AI Copilot badge indicates real-time session indexing during live broadcasts.
*   **Automated Greetings:** The Screencord AI joins your chat to announce its presence and role in organizing session insights.

### 🛡️ Privacy & Performance
*   **Hybrid Storage:** Recordings are stored locally via `IndexedDB` and managed by a secure SQLite backend.
*   **Glassmorphism UI:** A meticulously crafted, fluid interface with native Dark/Light mode support.
*   **Admin Dashboard:** Real-time monitoring of active broadcasts, viewer counts, and user roles.

---

## 🛠️ Technology Stack

*   **Frontend:** Vanilla ES6+ JavaScript, CSS3 (Glassmorphism), [Fabric.js](http://fabricjs.com/) (Canvas), [PeerJS](https://peerjs.com/) (WebRTC).
*   **Backend:** Node.js, Express.
*   **Database:** SQLite via `better-sqlite3`, IndexedDB (Client-side).
*   **AI Infrastructure:** 
    *   **Replicate:** OpenAI Whisper for high-fidelity audio-to-text.
    *   **Groq:** Llama 3 70B for lightning-fast LLM chapter generation, summarization, and action item extraction.
*   **Communications:** Nodemailer for automated Insight Reports, Thematic Invitations, and Registration Confirmations.
*   **Media Handling:** Multer, MediaRecorder API, AudioContext.

---

## 🚀 Getting Started

### 1. Prerequisites
*   Node.js (v16+)
*   API Keys for [Replicate](https://replicate.com/) and [Groq](https://groq.com/).
*   Gmail account (with App Password) for email functionality.

### 2. Configuration
Create a `.env` file in the root directory:
```env
PORT=3007
BASE_URL=http://localhost:3007
REPLICATE_API_TOKEN=your_replicate_token
GROQ_API_KEY=your_groq_key
GMAIL_USER=your_email@gmail.com
GMAIL_APP_PASSWORD=your_app_password
```

### 3. Installation
```bash
# Install dependencies
npm install

# Start the server
node server.js
```
Navigate to `http://localhost:3007` to start recording.

---

## 👥 Usage Guide

1.  **Record & Process:** Capture your screen. Upon saving, the AI automatically transcribes, summarizes, and generates chapters.
2.  **Schedule an Event:** Use the **Schedule Dashboard** to transform a recording into a Watch Party. Add **Custom Questions** to your registration form and preview your **AI Invitation** before publishing.
3.  **Invite Guests:** Use the **Compose Engine** to personalize your session invitations and track registrations in the **Attendee List**.
4.  **Go Live:** Switch to the **Live** tab, share your screen, and use the **Annotation Toolbar** (hit `P` for Pen, `W` for Whiteboard) to collaborate in real-time.
5.  **Review Intelligence:** View the Strategic Summary and Action Items directly in the playback sidebar or your inbox.

---

*Crafted for speed, intelligence, and immersive professional collaboration.*d immersive professional collaboration.*

# Screencord Product Roadmap & Monetization Strategy

This document outlines the strategic future of the Screencord platform, focusing on high-value features for professional teams and enterprise-grade monetization.

## 🎯 Core Vision
Transform Screencord from a "sharing tool" to an **"integrated ecosystem for high-stakes remote collaboration."**

---

## 🛠️ Phase 1: Interactive Collaboration (The "Retention" Layer)
*Focus: Enhancing the live experience to make every session more productive.*

- [ ] **The Live Canvas (Annotations)**: Allow the host and authorized viewers to draw, highlight, or place temporary markers directly on the live video stream.
- [ ] **Smart Resource "Push"**: Enable the host to "push" a resource (document, link, Figma embed) as a floating window for all viewers.
- [ ] **Viewer "Emoji Bursts"**: Add floating live emoji reactions (claps, hearts, fire) to provide the host with instant visual feedback.

## 🤖 Phase 2: AI & Post-Session Intelligence
*Focus: Turning recordings into searchable, actionable knowledge assets.*

- [ ] **Auto-Chaptering**: Use AI transcription to detect and label sections of the video automatically (e.g., "Introduction," "Feature Demo," "Q&A").
- [ ] **Action Item Extraction**: Integration with GPT to scan the transcript and chat for tasks, then push them directly to Slack, Trello, or Jira.
- [ ] **Video-Side Search**: Allow viewers of a saved recording to search for a keyword and jump directly to the moment it was spoken.

## 📡 Phase 3: Infrastructure & Scale
*Focus: Moving beyond P2P for reliability and professional-grade performance.*

- [ ] **SFU/MCU Architecture Transition**: Move beyond PeerJS P2P for high-scale sessions (1,000+ viewers) with ultra-low latency 4K streaming.
- [ ] **High-Fidelity Cloud Recording**: Store recordings in the cloud at 4K resolution rather than relying on local browser storage.
- [ ] **Team/Organization Accounts**: Centralized billing, team-wide recording libraries, and shared permission settings.

## 🏢 Phase 4: Enterprise & White-Labeling
*Focus: Custom experiences for high-ticket corporate clients.*

- [ ] **Branded Portals**: Custom subdomains (e.g., `screencord.acme.com`) with corporate logos, branding, and customized UI color schemes.
- [ ] **SSO / SAML Integration**: Secure login through corporate identity providers like Okta or Google Workspace.
- [ ] **Audit Logs & Compliance**: Detailed tracking of who viewed what and when, for security and compliance requirements.

---

## 💰 Suggested Monetization Hooks

| Tier | Price (Est.) | Key Features |
| :--- | :--- | :--- |
| **Free** | $0 | Local recordings, unlimited P2P sessions up to 5 people. |
| **Pro** | $12/mo | Cloud storage (100GB), AI transcriptions, Custom branding. |
| **Team** | $25/seat/mo | Team recordings library, SFU-powered large sessions (50+ people). |
| **Enterprise** | Custom | Branded portals, SSO, 24/7 support, Unlimited cloud storage. |

---
*Created on: 2026-03-27*

const nodemailer = require('nodemailer');

/**
 * Screencord Mailer Service
 * Configured for Gmail SMTP by default.
 * Requires: GMAIL_USER and GMAIL_APP_PASSWORD in .env
 */

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
    },
});

const sendEmail = async (to, subject, text, html) => {
    if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
        console.warn('[Mailer] Missing Gmail credentials. Skipping email send.');
        return { skipped: true };
    }

    try {
        const info = await transporter.sendMail({
            from: `"Screencord AI" <${process.env.GMAIL_USER}>`,
            to,
            subject,
            text,
            html,
        });

        console.log('[Mailer] Email sent: %s', info.messageId);
        return { success: true, messageId: info.messageId };
    } catch (err) {
        console.error('[Mailer] Error sending email:', err.message);
        throw err;
    }
};

/**
 * Send an AI Insight Report
 */
const sendInsightReport = async (to, recordingName, transcript, chapters, actionItems, summaryText) => {
    const chaptersHtml = chapters?.map(c => `<li><b>${c.title}</b> at ${c.start}s</li>`).join('') || '';
    const itemsHtml = actionItems?.map(i => `<li style="margin-bottom:8px;">✅ ${i}</li>`).join('') || '<li style="color:#aaa;">No specific action items detected.</li>';
    
    const subject = `✨ Your AI Insights are Ready: ${recordingName}`;
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 12px; border-top: 5px solid #8b5cf6;">
            <h2 style="color: #333; text-align: center;">Screencord Intelligence</h2>
            <p>Your session recording <strong>"${recordingName}"</strong> has been processed professionally.</p>
            
            ${summaryText ? `
            <div style="padding: 20px; background: #fafcfe; border: 1px dashed #bfdbfe; border-radius: 12px; margin: 24px 0;">
                <h3 style="margin-top: 0; color: #1e40af; font-size: 1rem;">Strategic Summary</h3>
                <p style="margin-bottom:0; color: #4b5563; line-height: 1.6; font-size: 0.9rem; font-style: italic;">
                    "${summaryText}"
                </p>
            </div>
            ` : ''}

            <div style="background: #f1f5f9; padding: 20px; border-radius: 12px; margin: 24px 0;">
                <h3 style="margin-top: 0; color: #1e293b; font-size: 1.1rem;">📝 Action Items</h3>
                <ul style="padding-left: 0; list-style: none; color: #334155; font-size: 0.95rem;">
                    ${itemsHtml}
                </ul>
            </div>

            <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; color: #8b5cf6;">🎞️ Smart Chapters</h3>
                <ul style="padding-left: 20px; color: #4b5563;">
                    ${chaptersHtml}
                </ul>
            </div>
            
            <div style="margin-top: 20px;">
                <h3 style="color: #555;">Transcript Preview</h3>
                <p style="color: #777; font-style: italic; font-size: 0.9em; line-height: 1.6;">
                    "${transcript.substring(0, 300)}..."
                </p>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="${process.env.BASE_URL || 'http://localhost:3007'}" style="background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">View Full Intelligence</a>
            </div>
            
            <p style="font-size: 0.8em; color: #aaa; text-align: center; margin-top: 40px;">
                © 2026 Screencord AI. Professional Screen Recording & Strategic Intelligence.
            </p>
        </div>
    `;

    return sendEmail(to, subject, transcript.substring(0, 150), html);
};

/**
 * Send a Session Invitation
 */
const sendInvite = async (to, senderName, roomCode, roomType) => {
    const typeLabel = roomType === 'live' ? 'Live Broadcast' : 'Watch Party';
    const subject = `🤝 ${senderName} invited you to a ${typeLabel}`;
    
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: auto; padding: 30px; background: #fff; border: 1px solid #e5e7eb; border-radius: 16px; text-align: center;">
            <div style="margin-bottom: 20px;">
                <span style="background: #ef4444; color: white; padding: 4px 12px; border-radius: 99px; font-size: 0.75rem; font-weight: bold; text-transform: uppercase;">NOW ${roomType === 'live' ? 'LIVE' : 'PARTY'}</span>
            </div>
            <h2 style="color: #1f2937; margin-bottom: 10px;">Session Invitation</h2>
            <p style="color: #4b5563; line-height: 1.5;">${senderName} is hosting a <strong>${typeLabel}</strong> and wants you to join the collaboration!</p>
            
            <div style="margin: 30px 0; padding: 20px; background: #f3f4f6; border-radius: 12px;">
                <p style="font-size: 0.8rem; color: #6b7280; text-transform: uppercase; margin-bottom: 8px;">Access Code</p>
                <h1 style="font-family: monospace; letter-spacing: 4px; color: #111827; margin: 0;">${roomCode}</h1>
            </div>
            
            <a href="${process.env.BASE_URL || 'http://localhost:3007'}" style="display: block; background: #111827; color: white; padding: 14px; text-decoration: none; border-radius: 8px; font-weight: 600;">Join Session</a>
            
            <p style="margin-top: 20px; font-size: 0.85rem; color: #9ca3af;">No software required. Runs entirely in your browser.</p>
        </div>
    `;

    return sendEmail(to, subject, `${senderName} invited you. Code: ${roomCode}`, html);
};

/**
 * Send a Registration Confirmation email
 */
const sendRegistrationConfirmation = async (to, name, sessionTitle, scheduledAt, roomCode) => {
    const subject = `📅 Registration Confirmed: ${sessionTitle}`;
    const dateStr = new Date(scheduledAt).toLocaleString();
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 12px; border-top: 5px solid #10b981;">
            <h2 style="color: #333; text-align: center;">Registration Confirmed!</h2>
            <p>Hello <strong>${name || 'Attendee'}</strong>,</p>
            <p>You have successfully registered for the upcoming Screencord Watch Party:</p>
            
            <div style="background: #f0fdf4; padding: 24px; border-radius: 12px; margin: 24px 0; text-align:center;">
                <h3 style="margin-top: 0; color: #065f46; font-size: 1.2rem;">${sessionTitle}</h3>
                <p style="font-size: 1.1rem; color: #047857; font-weight: bold; margin-bottom: 8px;">${dateStr}</p>
                <div style="font-family: monospace; font-size: 1.6rem; color: #10b981; margin: 16px 0;">${roomCode}</div>
                <p style="font-size: 0.85rem; color: #6b7280;">Keep this access code handy to join the session at start time.</p>
            </div>
            
            <p style="color: #4b5563; line-height: 1.6;">We'll notify you when the host goes live. Be sure to arrive early to ensure you don't miss any of the AI-enhanced insights!</p>
            
            <div style="text-align: center; margin-top: 32px; border-top: 1px solid #eee; padding-top: 24px;">
                <p style="font-size: 0.8rem; color: #9ca3af; margin: 0;">&copy; 2026 Screencord AI Intelligence Platform</p>
            </div>
        </div>
    `;
    return sendEmail(to, subject, `Registration Confirmed: ${sessionTitle} on ${dateStr}`, html);
};

/**
 * Send an Invitation to a Scheduled Session with Themes and Custom Messages
 */
const sendScheduledInvite = async (to, senderName, sessionTitle, scheduledAt, roomCode, theme = 'professional', customMessage = "") => {
    let subject, badgeText, badgeBg, bgStyle, boxBg, boxBorder, btnBg, btnRadius, toneText;
    
    if (theme === 'party') {
        subject = `🎉 You're Invited: ${sessionTitle} with ${senderName}!`;
        badgeText = '🔥 MASSIVE EVENT';
        badgeBg = 'linear-gradient(45deg, #f43f5e, #8b5cf6)';
        bgStyle = 'background: #0f172a; color: #fff; border: 2px solid #334155;';
        boxBg = '#1e293b';
        boxBorder = '#475569';
        btnBg = 'linear-gradient(90deg, #ec4899, #8b5cf6); color: white;';
        btnRadius = '24px';
        toneText = customMessage || `<strong>${senderName}</strong> is throwing an epic Watch Party! Grab your spot on the RSVP list before it fills up.`;
    } else if (theme === 'friendly') {
        subject = `👋 You're invited by ${senderName}: ${sessionTitle}`;
        badgeText = '✨ UPCOMING HANGOUT';
        badgeBg = '#8b5cf6';
        bgStyle = 'background: #fff; color: #1e293b; border: 1px solid #ddd6fe;';
        boxBg = '#f5f3ff';
        boxBorder = '#c4b5fd';
        btnBg = 'background: #6d28d9; color: white;';
        btnRadius = '16px';
        toneText = customMessage || `<strong>${senderName}</strong> is hosting an awesome Watch Party today, and we'd love for you to join us!`;
    } else {
        // Professional default
        subject = `📅 Invitation: ${sessionTitle} with ${senderName}`;
        badgeText = 'EXECUTIVE BRIEFING';
        badgeBg = '#3b82f6';
        bgStyle = 'background: #fff; color: #1f2937; border: 1px solid #e5e7eb;';
        boxBg = '#f8fafc';
        boxBorder = '#cbd5e1';
        btnBg = 'background: #111827; color: white;';
        btnRadius = '8px';
        toneText = customMessage || `<strong>${senderName}</strong> has scheduled an exclusive Watch Party and requests your attendance on the registered attendee list.`;
    }

    const dateStr = new Date(scheduledAt).toLocaleString();
    const regUrl = `${process.env.BASE_URL || 'http://localhost:3007'}/?reg=${roomCode}`;
    
    // Default text color logic depending on dark/light
    const textColor = theme === 'party' ? '#e2e8f0' : '#4b5563';
    const titleColor = theme === 'party' ? '#ffffff' : '#0f172a';

    const html = `
        <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 500px; margin: auto; padding: 35px; border-radius: 20px; text-align: center; ${bgStyle}">
            <div style="margin-bottom: 24px;">
                <span style="background: ${badgeBg}; color: white; padding: 6px 14px; border-radius: 99px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">${badgeText}</span>
            </div>
            <h2 style="color: ${titleColor}; margin-bottom: 12px; font-size: 1.8rem;">You're Invited!</h2>
            <p style="color: ${textColor}; line-height: 1.6; font-size: 1.05rem;">${toneText}</p>
            
            <div style="margin: 35px 0; padding: 24px; background: ${boxBg}; border: 1.5px dashed ${boxBorder}; border-radius: 14px;">
                <h3 style="margin-top: 0; color: ${titleColor}; font-size: 1.3rem;">${sessionTitle}</h3>
                <p style="font-size: 1.1rem; color: ${theme === 'party' ? '#cbd5e1' : '#475569'}; font-weight: 700; margin-bottom: 0;">${dateStr}</p>
            </div>
            
            <a href="${regUrl}" style="display: block; ${btnBg} padding: 16px; text-decoration: none; border-radius: ${btnRadius}; font-weight: 700; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">RSVP & Register Now</a>
            
            <p style="margin-top: 24px; font-size: 0.85rem; color: #9ca3af;">Please register via the link above to secure your spot and receive the unique access code.</p>
        </div>
    `;

    return sendEmail(to, subject, `You're invited to ${sessionTitle}. RSVP here: ${regUrl}`, html);
};

module.exports = {
    sendEmail,
    sendInsightReport,
    sendInvite,
    sendRegistrationConfirmation,
    sendScheduledInvite
};

/**
 * Screencord — Admin Dashboard Module (SQLite Backend)
 * Handles admin panel: stats, broadcast history, user management, analytics.
 */

const ScreencordAdmin = {
    stats: null,
    broadcasts: [],
    users: [],

    async apiFetch(url, options = {}) {
        return ScreencordAuth.apiFetch(url, options);
    },

    async loadDashboard() {
        if (!ScreencordAuth.isAdmin()) return;
        
        await Promise.all([
            this.loadStats(),
            this.loadBroadcasts(),
            this.loadUsers()
        ]);
        
        this.renderStats();
        this.renderBroadcastsTable();
        this.renderUsersTable();
    },

    async loadStats() {
        try {
            this.stats = await this.apiFetch('/api/admin/stats');
        } catch (err) {
            console.error('[Admin] Failed to load stats:', err);
            this.stats = {
                total_users: 0, total_admins: 0, total_broadcasts: 0,
                active_broadcasts: 0, total_viewer_joins: 0,
                avg_viewers_per_broadcast: 0, avg_broadcast_duration: 0,
                total_messages: 0
            };
        }
    },

    async loadBroadcasts() {
        try {
            this.broadcasts = await this.apiFetch('/api/admin/broadcasts');
        } catch (err) {
            console.error('[Admin] Failed to load broadcasts:', err);
            this.broadcasts = [];
        }
    },

    async loadUsers() {
        try {
            this.users = await this.apiFetch('/api/admin/users');
        } catch (err) {
            console.error('[Admin] Failed to load users:', err);
            this.users = [];
        }
    },

    renderStats() {
        const s = this.stats;
        const setVal = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.textContent = val;
        };

        setVal('stat-total-broadcasts', s.total_broadcasts);
        setVal('stat-total-viewers', s.total_viewer_joins);
        setVal('stat-total-users', s.total_users);
        setVal('stat-active-broadcasts', s.active_broadcasts);
        setVal('stat-avg-viewers', s.avg_viewers_per_broadcast);
        setVal('stat-avg-duration', this.formatDuration(s.avg_broadcast_duration));
        setVal('stat-total-messages', s.total_messages);
        setVal('stat-total-admins', s.total_admins);
    },

    renderBroadcastsTable() {
        const tbody = document.getElementById('admin-broadcasts-body');
        if (!tbody) return;
        
        if (this.broadcasts.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color: var(--text-3); padding: 40px;">No broadcasts yet</td></tr>`;
            return;
        }

        tbody.innerHTML = this.broadcasts.map(b => {
            const hostName = b.host_name || 'Unknown';
            const date = new Date(b.started_at).toLocaleDateString('en-US', {
                month: 'short', day: 'numeric', year: 'numeric',
                hour: '2-digit', minute: '2-digit'
            });
            const typeBadge = b.broadcast_type === 'live' 
                ? '<span class="admin-badge admin-badge--live">LIVE</span>'
                : '<span class="admin-badge admin-badge--playback">PARTY</span>';
            const statusBadge = b.status === 'active'
                ? '<span class="admin-badge admin-badge--active">Active</span>'
                : '<span class="admin-badge admin-badge--ended">Ended</span>';

            return `
                <tr>
                    <td>${date}</td>
                    <td>${hostName}</td>
                    <td>${typeBadge}</td>
                    <td><code class="admin-code">${b.room_code}</code></td>
                    <td>${b.peak_viewers} / ${b.total_viewers}</td>
                    <td>${this.formatDuration(b.duration_seconds)}</td>
                    <td>${statusBadge}</td>
                </tr>
            `;
        }).join('');
    },

    renderUsersTable() {
        const tbody = document.getElementById('admin-users-body');
        if (!tbody) return;

        if (this.users.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-3); padding: 40px;">No users yet</td></tr>`;
            return;
        }

        tbody.innerHTML = this.users.map(u => {
            const roleBadge = u.role === 'admin'
                ? '<span class="admin-badge admin-badge--admin">Admin</span>'
                : '<span class="admin-badge admin-badge--user">User</span>';
            const lastActive = u.last_active 
                ? new Date(u.last_active).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
                : 'Never';
            const isCurrentUser = u.id === ScreencordAuth.currentUser?.id;

            return `
                <tr>
                    <td>
                        <div class="admin-user-cell">
                            <div class="admin-user-avatar">${(u.display_name || 'U').charAt(0).toUpperCase()}</div>
                            <div>
                                <div class="admin-user-name">${u.display_name || 'Unknown'}</div>
                                <div class="admin-user-email">${u.email}</div>
                            </div>
                        </div>
                    </td>
                    <td>${roleBadge}</td>
                    <td>${u.total_broadcasts || 0}</td>
                    <td>${lastActive}</td>
                    <td>${new Date(u.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                    <td>
                        ${!isCurrentUser ? `
                            <button class="btn btn--ghost btn--sm admin-action-btn" onclick="ScreencordAdmin.toggleRole('${u.id}', '${u.role}')">
                                ${u.role === 'admin' ? 'Demote' : 'Make Admin'}
                            </button>
                        ` : '<span style="color:var(--text-3); font-size:0.8rem">You</span>'}
                    </td>
                </tr>
            `;
        }).join('');
    },

    async toggleRole(userId, currentRole) {
        const newRole = currentRole === 'admin' ? 'user' : 'admin';
        const confirmText = newRole === 'admin' 
            ? 'Promote this user to admin?' 
            : 'Demote this user from admin?';
        
        if (!confirm(confirmText)) return;

        try {
            await this.apiFetch(`/api/admin/users/${userId}/role`, {
                method: 'PATCH',
                body: JSON.stringify({ role: newRole })
            });
            
            showToast(`User role updated to ${newRole}`, 'success');
            await this.loadUsers();
            this.renderUsersTable();
        } catch (err) {
            showToast('Failed to update role: ' + err.message, 'error');
        }
    },

    formatDuration(seconds) {
        if (!seconds || seconds === 0) return '0s';
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        if (h > 0) return `${h}h ${m}m`;
        if (m > 0) return `${m}m ${s}s`;
        return `${s}s`;
    }
};

window.ScreencordAdmin = ScreencordAdmin;

// ─── Broadcast Tracking Helpers ───
// Called from app.js to log broadcast events to server

window.ScreencordTracker = {
    currentBroadcastId: null,
    broadcastStartTime: null,

    async apiFetch(url, options = {}) {
        return ScreencordAuth.apiFetch(url, options);
    },

    async startBroadcast(roomCode, type = 'live') {
        if (!ScreencordAuth.currentUser) return;

        try {
            const data = await this.apiFetch('/api/broadcasts', {
                method: 'POST',
                body: JSON.stringify({ room_code: roomCode, broadcast_type: type })
            });

            if (data.broadcast_id) {
                this.currentBroadcastId = data.broadcast_id;
                this.broadcastStartTime = Date.now();
            }
        } catch (err) {
            console.error('[Tracker] Failed to log broadcast start:', err);
        }
    },

    async endBroadcast() {
        if (!this.currentBroadcastId) return;

        const duration = this.broadcastStartTime 
            ? Math.floor((Date.now() - this.broadcastStartTime) / 1000) 
            : 0;

        try {
            await this.apiFetch(`/api/broadcasts/${this.currentBroadcastId}/end`, {
                method: 'PATCH',
                body: JSON.stringify({ duration_seconds: duration })
            });
        } catch (err) {
            console.error('[Tracker] Failed to log broadcast end:', err);
        }

        this.currentBroadcastId = null;
        this.broadcastStartTime = null;
    },

    async updateViewerCount(peakViewers, totalViewers) {
        if (!this.currentBroadcastId) return;

        try {
            await this.apiFetch(`/api/broadcasts/${this.currentBroadcastId}/viewers`, {
                method: 'PATCH',
                body: JSON.stringify({ peak_viewers: peakViewers, total_viewers: totalViewers })
            });
        } catch (err) {
            console.error('[Tracker] Failed to update viewer count:', err);
        }
    },

    async logViewerJoin(broadcastRoomCode, viewerName) {
        if (!ScreencordAuth.currentUser) return null;

        try {
            const data = await this.apiFetch('/api/broadcasts/join', {
                method: 'POST',
                body: JSON.stringify({ room_code: broadcastRoomCode, viewer_name: viewerName })
            });
            return data.viewer_record_id || null;
        } catch (err) {
            console.error('[Tracker] Failed to log viewer join:', err);
            return null;
        }
    },

    async logViewerLeave(viewerRecordId) {
        if (!viewerRecordId) return;

        try {
            await this.apiFetch(`/api/broadcasts/leave/${viewerRecordId}`, {
                method: 'PATCH'
            });
        } catch (err) {
            console.error('[Tracker] Failed to log viewer leave:', err);
        }
    },

    async logChatMessage(senderName, message, msgType = 'chat') {
        if (!ScreencordAuth.currentUser || !this.currentBroadcastId) return;

        try {
            await this.apiFetch(`/api/broadcasts/${this.currentBroadcastId}/messages`, {
                method: 'POST',
                body: JSON.stringify({ sender_name: senderName, message, message_type: msgType })
            });
        } catch (err) {
            console.error('[Tracker] Failed to log chat message:', err);
        }
    }
};

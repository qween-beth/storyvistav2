require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const { ExpressPeerServer } = require('peer');
const db = require('./database');
const multer = require('multer');
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const Groq = require('groq-sdk');
const Replicate = require('replicate');
const mailer = require('./mailer');

const upload = multer({ dest: 'uploads/' });

// Groq Configuration
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || 'your_groq_api_key_here' });

// Replicate Configuration
const replicate = new Replicate({
    auth: process.env.REPLICATE_API_TOKEN,
});

const app = express();
const server = http.createServer(app);

// ─── Middleware ───
app.use(express.json());
app.use(express.static(__dirname));

// Request Logger
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// ─── PeerJS Signalling Server ───
const peerServer = ExpressPeerServer(server, {
    debug: true,
    path: '/peerjs'
});
app.use('/peer', peerServer);

// ─── Auth Middleware ───
function authRequired(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Authentication required' });
    }

    const token = authHeader.substring(7);
    const user = db.validateSession(token);
    if (!user) {
        return res.status(401).json({ error: 'Invalid or expired session' });
    }

    req.user = user;
    req.token = token;
    next();
}

function adminRequired(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    next();
}

function optionalAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const user = db.validateSession(token);
        if (user) {
            req.user = user;
            req.token = token;
        }
    }
    next();
}

// ═══════════════════════════════════════════════════════
// AUTH ROUTES
// ═══════════════════════════════════════════════════════

// Register
app.post('/api/auth/register', (req, res) => {
    try {
        const { email, password, display_name } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        // Check if email already exists
        const existing = db.getUserByEmail(email);
        if (existing) {
            return res.status(409).json({ error: 'An account with this email already exists' });
        }

        const user = db.createUser(email, password, display_name);
        const token = db.createSession(user.id);

        res.json({ user, token });
    } catch (err) {
        console.error('[Auth] Register error:', err.message);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// Login
app.post('/api/auth/login', (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const user = db.authenticateUser(email, password);
        if (!user) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const token = db.createSession(user.id);
        res.json({ user, token });
    } catch (err) {
        console.error('[Auth] Login error:', err.message);
        res.status(500).json({ error: 'Login failed' });
    }
});

// Get current session
app.get('/api/auth/me', authRequired, (req, res) => {
    res.json({ user: req.user });
});

// Logout
app.post('/api/auth/logout', authRequired, (req, res) => {
    db.deleteSession(req.token);
    res.json({ ok: true });
});

// Update profile
app.patch('/api/auth/profile', authRequired, (req, res) => {
    try {
        const updated = db.updateUserProfile(req.user.id, req.body);
        res.json({ user: updated });
    } catch (err) {
        res.status(500).json({ error: 'Profile update failed' });
    }
});

// ═══════════════════════════════════════════════════════
// BROADCAST ROUTES
// ═══════════════════════════════════════════════════════

// Start a broadcast
app.post('/api/broadcasts', authRequired, (req, res) => {
    try {
        const { room_code, broadcast_type } = req.body;
        const id = db.createBroadcast(req.user.id, room_code, broadcast_type || 'live');
        res.json({ broadcast_id: id });
    } catch (err) {
        console.error('[Broadcast] Create error:', err.message);
        res.status(500).json({ error: 'Failed to create broadcast' });
    }
});

// End a broadcast
app.patch('/api/broadcasts/:id/end', authRequired, (req, res) => {
    try {
        const { duration_seconds } = req.body;
        db.endBroadcast(req.params.id, duration_seconds || 0);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to end broadcast' });
    }
});

// Update viewer counts
app.patch('/api/broadcasts/:id/viewers', authRequired, (req, res) => {
    try {
        const { peak_viewers, total_viewers } = req.body;
        db.updateBroadcastViewers(req.params.id, peak_viewers, total_viewers);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update viewers' });
    }
});

// Log viewer join — can be anonymous
app.post('/api/broadcasts/join', optionalAuth, (req, res) => {
    try {
        const { room_code, viewer_name } = req.body;
        const broadcast = db.getActiveBroadcastByCode(room_code);
        if (!broadcast) {
            return res.json({ viewer_record_id: null });
        }

        const userId = req.user ? req.user.id : null;
        const recordId = db.logViewerJoin(broadcast.id, userId, viewer_name);
        res.json({ viewer_record_id: recordId, broadcast_id: broadcast.id });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log viewer join' });
    }
});

// Log viewer leave — can be anonymous
app.patch('/api/broadcasts/leave/:viewerRecordId', optionalAuth, (req, res) => {
    try {
        db.logViewerLeave(req.params.viewerRecordId);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log viewer leave' });
    }
});

// Log chat message — can be anonymous
app.post('/api/broadcasts/:id/messages', optionalAuth, (req, res) => {
    try {
        const { sender_name, message, message_type } = req.body;
        const userId = req.user ? req.user.id : null;
        const msgId = db.logChatMessage(req.params.id, userId, sender_name, message, message_type);
        res.json({ message_id: msgId });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log message' });
    }
});

// ═══════════════════════════════════════════════════════
// ADMIN ROUTES (admin only)
// ═══════════════════════════════════════════════════════

// Get admin stats
app.get('/api/admin/stats', authRequired, adminRequired, (req, res) => {
    try {
        const stats = db.getAdminStats();
        res.json(stats);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load stats' });
    }
});

// Get all broadcasts
app.get('/api/admin/broadcasts', authRequired, adminRequired, (req, res) => {
    try {
        const broadcasts = db.getBroadcasts(50);
        res.json(broadcasts);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load broadcasts' });
    }
});

// Get all users
app.get('/api/admin/users', authRequired, adminRequired, (req, res) => {
    try {
        const users = db.getAllUsers();
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load users' });
    }
});

// Update user role
app.patch('/api/admin/users/:id/role', authRequired, adminRequired, (req, res) => {
    try {
        const { role } = req.body;
        if (!['user', 'admin'].includes(role)) {
            return res.status(400).json({ error: 'Invalid role' });
        }
        const user = db.updateUserRole(req.params.id, role);
        res.json({ user });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update role' });
    }
});
// ═══════════════════════════════════════════════════════
// AI & POST-SESSION INTELLIGENCE
// ═══════════════════════════════════════════════════════

/**
 * Endpoint to process a recording with AI (Transcription + Chaptering)
 * Expects a multipart/form-data with a 'video' file.
 */
app.post('/api/ai/process', optionalAuth, upload.single('video'), async (req, res) => {
    const videoFile = req.file;
    if (!videoFile) return res.status(400).json({ error: 'No video file provided' });

    console.log(`[AI] Processing video: ${videoFile.originalname} (${videoFile.size} bytes)`);

    let renamedPath = videoFile.path + '.webm';
    try {
        if (!process.env.GROQ_API_KEY && groq.apiKey === 'your_groq_api_key_here') {
            throw new Error('Groq API Key not configured on server');
        }

        // Rename temp file so Groq recognizes the format
        fs.renameSync(videoFile.path, renamedPath);

        // 1. Transcription using Replicate OpenAI Whisper
        console.log('[AI] Step 1: Transcribing with Replicate...');
        const output = await replicate.run(
            "openai/whisper:8099696689d249cf8b122d833c36ac3f75505c666a395ca40ef26f68e7d3d16e",
            {
                input: {
                    audio: fs.createReadStream(renamedPath),
                    language: "auto",
                    translate: false,
                    temperature: 0,
                    transcription: "plain text",
                    suppress_tokens: "-1",
                    logprob_threshold: -1,
                    no_speech_threshold: 0.6,
                    condition_on_previous_text: true,
                    compression_ratio_threshold: 2.4,
                    temperature_increment_on_fallback: 0.2
                }
            }
        );

        const transcript = output.transcription;
        const segments = output.segments || [];

        // 2. Chaptering using Groq Llama 3 via SDK
        console.log('[AI] Step 2: Generating chapters...');
        const chapterPrompt = `
            You are a video analysis assistant. I will provide you with a transcript of a screen recording.
            Your task is to identify the main logical sections/chapters of the video and provide a concise title and the starting second for each.
            
            Format your response STRICTLY as a JSON array of objects: [{"title": "...", "start": 0}, ...]
            The 'start' should be the second where the section begins based on the context.
            
            TRANSCRIPT:
            ${transcript}
        `;

        const chatCompletion = await groq.chat.completions.create({
            messages: [{ role: 'user', content: chapterPrompt }],
            model: 'llama3-70b-8192',
            response_format: { type: 'json_object' }
        });

        // Parse Chat JSON
        let chapters = [];
        try {
            const content = JSON.parse(chatCompletion.choices[0].message.content);
            chapters = Array.isArray(content) ? content : (content.chapters || []);
        } catch (e) {
            console.error('[AI] Chapter parsing failed:', e.message);
        }

        // 3. Action Item Extraction using Groq Llama 3
        console.log('[AI] Step 3: Extracting Action Items...');
        const actionPrompt = `
            You are a strategic meeting assistant. I will provide you with a transcript of a recording.
            Your task is to identify and extract any specific action items, tasks, deadlines, or follow-up points mentioned.
            
            Format your response STRICTLY as a JSON array of strings: ["Task 1...", "Task 2...", ...]
            If no action items are found, return an empty array [].
            
            TRANSCRIPT:
            ${transcript}
        `;

        const actionCompletion = await groq.chat.completions.create({
            messages: [{ role: 'user', content: actionPrompt }],
            model: 'llama3-70b-8192',
            response_format: { type: 'json_object' }
        });

        let actionItems = [];
        try {
            const content = JSON.parse(actionCompletion.choices[0].message.content);
            actionItems = Array.isArray(content) ? content : (content.tasks || content.action_items || []);
        } catch (e) {
            console.error('[AI] Action item parsing failed:', e.message);
        }

        // 4. Strategic Summary using Groq Llama 3
        console.log('[AI] Step 4: Generating Strategic Summary...');
        const summaryPrompt = `
            You are a senior executive assistant. I will provide you with a transcript of a recording.
            Your task is to generate a concise "Executive Summary" of the session.
            The summary should be exactly two professional paragraphs:
            1. The first paragraph should summarize the primary purpose and main topics discussed.
            2. The second paragraph should summarize the core decisions made or the overall sentiment of the meeting.
            
            Return ONLY the text of the two paragraphs.
            
            TRANSCRIPT:
            ${transcript}
        `;

        const summaryCompletion = await groq.chat.completions.create({
            messages: [{ role: 'user', content: summaryPrompt }],
            model: 'llama3-70b-8192'
        });

        const summary = summaryCompletion.choices[0].message.content.trim();

        // Clean up
        if (fs.existsSync(renamedPath)) fs.unlinkSync(renamedPath);

        res.json({
            success: true,
            transcript,
            chapters,
            actionItems,
            summary,
            duration: segments.length > 0 ? segments[segments.length - 1].end : 0
        });

        // Optional: Auto-email insights if user provided an email
        if (req.user && req.user.email) {
            try {
                await mailer.sendInsightReport(req.user.email, videoFile.originalname, transcript, chapters, actionItems, summary);
            } catch (mailErr) {
                console.warn('[AI] Automated email notification failed:', mailErr.message);
            }
        }

    } catch (err) {
        console.error('[AI] CRITICAL ERROR:', err);
        
        // Detailed cleanup
        if (fs.existsSync(renamedPath)) fs.unlinkSync(renamedPath);
        if (videoFile && fs.existsSync(videoFile.path)) fs.unlinkSync(videoFile.path);
        
        res.status(500).json({ 
            error: 'AI Processing failed', 
            details: err.message,
            stack: err.stack
        });
    }
});

/**
 * Endpoint to send an email invitation to join a session
 */
const inviteLimits = new Map(); // Simple in-memory hourly rate limiting [userId/ip -> { count, startTime }]

app.post('/api/ai/invite', optionalAuth, async (req, res) => {
    try {
        const { to, sender_name, room_code, room_type } = req.body;
        
        if (!to || !room_code) {
            return res.status(400).json({ error: 'Missing required invitation fields' });
        }

        // --- Rate Limiting (100 per hour) ---
        const limitKey = req.user ? req.user.id : req.ip;
        const now = Date.now();
        const hourMs = 60 * 60 * 1000;
        
        if (!inviteLimits.has(limitKey)) {
            inviteLimits.set(limitKey, { count: 0, startTime: now });
        }
        
        const limit = inviteLimits.get(limitKey);
        if (now - limit.startTime > hourMs) {
            limit.count = 0;
            limit.startTime = now;
        }

        // --- Multiple Email Parsing ---
        const emailList = Array.isArray(to) ? to : to.split(/[,;\s]+/).filter(e => e.includes('@'));
        
        if (limit.count + emailList.length > 100) {
            const remaining = 100 - limit.count;
            return res.status(429).json({ error: `Hourly invitation limit exceeded. You can send ${remaining} more invites this hour.` });
        }

        const sender = sender_name || (req.user ? req.user.display_name : 'A Host');
        
        // --- Bulk Sending ---
        const { custom_subject, custom_html } = req.body;
        
        const results = await Promise.allSettled(emailList.map(email => {
            if (custom_subject && custom_html) {
                // Use custom content from Rich Editor
                return mailer.sendEmail(email.trim(), custom_subject, 'Invitation to Screencord Session', custom_html);
            } else {
                // Default template
                return mailer.sendInvite(email.trim(), sender, room_code, room_type || 'live');
            }
        }));
        
        const successCount = results.filter(r => r.status === 'fulfilled').length;
        limit.count += successCount;
        
        res.json({ 
            success: true, 
            sentCount: successCount,
            totalCount: emailList.length,
            message: `Successfully invited ${successCount} participants.` 
        });
    } catch (err) {
        console.error('[Invite] Email error:', err.message);
        res.status(500).json({ error: 'Failed to send invitation', details: err.message });
    }
});

/**
 * Endpoint to schedule a watch recording
 */
app.post('/api/sessions/schedule', authRequired, upload.single('video'), async (req, res) => {
    try {
        const { title, room_code, scheduled_at, form_config, invite_emails, email_theme } = req.body;
        const videoFile = req.file;

        if (!videoFile || !room_code || !scheduled_at) {
            return res.status(400).json({ error: 'Missing recording file, room code, or schedule time' });
        }

        const sessionTitle = title || 'Scheduled Watch Party';

        // Save session to DB
        db.createScheduledSession(
            req.user.id, 
            room_code, 
            sessionTitle, 
            videoFile.filename, 
            scheduled_at,
            form_config ? JSON.parse(form_config) : []
        );

        let sentCount = 0;
        
        // Handle Automated Emails to Invitees
        if (invite_emails) {
            const emailList = Array.isArray(invite_emails) ? invite_emails : JSON.parse(invite_emails);
            const validEmails = emailList.filter(e => e.includes('@'));
            
            if (validEmails.length > 0) {
                // Rate Limiting checks
                const limitKey = req.user.id;
                const now = Date.now();
                if (!inviteLimits.has(limitKey)) inviteLimits.set(limitKey, { count: 0, startTime: now });
                const limit = inviteLimits.get(limitKey);
                if (now - limit.startTime > 3600000) { limit.count = 0; limit.startTime = now; }

                if (limit.count + validEmails.length <= 100) {
                    const sender = req.user.display_name;
                    const parsedConfig = form_config ? JSON.parse(form_config) : {};
                    const themeObj = parsedConfig.theme || email_theme || 'professional';
                    const customMsg = parsedConfig.custom_message || "";
                    
                    const results = await Promise.allSettled(
                        validEmails.map(email => mailer.sendScheduledInvite(email.trim(), sender, sessionTitle, scheduled_at, room_code, themeObj, customMsg))
                    );
                    sentCount = results.filter(r => r.status === 'fulfilled').length;
                    limit.count += sentCount;
                } else {
                    console.warn(`[Schedule] User ${req.user.id} skipped some invites due to limit.`);
                }
            }
        }

        res.json({ 
            success: true, 
            message: 'Session scheduled successfully', 
            invitesSent: sentCount 
        });
    } catch (err) {
        console.error('[Schedule] Error:', err.message);
        res.status(500).json({ error: 'Failed to schedule session' });
    }
});

/**
 * Get scheduled session details (for registration page)
 */
app.get('/api/sessions/scheduled/:roomCode', async (req, res) => {
    try {
        const session = db.getScheduledSession(req.params.roomCode);
        if (!session) return res.status(404).json({ error: 'Session not found' });
        
        // Don't leak host_id or filename unnecessarily
        const safeSession = {
            room_code: session.room_code,
            title: session.title,
            scheduled_at: session.scheduled_at,
            form_config: session.form_config
        };

        res.json({ success: true, session: safeSession });
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch session' });
    }
});

/**
 * Endpoint to register for a scheduled session
 */
app.post('/api/sessions/register/:roomCode', async (req, res) => {
    try {
        const { name, email, phone, custom_data } = req.body;
        const session = db.getScheduledSession(req.params.roomCode);
        
        if (!session) return res.status(404).json({ error: 'Session not found' });
        if (!email) return res.status(400).json({ error: 'Email is required' });

        db.createRegistration(session.room_code, name, email, phone, custom_data);

        // Send confirmation email
        await mailer.sendRegistrationConfirmation(email, name, session.title, session.scheduled_at, session.room_code);

        res.json({ success: true, message: 'Registration successful. Confirmation email sent!' });
    } catch (err) {
        console.error('[Register] Error:', err.message);
        res.status(500).json({ error: 'Registration failed' });
    }
});

/**
 * Endpoint to list all scheduled sessions for the current host
 */
app.get('/api/sessions/my-scheduled', authRequired, async (req, res) => {
    try {
        const sessions = db.prepare(`
            SELECT s.*, (SELECT COUNT(*) FROM registrations r WHERE r.session_id = s.room_code) as attendee_count
            FROM scheduled_sessions s
            WHERE s.host_id = ?
            ORDER BY s.scheduled_at DESC
        `).all(req.user.id);

        res.json({ success: true, sessions });
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch scheduled sessions' });
    }
});

/**
 * Endpoint to list all registrations for a specific session
 */
app.get('/api/sessions/registrations/:roomCode', authRequired, async (req, res) => {
    try {
        // Ensure user is the host
        const session = db.getScheduledSession(req.params.roomCode);
        if (!session || session.host_id !== req.user.id) {
            return res.status(403).json({ error: 'Forbidden' });
        }

        const registrations = db.prepare(`
            SELECT * FROM registrations WHERE session_id = ? ORDER BY created_at DESC
        `).all(req.params.roomCode);

        // Parse custom_data for each registration
        registrations.forEach(r => {
            if (r.custom_data) r.custom_data = JSON.parse(r.custom_data);
        });

        res.json({ success: true, registrations });
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch registrations' });
    }
});

// ─── Start Server ───
const PORT = process.env.PORT || 3007;

// Initialize database before starting
db.init();

server.listen(PORT, '0.0.0.0', () => {
    console.log(`\x1b[32m%s\x1b[0m`, `Screencord Server Running!`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`Interface: 0.0.0.0`);
    console.log(`PeerJS path: /peer/peerjs`);
    console.log(`API: /api/auth, /api/broadcasts, /api/admin`);
    console.log(`Database: SQLite (screencord.db)`);
});

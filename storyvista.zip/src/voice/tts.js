'use strict';

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const Replicate = require('replicate');

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

// ── Default voices (Replicate / ElevenLabs pre-built) ────────────
const DEFAULT_VOICES = {
  storyteller_female: 'Sarah',
  storyteller_male:   'Josh',
  educator_female:    'Matilda',
  educator_male:      'Daniel',
  child_friendly:     'Gigi',
};

// ── Voice settings per content type ─────────────────────────────
const VOICE_SETTINGS = {
  story: {
    stability: 0.55,
    similarity_boost: 0.80,
    style: 0.35,
  },
  lesson: {
    stability: 0.75,
    similarity_boost: 0.85,
    style: 0.20,
  },
};

/**
 * Downloads audio from a Replicate URL.
 * Sometimes Replicate returns a readable stream, sometimes a generic URL.
 */
async function getBufferFromOutput(output) {
  if (Buffer.isBuffer(output)) return output;

  if (output && typeof output.arrayBuffer === 'function') {
    return Buffer.from(await output.arrayBuffer());
  }
  
  // Replicate output could be a string URL
  const url = typeof output === 'string' ? output : (output.url ? output.url() : null);
  
  if (!url || !url.startsWith('http')) {
    throw new Error('Could not parse Replicate output URL');
  }

  const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000 });
  return Buffer.from(response.data);
}

// ── Text-to-speech: single text block → audio buffer ─────────────
/**
 * @param {string} text
 * @param {Object} opts
 * @param {string} opts.voiceId       - Voice name (ElevenLabs) or cloned voice ID (Minimax)
 * @param {string} opts.contentType   - 'story' | 'lesson'
 * @returns {Promise<Buffer>}
 */
async function textToSpeech(text, opts = {}) {
  const {
    voiceId = DEFAULT_VOICES.storyteller_female,
    contentType = 'story',
  } = opts;

  const settings = VOICE_SETTINGS[contentType] || VOICE_SETTINGS.story;

  logger.info(`[Voice] TTS via Replicate — ${text.length} chars, voice=${voiceId}`);

  // Determine if this is a default ElevenLabs voice or a Minimax cloned voice
  const isDefaultVoice = Object.values(DEFAULT_VOICES).includes(voiceId) || ['Rachel', 'Aria', 'Drew'].includes(voiceId);

  try {
    let output;
    
    if (isDefaultVoice) {
      // ── Use ElevenLabs via Replicate ──
      output = await replicate.run("elevenlabs/v2-multilingual", {
        input: {
          voice: voiceId,
          prompt: text,
          stability: settings.stability,
          similarity_boost: settings.similarity_boost,
          style: settings.style,
        }
      });
    } else {
      // ── Use Minimax TTS for cloned voices ──
      output = await replicate.run("minimax/speech-02-turbo", {
        input: {
          voice_id: voiceId,
          text: text,
        }
      });
    }

    return await getBufferFromOutput(output);
  } catch (err) {
    logger.warn(`[Voice] Primary TTS failed (${voiceId}): ${err.message}. Attempting fallback...`);
    
    // ── FALLBACK ──────────────────────────────────────────────────
    // If the specific voice or Minimax fails, fall back to a standard reliable voice
    try {
      if (voiceId === 'Rachel') throw err; // Already failed with Rachel, don't loop

      const fallbackOutput = await replicate.run("elevenlabs/v2-multilingual", {
        input: {
          voice: "Rachel", // Extremely stable default
          prompt: text,
          stability: 0.5,
          similarity_boost: 0.75,
        }
      });
      logger.info(`[Voice] Fallback to Rachel successful`);
      return await getBufferFromOutput(fallbackOutput);
    } catch (fallbackErr) {
      logger.error(`[Voice] All TTS attempts failed: ${fallbackErr.message}`);
      throw fallbackErr;
    }
  }
}

// ── Narrate a full story (scene by scene) ────────────────────────
/**
 * Converts each scene's narrative text to audio.
 * Returns array of { sceneNumber, audio: Buffer, duration (est.) }
 *
 * @param {Object} story        - generated story object
 * @param {string} voiceId      - voice to use (default or cloned)
 * @param {string} outputDir    - where to save .mp3 files
 * @param {boolean} singleFile  - if true, narate everything into one file
 * @returns {Promise<Array>}
 */
async function narrateStory(story, voiceId = null, outputDir = null, singleFile = false) {
  const voice = voiceId || DEFAULT_VOICES.storyteller_female;
  const scenes = story.scenes || [];
  const results = [];

  logger.info(`[Voice] Narrating story "${story.title}" — mode=${singleFile ? 'single-file' : 'multi-segment'}`);

  if (singleFile) {
    try {
      const fullText = [
        `${story.title}.`,
        story.tagline || '',
        ...scenes.map(s => s.narrative),
        story.ending || ''
      ].filter(t => t.trim().length > 0).join('\n\n');

      const audio = await textToSpeech(fullText, { voiceId: voice, contentType: 'story' });
      const result = { type: 'full', audio, text: fullText };
      
      if (outputDir) {
        const filename = 'full_story.mp3';
        fs.writeFileSync(path.join(outputDir, filename), audio);
        result.fileName = filename;
        delete result.audio;
      }
      results.push(result);
      logger.info(`[Voice] Full story narration complete (${audio.length} bytes)`);
      return results;
    } catch (err) {
      logger.error(`[Voice] Full story narration failed: ${err.message}. Falling back to segments.`);
    }
  }

  // 1. Narrate title introduction
  try {
    const intro = `${story.title}. ${story.tagline || ''}`.trim();
    if (intro) {
      const introAudio = await textToSpeech(intro, { voiceId: voice, contentType: 'story' });
      const introRes = { type: 'intro', audio: introAudio, text: intro };
      
      if (outputDir) {
        const filename = 'intro.mp3';
        fs.writeFileSync(path.join(outputDir, filename), introAudio);
        introRes.fileName = filename;
        delete introRes.audio;
      }
      results.push(introRes);
    }
  } catch (err) {
    logger.error(`[Voice] Intro narration failed: ${err.message}`);
    results.push({ type: 'intro', error: err.message });
  }

  // 2. Narrate each scene
  for (const scene of scenes) {
    const text = scene.narrative || '';
    if (!text) continue;

    try {
      const audio = await textToSpeech(text, { voiceId: voice, contentType: 'story' });
      const result = { type: 'scene', sceneNumber: scene.sceneNumber, audio, text };

      if (outputDir) {
        const filename = `scene_${scene.sceneNumber}.mp3`;
        const filepath = path.join(outputDir, filename);
        fs.writeFileSync(filepath, audio);
        result.filePath = filepath;
        result.fileName = filename;
        delete result.audio; 
      }

      results.push(result);
      logger.info(`[Voice] Scene ${scene.sceneNumber} narrated (${audio.length} bytes)`);
    } catch (err) {
      logger.error(`[Voice] Scene ${scene.sceneNumber} failed: ${err.message}`);
      results.push({ type: 'scene', sceneNumber: scene.sceneNumber, error: err.message });
    }
  }

  // 3. Narrate ending
  if (story.ending) {
    try {
      const endingAudio = await textToSpeech(story.ending, { voiceId: voice, contentType: 'story' });
      const endingRes = { type: 'ending', audio: endingAudio, text: story.ending };
      
      if (outputDir) {
        const filename = 'ending.mp3';
        fs.writeFileSync(path.join(outputDir, filename), endingAudio);
        endingRes.fileName = filename;
        delete endingRes.audio;
      }
      results.push(endingRes);
    } catch (err) {
      logger.error(`[Voice] Ending narration failed: ${err.message}`);
      results.push({ type: 'ending', error: err.message });
    }
  }

  logger.info(`[Voice] ✓ Story narration complete — ${results.length} audio segments`);
  return results;
}

// ── Narrate a lesson (section by section) ───────────────────────
async function narrateLesson(lesson, voiceId = null, outputDir = null, singleFile = false) {
  const voice = voiceId || DEFAULT_VOICES.educator_female;
  const sections = lesson.sections || [];
  const results = [];

  logger.info(`[Voice] Narrating lesson "${lesson.title}" — mode=${singleFile ? 'single-file' : 'multi-segment'}`);

  if (singleFile) {
    try {
      const fullText = [
        `${lesson.title}. Objective: ${lesson.learningObjectives?.join(', ')}.`,
        ...sections.map(s => s.narrationScript || s.title),
      ].filter(t => t.trim().length > 0).join('\n\n');

      const audio = await textToSpeech(fullText, { voiceId: voice, contentType: 'lesson' });
      const result = { type: 'full', audio, text: fullText };
      
      if (outputDir) {
        const filename = 'full_lesson.mp3';
        fs.writeFileSync(path.join(outputDir, filename), audio);
        result.fileName = filename;
        delete result.audio;
      }
      results.push(result);
      logger.info(`[Voice] Full lesson narration complete (${audio.length} bytes)`);
      return results;
    } catch (err) {
      logger.error(`[Voice] Full lesson narration failed: ${err.message}. Falling back to segments.`);
    }
  }

  // 1. Narrate title and objectives
  try {
    const intro = `${lesson.title}. ${lesson.learningObjectives ? 'Today\'s objectives include ' + lesson.learningObjectives.join(', ') : ''}`.trim();
    if (intro) {
      const introAudio = await textToSpeech(intro, { voiceId: voice, contentType: 'lesson' });
      const introRes = { type: 'intro', audio: introAudio, text: intro };
      
      if (outputDir) {
        const filename = 'intro.mp3';
        fs.writeFileSync(path.join(outputDir, filename), introAudio);
        introRes.fileName = filename;
        delete introRes.audio;
      }
      results.push(introRes);
    }
  } catch (err) {
    logger.error(`[Voice] Lesson intro narration failed: ${err.message}`);
    results.push({ type: 'intro', error: err.message });
  }

  // 2. Narrate each section
  for (const section of sections) {
    const text = section.narrationScript || section.title || '';
    if (!text) continue;

    try {
      const audio = await textToSpeech(text, { voiceId: voice, contentType: 'lesson' });
      const result = { type: 'section', sectionNumber: section.sectionNumber, audio, text };

      if (outputDir) {
        const filename = `section_${section.sectionNumber}.mp3`;
        fs.writeFileSync(path.join(outputDir, filename), audio);
        result.fileName = filename;
        delete result.audio;
      }

      results.push(result);
    } catch (err) {
      logger.error(`[Voice] Section ${section.sectionNumber} failed: ${err.message}`);
      results.push({ type: 'section', sectionNumber: section.sectionNumber, error: err.message });
    }
  }

  logger.info(`[Voice] ✓ Lesson narration complete — ${results.length} audio segments`);
  return results;
}

module.exports = {
  textToSpeech,
  narrateStory,
  narrateLesson,
  DEFAULT_VOICES,
  VOICE_SETTINGS,
};

'use strict';

require('dotenv').config();
const { resolveMedia } = require('../src/media/index');
const logger = require('../src/utils/logger');

async function testResolution() {
  const testBlocks = [
    {
      topic: 'Photosynthesis',
      key_concepts: ['chloroplasts', 'sunlight'],
      sceneHint: 'A detailed diagram of a chloroplast showing photosynthesis components'
    },
    {
      topic: 'Lion',
      key_concepts: ['predator', 'savannah'],
      sceneHint: 'A family of lions resting under a baobab tree in the African savannah'
    },
    {
       topic: 'Circuit Board',
       key_concepts: ['electronics', 'solder'],
       sceneHint: 'A magnifying glass looking at a complex green circuit board'
    }
  ];

  console.log('--- STARTING MEDIA RESOLUTION TEST ---');
  
  for (const block of testBlocks) {
    console.log(`\nTesting: [${block.topic}] with SceneHint: "${block.sceneHint}"`);
    try {
      // Force non-cache for test
      const result = await resolveMedia(block, 'lesson', '9-12', 'ng', block.sceneHint);
      
      console.log(`- Source: ${result.source}`);
      console.log(`- URL: ${result.url}`);
      if (result.attribution) console.log(`- Attribution: ${result.attribution}`);
      
      if (result.source !== 'wikimedia') {
        console.warn(`! Warning: Expected Wikimedia for "${block.topic}", but got ${result.source}`);
      } else {
        console.log(`✓ SUCCESS: Resolved via Wikimedia`);
      }
    } catch (err) {
      console.error(`✘ ERROR: ${err.message}`);
    }
  }

  console.log('\n--- TEST COMPLETE ---');
  process.exit(0);
}

testResolution();

'use strict';

const axios = require('axios');
const fs = require('fs');
const { query } = require('../storage/db');
const logger = require('../utils/logger');
const Replicate = require('replicate');

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

// ── Clone a voice from audio samples ────────────────────────────
/**
 * Creates a Voice Clone using Replicate's Minimax model.
 * Note: Minimax voice cloning endpoint requires a public URL or file stream.
 * 
 * @param {Object} opts
 * @param {string}   opts.name          - display name e.g. "Mum's voice"
 * @param {string[]} opts.samplePaths   - local file paths to audio samples (.mp3/.wav)
 * @param {string}   opts.description   - optional description
 * @param {string}   opts.userId        - story vista user ID
 * @param {string}   opts.voiceType     - 'parent' | 'teacher'
 * @returns {Promise<ClonedVoice>}
 */
async function cloneVoice({ name, samplePaths, description = '', userId, voiceType = 'parent' }) {
  if (!samplePaths?.length) throw new Error('At least one audio sample is required');

  logger.info(`[VoiceClone] Cloning voice "${name}" for user ${userId} via Replicate (Minimax)`);

  const primarySample = samplePaths[0];
  if (!fs.existsSync(primarySample)) throw new Error(`Sample file not found: ${primarySample}`);

  // Replicate allows passing a readable stream directly for file inputs
  const fileStream = fs.createReadStream(primarySample);

  try {
    const output = await replicate.run("minimax/voice-cloning", {
      input: {
        voice_file: fileStream,
      }
    });

    const voiceId = output?.voice_id;
    if (!voiceId) throw new Error('Replicate (Minimax) did not return a voice_id');

    // Save to DB
    await saveClonedVoice({
      userId,
      voiceId,
      name,
      description,
      voiceType,
      sampleCount: samplePaths.length,
    });

    logger.info(`[VoiceClone] ✓ Voice cloned: ${voiceId} — "${name}"`);

    return { voiceId, name, voiceType, userId };
  } catch (err) {
    logger.error(`[VoiceClone] Failed to clone voice via Replicate: ${err.message}`);
    throw err;
  }
}

// ── Delete a cloned voice ────────────────────────────────────────
async function deleteClonedVoice(voiceId, userId) {
  // Verify ownership
  const result = await query(
    'SELECT id FROM cloned_voices WHERE voice_id = $1 AND user_id = $2',
    [voiceId, userId]
  );
  if (!result.rows.length) throw new Error('Voice not found or not owned by this user');

  // Currently, Replicate/Minimax doesn't have an explicit delete endpoint for cached voice IDs
  // We'll just remove it from our database.
  
  // Remove from DB
  await query('DELETE FROM cloned_voices WHERE voice_id = $1', [voiceId]);
  logger.info(`[VoiceClone] Deleted voice ${voiceId} from local DB`);
}

// ── Get all cloned voices for a user ────────────────────────────
async function getUserVoices(userId) {
  const result = await query(
    `SELECT voice_id, name, voice_type, sample_count, created_at
     FROM cloned_voices WHERE user_id = $1 ORDER BY created_at DESC`,
    [userId]
  );
  return result.rows;
}

// ── Get a user's default voice for a content type ───────────────
async function getDefaultVoice(userId, voiceType = 'parent') {
  const result = await query(
    `SELECT voice_id FROM cloned_voices
     WHERE user_id = $1 AND voice_type = $2
     ORDER BY created_at DESC LIMIT 1`,
    [userId, voiceType]
  );
  return result.rows[0]?.voice_id || null;
}

// ── Storage helpers ──────────────────────────────────────────────
async function saveClonedVoice({ userId, voiceId, name, description, voiceType, sampleCount }) {
  await query(
    `INSERT INTO cloned_voices (user_id, voice_id, name, description, voice_type, sample_count)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (voice_id) DO UPDATE SET name=$3, updated_at=NOW()`,
    [userId, voiceId, name, description, voiceType, sampleCount]
  );
}

module.exports = { cloneVoice, deleteClonedVoice, getUserVoices, getDefaultVoice };

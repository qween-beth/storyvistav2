/**
 * Screencord — SQLite Database Module
 * Handles all database operations: users, sessions, broadcasts, viewers, messages.
 */

const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');

const DB_PATH = path.join(__dirname, 'screencord.db');
let db;

function init() {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');

    // ─── Create Tables ───
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            display_name TEXT DEFAULT 'User',
            role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
            avatar_url TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            last_active TEXT DEFAULT (datetime('now')),
            total_broadcasts INTEGER DEFAULT 0,
            total_watch_time INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            created_at TEXT DEFAULT (datetime('now')),
            expires_at TEXT
        );

        CREATE TABLE IF NOT EXISTS broadcasts (
            id TEXT PRIMARY KEY,
            host_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            room_code TEXT NOT NULL,
            broadcast_type TEXT DEFAULT 'live' CHECK (broadcast_type IN ('live', 'playback')),
            status TEXT DEFAULT 'active' CHECK (status IN ('active', 'ended')),
            title TEXT DEFAULT 'Untitled Broadcast',
            started_at TEXT DEFAULT (datetime('now')),
            ended_at TEXT,
            peak_viewers INTEGER DEFAULT 0,
            total_viewers INTEGER DEFAULT 0,
            total_messages INTEGER DEFAULT 0,
            duration_seconds INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS broadcast_viewers (
            id TEXT PRIMARY KEY,
            broadcast_id TEXT NOT NULL REFERENCES broadcasts(id) ON DELETE CASCADE,
            viewer_id TEXT REFERENCES users(id) ON DELETE SET NULL,
            viewer_name TEXT DEFAULT 'Anonymous',
            joined_at TEXT DEFAULT (datetime('now')),
            left_at TEXT,
            watch_duration INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS chat_messages (
            id TEXT PRIMARY KEY,
            broadcast_id TEXT NOT NULL REFERENCES broadcasts(id) ON DELETE CASCADE,
            sender_id TEXT REFERENCES users(id) ON DELETE SET NULL,
            sender_name TEXT DEFAULT 'Anonymous',
            message TEXT NOT NULL,
            message_type TEXT DEFAULT 'chat' CHECK (message_type IN ('chat', 'poll', 'resource', 'system')),
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS scheduled_sessions (
            room_code TEXT PRIMARY KEY,
            host_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title TEXT DEFAULT 'Scheduled Watch Recording',
            recording_filename TEXT,
            scheduled_at TEXT,
            form_config TEXT, -- JSON for custom fields
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS registrations (
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL REFERENCES scheduled_sessions(room_code) ON DELETE CASCADE,
            name TEXT,
            email TEXT,
            phone TEXT,
            custom_data TEXT, -- JSON for answers
            created_at TEXT DEFAULT (datetime('now'))
        );
    `);

    console.log('[DB] SQLite database initialized');
}

// ─── Helpers ───
function generateId() {
    return crypto.randomUUID();
}

function generateToken() {
    return crypto.randomBytes(48).toString('hex');
}

// ─── User Operations ───
function createUser(email, password, displayName) {
    const id = generateId();
    const hash = bcrypt.hashSync(password, 10);
    
    // First user becomes admin
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const role = userCount === 0 ? 'admin' : 'user';
    const name = displayName || email.split('@')[0];

    const stmt = db.prepare(`
        INSERT INTO users (id, email, password_hash, display_name, role)
        VALUES (?, ?, ?, ?, ?)
    `);
    
    stmt.run(id, email.toLowerCase(), hash, name, role);
    return getUserById(id);
}

function authenticateUser(email, password) {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (!user) return null;
    if (!bcrypt.compareSync(password, user.password_hash)) return null;
    
    // Update last_active
    db.prepare("UPDATE users SET last_active = datetime('now') WHERE id = ?").run(user.id);
    
    return sanitizeUser(user);
}

function getUserById(id) {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    return user ? sanitizeUser(user) : null;
}

function getUserByEmail(email) {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    return user ? sanitizeUser(user) : null;
}

function sanitizeUser(user) {
    const { password_hash, ...safe } = user;
    return safe;
}

function getAllUsers() {
    return db.prepare('SELECT id, email, display_name, role, created_at, last_active, total_broadcasts, total_watch_time FROM users ORDER BY created_at DESC').all();
}

function updateUserRole(userId, newRole) {
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(newRole, userId);
    return getUserById(userId);
}

function updateUserProfile(userId, updates) {
    const fields = [];
    const values = [];
    
    if (updates.display_name !== undefined) { fields.push('display_name = ?'); values.push(updates.display_name); }
    if (updates.avatar_url !== undefined) { fields.push('avatar_url = ?'); values.push(updates.avatar_url); }
    
    if (fields.length === 0) return getUserById(userId);
    
    values.push(userId);
    db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    return getUserById(userId);
}

// ─── Session Operations ───
function createSession(userId) {
    const token = generateToken();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days
    
    db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(token, userId, expiresAt);
    return token;
}

function validateSession(token) {
    if (!token) return null;
    
    const session = db.prepare(`
        SELECT s.*, u.id as uid, u.email, u.display_name, u.role, u.created_at, u.last_active, u.total_broadcasts
        FROM sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.token = ? AND (s.expires_at IS NULL OR s.expires_at > datetime('now'))
    `).get(token);
    
    if (!session) return null;
    
    return {
        id: session.uid,
        email: session.email,
        display_name: session.display_name,
        role: session.role,
        created_at: session.created_at,
        last_active: session.last_active,
        total_broadcasts: session.total_broadcasts
    };
}

function deleteSession(token) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

function deleteUserSessions(userId) {
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
}

// ─── Broadcast Operations ───
function createBroadcast(hostId, roomCode, type = 'live') {
    const id = generateId();
    db.prepare(`
        INSERT INTO broadcasts (id, host_id, room_code, broadcast_type, status)
        VALUES (?, ?, ?, ?, 'active')
    `).run(id, hostId, roomCode, type);
    
    // Increment user's total_broadcasts
    db.prepare('UPDATE users SET total_broadcasts = total_broadcasts + 1 WHERE id = ?').run(hostId);
    
    return id;
}

function endBroadcast(broadcastId, durationSeconds = 0) {
    db.prepare(`
        UPDATE broadcasts 
        SET status = 'ended', ended_at = datetime('now'), duration_seconds = ?
        WHERE id = ?
    `).run(durationSeconds, broadcastId);
}

function updateBroadcastViewers(broadcastId, peakViewers, totalViewers) {
    db.prepare(`
        UPDATE broadcasts SET peak_viewers = ?, total_viewers = ? WHERE id = ?
    `).run(peakViewers, totalViewers, broadcastId);
}

function getBroadcasts(limit = 50) {
    return db.prepare(`
        SELECT b.*, u.display_name as host_name, u.email as host_email
        FROM broadcasts b
        LEFT JOIN users u ON b.host_id = u.id
        ORDER BY b.started_at DESC
        LIMIT ?
    `).all(limit);
}

function getActiveBroadcastByCode(roomCode) {
    return db.prepare(`
        SELECT * FROM broadcasts WHERE room_code = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1
    `).get(roomCode);
}

// ─── Viewer Operations ───
function logViewerJoin(broadcastId, viewerId, viewerName) {
    const id = generateId();
    db.prepare(`
        INSERT INTO broadcast_viewers (id, broadcast_id, viewer_id, viewer_name)
        VALUES (?, ?, ?, ?)
    `).run(id, broadcastId, viewerId, viewerName);
    return id;
}

function logViewerLeave(viewerRecordId) {
    db.prepare(`
        UPDATE broadcast_viewers SET left_at = datetime('now') WHERE id = ?
    `).run(viewerRecordId);
}

// ─── Chat Operations ───
function logChatMessage(broadcastId, senderId, senderName, message, msgType = 'chat') {
    const id = generateId();
    db.prepare(`
        INSERT INTO chat_messages (id, broadcast_id, sender_id, sender_name, message, message_type)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, broadcastId, senderId, senderName, message, msgType);
    
    // Increment broadcast message count
    db.prepare('UPDATE broadcasts SET total_messages = total_messages + 1 WHERE id = ?').run(broadcastId);
    return id;
}

// ─── Admin Stats ───
function getAdminStats() {
    const stats = {};
    
    stats.total_users = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
    stats.total_admins = db.prepare('SELECT COUNT(*) as c FROM users WHERE role = "admin"').get().c;
    stats.total_broadcasts = db.prepare('SELECT COUNT(*) as c FROM broadcasts').get().c;
    stats.active_broadcasts = db.prepare('SELECT COUNT(*) as c FROM broadcasts WHERE status = "active"').get().c;
    stats.total_viewer_joins = db.prepare('SELECT COALESCE(SUM(total_viewers), 0) as c FROM broadcasts').get().c;
    
    const avgViewers = db.prepare('SELECT COALESCE(AVG(total_viewers), 0) as c FROM broadcasts WHERE total_viewers > 0').get().c;
    stats.avg_viewers_per_broadcast = Math.round(avgViewers);
    
    const avgDuration = db.prepare('SELECT COALESCE(AVG(duration_seconds), 0) as c FROM broadcasts WHERE duration_seconds > 0').get().c;
    stats.avg_broadcast_duration = Math.round(avgDuration);
    
    stats.total_messages = db.prepare('SELECT COALESCE(SUM(total_messages), 0) as c FROM broadcasts').get().c;
    
    return stats;
}

// ─── Scheduled Sessions ───
function createScheduledSession(hostId, roomCode, title, recordingFilename, scheduledAt, formConfig = '[]') {
    db.prepare(`
        INSERT INTO scheduled_sessions (room_code, host_id, title, recording_filename, scheduled_at, form_config)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(roomCode, hostId, title, recordingFilename, scheduledAt, JSON.stringify(formConfig));
    return roomCode;
}

function getScheduledSession(roomCode) {
    const session = db.prepare('SELECT * FROM scheduled_sessions WHERE room_code = ?').get(roomCode);
    if (session) session.form_config = JSON.parse(session.form_config);
    return session;
}

function createRegistration(sessionId, name, email, phone, customData = {}) {
    const id = generateId();
    db.prepare(`
        INSERT INTO registrations (id, session_id, name, email, phone, custom_data)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, sessionId, name, email, phone, JSON.stringify(customData));
    return id;
}

module.exports = {
    init,
    // Users
    createUser, authenticateUser, getUserById, getUserByEmail, getAllUsers,
    updateUserRole, updateUserProfile,
    // Sessions
    createSession, validateSession, deleteSession, deleteUserSessions,
    // Broadcasts
    createBroadcast, endBroadcast, updateBroadcastViewers, getBroadcasts, getActiveBroadcastByCode,
    // Viewers
    logViewerJoin, logViewerLeave,
    // Chat
    logChatMessage,
    // Admin
    getAdminStats,
    // Scheduled Sessions
    createScheduledSession, getScheduledSession, createRegistration
};

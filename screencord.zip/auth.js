/**
 * Screencord — Authentication Module (SQLite Backend)
 * Handles login, signup, session management via server API.
 */

const ScreencordAuth = {
    currentUser: null,
    token: null,
    isGuest: false,

    async init() {
        // Check for existing token in localStorage
        const savedToken = localStorage.getItem('screencord_token');
        if (savedToken) {
            try {
                const res = await this.apiFetch('/api/auth/me');
                if (res.user) {
                    this.currentUser = res.user;
                    this.token = savedToken;
                    this.showApp();
                    return;
                }
            } catch (err) {
                // Token invalid, clear it
                localStorage.removeItem('screencord_token');
            }
        }
        this.showAuthGate();
    },

    async apiFetch(url, options = {}) {
        const headers = { 'Content-Type': 'application/json', ...options.headers };
        const token = this.token || localStorage.getItem('screencord_token');
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const res = await fetch(url, { ...options, headers });
        const data = await res.json();
        
        if (!res.ok) {
            throw new Error(data.error || 'Request failed');
        }
        return data;
    },

    isAdmin() {
        return this.currentUser?.role === 'admin';
    },

    showApp() {
        const authGate = document.getElementById('auth-gate');
        const appContent = document.getElementById('app-content');
        if (authGate) authGate.style.display = 'none';
        if (appContent) appContent.style.display = 'block';

        // Update UI with user info
        const userNameEl = document.getElementById('user-display-name');
        const userEmailEl = document.getElementById('user-email');
        const userAvatarEl = document.getElementById('user-avatar-letter');
        const userMenu = document.getElementById('user-menu');

        if (this.isGuest) {
            if (userNameEl) userNameEl.textContent = 'Guest';
            if (userEmailEl) userEmailEl.textContent = 'Not signed in';
            if (userAvatarEl) userAvatarEl.textContent = 'G';
            // Hide admin + host-only nav for guests
            const adminLink = document.getElementById('nav-admin');
            if (adminLink) adminLink.style.display = 'none';
        } else {
            if (userNameEl) userNameEl.textContent = this.currentUser?.display_name || 'User';
            if (userEmailEl) userEmailEl.textContent = this.currentUser?.email || '';
            if (userAvatarEl) {
                const name = this.currentUser?.display_name || this.currentUser?.email || 'U';
                userAvatarEl.textContent = name.charAt(0).toUpperCase();
            }
            // Show admin nav link if admin
            const adminLink = document.getElementById('nav-admin');
            if (adminLink) {
                adminLink.style.display = this.isAdmin() ? 'flex' : 'none';
            }
        }

        // Store name for chat
        if (this.currentUser?.display_name) {
            localStorage.setItem('screencord_user_name', this.currentUser.display_name);
        } else if (this.isGuest) {
            const guestName = localStorage.getItem('screencord_user_name') || 'Guest';
            localStorage.setItem('screencord_user_name', guestName);
        }
    },

    showAuthGate() {
        const authGate = document.getElementById('auth-gate');
        const appContent = document.getElementById('app-content');
        if (authGate) authGate.style.display = 'flex';
        if (appContent) appContent.style.display = 'none';
    },

    async login(email, password) {
        const data = await this.apiFetch('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        this.currentUser = data.user;
        this.token = data.token;
        localStorage.setItem('screencord_token', data.token);
        this.showApp();
        return data;
    },

    async signup(email, password, displayName) {
        const data = await this.apiFetch('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify({ email, password, display_name: displayName })
        });
        
        this.currentUser = data.user;
        this.token = data.token;
        localStorage.setItem('screencord_token', data.token);
        this.showApp();
        return data;
    },

    async logout() {
        if (!this.isGuest) {
            try {
                await this.apiFetch('/api/auth/logout', { method: 'POST' });
            } catch (e) { /* ignore */ }
        }
        
        this.currentUser = null;
        this.token = null;
        this.isGuest = false;
        localStorage.removeItem('screencord_token');
        this.showAuthGate();
    },

    enterGuestMode() {
        this.isGuest = true;
        this.currentUser = null;
        this.token = null;
        this.showApp();
    },

    async updateProfile(updates) {
        const data = await this.apiFetch('/api/auth/profile', {
            method: 'PATCH',
            body: JSON.stringify(updates)
        });
        if (data.user) this.currentUser = data.user;
        return data.user;
    }
};

window.ScreencordAuth = ScreencordAuth;

// ─── Auth Form Handlers ───
window.handleAuthLogin = async function() {
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;
    const errorEl = document.getElementById('auth-error');
    const btn = document.getElementById('auth-submit-btn');

    if (!email || !password) {
        errorEl.textContent = 'Please enter email and password';
        errorEl.style.display = 'block';
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Signing in...';
    errorEl.style.display = 'none';

    try {
        await ScreencordAuth.login(email, password);
    } catch (err) {
        errorEl.textContent = err.message || 'Login failed';
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
    }
};

window.handleAuthSignup = async function() {
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;
    const name = document.getElementById('auth-name').value.trim() || email.split('@')[0];
    const errorEl = document.getElementById('auth-error');
    const btn = document.getElementById('auth-signup-btn');

    if (!email || !password) {
        errorEl.textContent = 'Please enter email and password';
        errorEl.style.display = 'block';
        return;
    }

    if (password.length < 6) {
        errorEl.textContent = 'Password must be at least 6 characters';
        errorEl.style.display = 'block';
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Creating account...';
    errorEl.style.display = 'none';

    try {
        await ScreencordAuth.signup(email, password, name);
    } catch (err) {
        errorEl.textContent = err.message || 'Signup failed';
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Create Account';
    }
};

window.handleAuthLogout = async function() {
    await ScreencordAuth.logout();
};

window.toggleAuthMode = function() {
    const loginGroup = document.getElementById('auth-login-group');
    const signupGroup = document.getElementById('auth-signup-group');
    const nameField = document.getElementById('auth-name-field');
    const toggleText = document.getElementById('auth-toggle-text');
    const errorEl = document.getElementById('auth-error');
    const successEl = document.getElementById('auth-success');

    if (errorEl) errorEl.style.display = 'none';
    if (successEl) successEl.style.display = 'none';

    if (loginGroup.style.display !== 'none') {
        loginGroup.style.display = 'none';
        signupGroup.style.display = 'flex';
        nameField.style.display = 'block';
        toggleText.innerHTML = 'Already have an account? <a href="#" onclick="toggleAuthMode(); return false;">Sign in</a>';
    } else {
        loginGroup.style.display = 'flex';
        signupGroup.style.display = 'none';
        nameField.style.display = 'none';
        toggleText.innerHTML = 'Don\'t have an account? <a href="#" onclick="toggleAuthMode(); return false;">Sign up</a>';
    }
};

// ─── Guest Join ───
window.guestJoinSession = function() {
    ScreencordAuth.enterGuestMode();
    // Navigate to record view but immediately show join modal
    if (typeof navigate === 'function') navigate('record');
    if (typeof setUIRole === 'function') setUIRole('host');
    // Small delay to ensure DOM is ready after showApp()
    setTimeout(() => {
        if (typeof showJoinModal === 'function') showJoinModal();
    }, 100);
};

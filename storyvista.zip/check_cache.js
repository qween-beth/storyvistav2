require('dotenv').config();
const { query } = require('./src/storage/db');

async function check() {
  try {
    const result = await query('SELECT * FROM media_cache LIMIT 50;');
    console.log(JSON.stringify(result.rows, null, 2));
  } catch (err) {
    console.error('CRITICAL ERROR: ' + err.message);
  }
  process.exit(0);
}

check();

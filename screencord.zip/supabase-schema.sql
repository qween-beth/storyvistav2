-- ═══════════════════════════════════════════════════════
-- SCREENCORD — Supabase Database Schema
-- Run this in your Supabase SQL Editor (Dashboard → SQL)
-- ═══════════════════════════════════════════════════════

-- 1. PROFILES TABLE (extends Supabase Auth users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email TEXT NOT NULL,
    display_name TEXT DEFAULT 'User',
    role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    last_active TIMESTAMPTZ DEFAULT now(),
    total_broadcasts INTEGER DEFAULT 0,
    total_watch_time INTEGER DEFAULT 0 -- in seconds
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies: Users can read all profiles, but only edit their own
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Admin policy: admins can update any profile
CREATE POLICY "Admins can update any profile" ON public.profiles
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- 2. BROADCASTS TABLE
CREATE TABLE IF NOT EXISTS public.broadcasts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    host_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    room_code TEXT NOT NULL,
    broadcast_type TEXT DEFAULT 'live' CHECK (broadcast_type IN ('live', 'playback')),
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    title TEXT DEFAULT 'Untitled Broadcast',
    started_at TIMESTAMPTZ DEFAULT now(),
    ended_at TIMESTAMPTZ,
    peak_viewers INTEGER DEFAULT 0,
    total_viewers INTEGER DEFAULT 0,
    total_messages INTEGER DEFAULT 0,
    duration_seconds INTEGER DEFAULT 0
);

ALTER TABLE public.broadcasts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Broadcasts viewable by authenticated users" ON public.broadcasts
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can insert their own broadcasts" ON public.broadcasts
    FOR INSERT WITH CHECK (auth.uid() = host_id);

CREATE POLICY "Users can update their own broadcasts" ON public.broadcasts
    FOR UPDATE USING (auth.uid() = host_id);

-- Admins can do anything with broadcasts
CREATE POLICY "Admins can manage all broadcasts" ON public.broadcasts
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- 3. BROADCAST VIEWERS TABLE
CREATE TABLE IF NOT EXISTS public.broadcast_viewers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    broadcast_id UUID REFERENCES public.broadcasts(id) ON DELETE CASCADE NOT NULL,
    viewer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    viewer_name TEXT DEFAULT 'Anonymous',
    joined_at TIMESTAMPTZ DEFAULT now(),
    left_at TIMESTAMPTZ,
    watch_duration INTEGER DEFAULT 0 -- in seconds
);

ALTER TABLE public.broadcast_viewers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Broadcast viewers viewable by authenticated" ON public.broadcast_viewers
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Anyone authenticated can insert viewer records" ON public.broadcast_viewers
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can update their own viewer records" ON public.broadcast_viewers
    FOR UPDATE USING (auth.uid() = viewer_id);

-- 4. CHAT MESSAGES TABLE (persistent log)
CREATE TABLE IF NOT EXISTS public.chat_messages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    broadcast_id UUID REFERENCES public.broadcasts(id) ON DELETE CASCADE NOT NULL,
    sender_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    sender_name TEXT DEFAULT 'Anonymous',
    message TEXT NOT NULL,
    message_type TEXT DEFAULT 'chat' CHECK (message_type IN ('chat', 'poll', 'resource', 'system')),
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Chat messages viewable by authenticated" ON public.chat_messages
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can insert messages" ON public.chat_messages
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- 5. AUTO-CREATE PROFILE ON SIGNUP (Trigger Function)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, display_name, role)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
        CASE WHEN (SELECT COUNT(*) FROM public.profiles) = 0 THEN 'admin' ELSE 'user' END
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop trigger if exists, then create
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. ADMIN STATS VIEW (for dashboard queries)
CREATE OR REPLACE VIEW public.admin_stats AS
SELECT
    (SELECT COUNT(*) FROM public.profiles) AS total_users,
    (SELECT COUNT(*) FROM public.profiles WHERE role = 'admin') AS total_admins,
    (SELECT COUNT(*) FROM public.broadcasts) AS total_broadcasts,
    (SELECT COUNT(*) FROM public.broadcasts WHERE status = 'active') AS active_broadcasts,
    (SELECT COALESCE(SUM(total_viewers), 0) FROM public.broadcasts) AS total_viewer_joins,
    (SELECT COALESCE(AVG(total_viewers), 0)::INTEGER FROM public.broadcasts WHERE total_viewers > 0) AS avg_viewers_per_broadcast,
    (SELECT COALESCE(AVG(duration_seconds), 0)::INTEGER FROM public.broadcasts WHERE duration_seconds > 0) AS avg_broadcast_duration,
    (SELECT COALESCE(SUM(total_messages), 0) FROM public.broadcasts) AS total_messages;

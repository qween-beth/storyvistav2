require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const { ExpressPeerServer } = require('peer');
const db = require('./database');
const multer = require('multer');
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const Groq = require('groq-sdk');

const upload = multer({ dest: 'uploads/' });

// Groq Configuration
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || 'your_groq_api_key_here' });

const app = express();
const server = http.createServer(app);

// ─── Middleware ───
app.use(express.json());
app.use(express.static(__dirname));

// Request Logger
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// ─── PeerJS Signalling Server ───
const peerServer = ExpressPeerServer(server, {
    debug: true,
    path: '/peerjs'
});
app.use('/peer', peerServer);

// ─── Auth Middleware ───
function authRequired(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Authentication required' });
    }

    const token = authHeader.substring(7);
    const user = db.validateSession(token);
    if (!user) {
        return res.status(401).json({ error: 'Invalid or expired session' });
    }

    req.user = user;
    req.token = token;
    next();
}

function adminRequired(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    next();
}

function optionalAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const user = db.validateSession(token);
        if (user) {
            req.user = user;
            req.token = token;
        }
    }
    next();
}

// ═══════════════════════════════════════════════════════
// AUTH ROUTES
// ═══════════════════════════════════════════════════════

// Register
app.post('/api/auth/register', (req, res) => {
    try {
        const { email, password, display_name } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        // Check if email already exists
        const existing = db.getUserByEmail(email);
        if (existing) {
            return res.status(409).json({ error: 'An account with this email already exists' });
        }

        const user = db.createUser(email, password, display_name);
        const token = db.createSession(user.id);

        res.json({ user, token });
    } catch (err) {
        console.error('[Auth] Register error:', err.message);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// Login
app.post('/api/auth/login', (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const user = db.authenticateUser(email, password);
        if (!user) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const token = db.createSession(user.id);
        res.json({ user, token });
    } catch (err) {
        console.error('[Auth] Login error:', err.message);
        res.status(500).json({ error: 'Login failed' });
    }
});

// Get current session
app.get('/api/auth/me', authRequired, (req, res) => {
    res.json({ user: req.user });
});

// Logout
app.post('/api/auth/logout', authRequired, (req, res) => {
    db.deleteSession(req.token);
    res.json({ ok: true });
});

// Update profile
app.patch('/api/auth/profile', authRequired, (req, res) => {
    try {
        const updated = db.updateUserProfile(req.user.id, req.body);
        res.json({ user: updated });
    } catch (err) {
        res.status(500).json({ error: 'Profile update failed' });
    }
});

// ═══════════════════════════════════════════════════════
// BROADCAST ROUTES
// ═══════════════════════════════════════════════════════

// Start a broadcast
app.post('/api/broadcasts', authRequired, (req, res) => {
    try {
        const { room_code, broadcast_type } = req.body;
        const id = db.createBroadcast(req.user.id, room_code, broadcast_type || 'live');
        res.json({ broadcast_id: id });
    } catch (err) {
        console.error('[Broadcast] Create error:', err.message);
        res.status(500).json({ error: 'Failed to create broadcast' });
    }
});

// End a broadcast
app.patch('/api/broadcasts/:id/end', authRequired, (req, res) => {
    try {
        const { duration_seconds } = req.body;
        db.endBroadcast(req.params.id, duration_seconds || 0);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to end broadcast' });
    }
});

// Update viewer counts
app.patch('/api/broadcasts/:id/viewers', authRequired, (req, res) => {
    try {
        const { peak_viewers, total_viewers } = req.body;
        db.updateBroadcastViewers(req.params.id, peak_viewers, total_viewers);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update viewers' });
    }
});

// Log viewer join — can be anonymous
app.post('/api/broadcasts/join', optionalAuth, (req, res) => {
    try {
        const { room_code, viewer_name } = req.body;
        const broadcast = db.getActiveBroadcastByCode(room_code);
        if (!broadcast) {
            return res.json({ viewer_record_id: null });
        }

        const userId = req.user ? req.user.id : null;
        const recordId = db.logViewerJoin(broadcast.id, userId, viewer_name);
        res.json({ viewer_record_id: recordId, broadcast_id: broadcast.id });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log viewer join' });
    }
});

// Log viewer leave — can be anonymous
app.patch('/api/broadcasts/leave/:viewerRecordId', optionalAuth, (req, res) => {
    try {
        db.logViewerLeave(req.params.viewerRecordId);
        res.json({ ok: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log viewer leave' });
    }
});

// Log chat message — can be anonymous
app.post('/api/broadcasts/:id/messages', optionalAuth, (req, res) => {
    try {
        const { sender_name, message, message_type } = req.body;
        const userId = req.user ? req.user.id : null;
        const msgId = db.logChatMessage(req.params.id, userId, sender_name, message, message_type);
        res.json({ message_id: msgId });
    } catch (err) {
        res.status(500).json({ error: 'Failed to log message' });
    }
});

// ═══════════════════════════════════════════════════════
// ADMIN ROUTES (admin only)
// ═══════════════════════════════════════════════════════

// Get admin stats
app.get('/api/admin/stats', authRequired, adminRequired, (req, res) => {
    try {
        const stats = db.getAdminStats();
        res.json(stats);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load stats' });
    }
});

// Get all broadcasts
app.get('/api/admin/broadcasts', authRequired, adminRequired, (req, res) => {
    try {
        const broadcasts = db.getBroadcasts(50);
        res.json(broadcasts);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load broadcasts' });
    }
});

// Get all users
app.get('/api/admin/users', authRequired, adminRequired, (req, res) => {
    try {
        const users = db.getAllUsers();
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: 'Failed to load users' });
    }
});

// Update user role
app.patch('/api/admin/users/:id/role', authRequired, adminRequired, (req, res) => {
    try {
        const { role } = req.body;
        if (!['user', 'admin'].includes(role)) {
            return res.status(400).json({ error: 'Invalid role' });
        }
        const user = db.updateUserRole(req.params.id, role);
        res.json({ user });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update role' });
    }
});
// ═══════════════════════════════════════════════════════
// AI & POST-SESSION INTELLIGENCE
// ═══════════════════════════════════════════════════════

/**
 * Endpoint to process a recording with AI (Transcription + Chaptering)
 * Expects a multipart/form-data with a 'video' file.
 */
app.post('/api/ai/process', optionalAuth, upload.single('video'), async (req, res) => {
    const videoFile = req.file;
    if (!videoFile) return res.status(400).json({ error: 'No video file provided' });

    console.log(`[AI] Processing video: ${videoFile.originalname} (${videoFile.size} bytes)`);

    let renamedPath = videoFile.path + '.webm';
    try {
        if (!process.env.GROQ_API_KEY && groq.apiKey === 'your_groq_api_key_here') {
            throw new Error('Groq API Key not configured on server');
        }

        // Rename temp file so Groq recognizes the format
        fs.renameSync(videoFile.path, renamedPath);

        // 1. Transcription using Groq Whisper via SDK
        console.log('[AI] Step 1: Transcribing...');
        const transcription = await groq.audio.transcriptions.create({
            file: fs.createReadStream(renamedPath),
            model: 'whisper-large-v3-turbo',
            response_format: 'verbose_json',
        });

        const transcript = transcription.text;
        const segments = transcription.segments || [];

        // 2. Chaptering using Groq Llama 3 via SDK
        console.log('[AI] Step 2: Generating chapters...');
        const chapterPrompt = `
            You are a video analysis assistant. I will provide you with a transcript of a screen recording.
            Your task is to identify the main logical sections/chapters of the video and provide a concise title and the starting second for each.
            
            Format your response STRICTLY as a JSON array of objects: [{"title": "...", "start": 0}, ...]
            The 'start' should be the second where the section begins based on the context.
            
            TRANSCRIPT:
            ${transcript}
        `;

        const chatCompletion = await groq.chat.completions.create({
            messages: [{ role: 'user', content: chapterPrompt }],
            model: 'llama3-70b-8192',
            response_format: { type: 'json_object' }
        });

        // Parse Chat JSON
        let chapters = [];
        try {
            const content = JSON.parse(chatCompletion.choices[0].message.content);
            chapters = Array.isArray(content) ? content : (content.chapters || []);
        } catch (e) {
            console.error('[AI] Chapter parsing failed:', e.message);
        }

        // Clean up
        if (fs.existsSync(renamedPath)) fs.unlinkSync(renamedPath);

        res.json({
            success: true,
            transcript,
            chapters,
            duration: segments.length > 0 ? segments[segments.length - 1].end : 0
        });

    } catch (err) {
        console.error('[AI] CRITICAL ERROR:', err);
        
        // Detailed cleanup
        if (fs.existsSync(renamedPath)) fs.unlinkSync(renamedPath);
        if (videoFile && fs.existsSync(videoFile.path)) fs.unlinkSync(videoFile.path);
        
        res.status(500).json({ 
            error: 'AI Processing failed', 
            details: err.message,
            stack: err.stack
        });
    }
});

// ─── Start Server ───
const PORT = process.env.PORT || 3007;

// Initialize database before starting
db.init();

server.listen(PORT, '0.0.0.0', () => {
    console.log(`\x1b[32m%s\x1b[0m`, `Screencord Server Running!`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`Interface: 0.0.0.0`);
    console.log(`PeerJS path: /peer/peerjs`);
    console.log(`API: /api/auth, /api/broadcasts, /api/admin`);
    console.log(`Database: SQLite (screencord.db)`);
});

require('dotenv').config();
const { getUsage, listVoices } = require('./src/voice/tts');

async function check() {
  console.log('Checking ElevenLabs API Key...');
  try {
    const usage = await getUsage();
    console.log('API KEY OK');
    console.log('Usage:', JSON.stringify(usage, null, 2));
    
    const voices = await listVoices();
    console.log('Voices available:', voices.length);
  } catch (err) {
    if (err.response) {
      console.error('API Error:', err.response.status, err.response.data);
    } else {
      console.error('Error:', err.message);
    }
    process.exit(1);
  }
}

check();

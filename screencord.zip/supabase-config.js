/**
 * Screencord — Supabase Configuration
 * Replace the URL and ANON_KEY with your project values from:
 * Supabase Dashboard → Settings → API
 */

const SUPABASE_URL = 'YOUR_SUPABASE_URL';       // e.g. https://abcdefg.supabase.co
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY'; // e.g. eyJhbGciOiJIUz...

// Initialize the Supabase client (loaded from CDN in index.html)
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

window.ScreencordSupabase = supabase;

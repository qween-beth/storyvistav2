'use strict';

require('dotenv').config();
const { resolveMedia } = require('../src/media/index');
const logger = require('../src/utils/logger');

async function testVariety() {
  const block = {
    topic: 'Cat', // Use a very common topic
    key_concepts: ['pet', 'feline'],
  };

  const sceneHints = [
    'Slide 1',
    'Slide 2',
    'Slide 3'
  ];

  console.log('--- TESTING IMAGE VARIETY ---');
  
  const urls = new Set();
  
  for (let i = 0; i < sceneHints.length; i++) {
    console.log(`\nSlide ${i}: index=${i}`);
    try {
      const result = await resolveMedia(block, 'lesson', '9-12', 'ng', sceneHints[i], i);
      console.log(`- URL: ${result.url}`);
      
      if (urls.has(result.url)) {
        console.warn(`! DUPLICATE detected.`);
      } else {
        urls.add(result.url);
        console.log(`✓ UNIQUE.`);
      }
    } catch (err) {
      console.error(`✘ ERROR: ${err.message}`);
    }
  }

  process.exit(0);
}

testVariety();

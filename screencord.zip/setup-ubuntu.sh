#!/bin/bash

# Screencord — Ubuntu Linux Server Setup Script
# Author: Antigravity
# Version: 1.0.0

echo "🚀 Starting Screencord Ubuntu Setup..."

# 1. Update and install base dependencies
echo "📦 Updating system and installing build tools..."
sudo apt update && sudo apt upgrade -y
sudo apt install build-essential python3 curl git -y

# 2. Install Node.js (v18)
echo "🟢 Installing Node.js 18..."
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Process Management (PM2)
echo "🛠️ Configuring PM2..."
sudo npm install pm2 -g

# 4. Install Project Dependencies
echo "📑 Installing local project dependencies..."
npm install

# 5. Setup Nginx (Reverse Proxy)
echo "🌐 Installing Nginx..."
sudo apt install nginx -y

# 6. Setup SSL (Certbot)
echo "🔐 Installing Certbot..."
sudo apt install certbot python3-certbot-nginx -y

# 7. Project Start (Manual Confirmation Required)
echo "✅ Setup Complete!"
echo "--------------------------------------------------------"
echo "Next Steps:"
echo "1. Configure your domain in Nginx (/etc/nginx/sites-available/screencord)"
echo "2. Run 'sudo certbot --nginx' to enable HTTPS (MANDATORY for mic/screen capture)"
echo "3. Start your app with: 'pm2 start server.js --name screencord'"
echo "4. Enable boot restart: 'pm2 startup' and 'pm2 save'"
echo "--------------------------------------------------------"

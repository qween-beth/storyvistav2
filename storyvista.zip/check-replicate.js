'use strict';

require('dotenv').config();
const Replicate = require('replicate');

async function testReplicate() {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token || token.includes('*****')) {
    console.error('❌ Error: REPLICATE_API_TOKEN is missing or masked in .env');
    process.exit(1);
  }

  const replicate = new Replicate({
    auth: token,
  });

  const input = {
    prompt: "A beautiful African children's book illustration showing a group of children exploring a lush garden with colorful flowers, soft lighting, friendly atmosphere.",
    quality: "high",
    aspect_ratio: "1:1"
  };

  console.log('🚀 Generating test image via openai/gpt-image-1.5 on Replicate...');
  
  try {
    const output = await replicate.run("openai/gpt-image-1.5", { input });
    
    // Output is usually an array of items
    const imageUrl = typeof output[0] === 'string' ? output[0] : (output[0]?.url ? output[0].url() : output[0]);
    
    console.log('✅ Success! Image URL:', imageUrl);
  } catch (error) {
    console.error('❌ Replicate test failed:', error.message);
  }
}

testReplicate();
